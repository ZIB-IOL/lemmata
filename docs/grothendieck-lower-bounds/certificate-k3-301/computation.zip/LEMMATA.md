# A 301-by-321 witness for the real Grothendieck constant of order three

Sebastian Pokutta · [ORCID 0000-0001-7365-3000](https://orcid.org/0000-0001-7365-3000)

**Theorem.** An explicit $301\times321$ integer matrix gives
$$
 K_G(3)>1.4397098471655953.
$$

The construction starts from the 141-row reference in the earlier computation. It adds two neighbors at each of 15 twofold directions and at each member of a second, 30-direction orbit. Three further orbits place 10, 30 and 30 directions at centers of gaps in the intermediate spherical configuration. The coefficients of the matrix and both sets of vector directions are then optimized.

Let $K$ denote the previous reference. For a Bob signing $b$ with $\|Kb\|_1>T=641519292$, a maximizing Alice signing $a$ satisfies $\|K^{\mathsf T}a\|_1>T$. By symmetry, one can take $a$ from the previous exhaustive list of 4,309 records. For each such $a$, all high-scoring choices of $b$ can be enumerated by the exact cost of flipping signs of $K^{\mathsf T}a$. This gives 625,968 Bob representatives. The new reference is $H=VK$, where $V$ is the supplied integer row transport. Since $\|Hb\|_1\le\|V\|_{1\to1}\|Kb\|_1$, the same list covers every signing above the transported cutoff. Exactly 101,967 representatives survive that cutoff.

A perturbation bound handles the complementary signings. Direct integer evaluation on the retained list gives the exact classical maximum, attained by the archived signing,
$$
 C(W)=641951269303647081416258863417 .
$$
The archived rational triples have common denominator $10^{40}$. Their exact score divided by $C(W)$ begins 1.4397098471655953648981198686680622. A dual Gram certificate bounds the improvement possible by changing either or both sets of vectors on this particular matrix by $7.2\times 10^{-35}$.

The conjecture of Bhattiprolu and Heinävaara places $K_G(3)$ at $1/\ln 2$. The new bound lies about 0.002985194 below the conjectured value. [Heinävaara, §3.15](https://web.math.princeton.edu/~oeh/research_statement_Otte.pdf)

**Verification.** The computational supplement contains the coefficients, vectors, signings, exact classical search and a second implementation of the new sign enumeration. Lean checks the vector lengths, the integer numerator, the value of the attaining signing and the strict decimal inequality. The exhaustive classical upper bound is verified by Python and C++. [Proof](PROOF.md) · [Reproduction instructions](README.md)

**AI use for this extension.** OpenAI Codex developed the expanded configurations, ran the numerical searches, and prepared the integer certificates, independent computational checks and Lean witness check.

**Acknowledgements.** Research reported in this paper was partially supported by the Berlin Mathematics Research Center MATH$^+$ (EXC-2046/2, project ID 390685689), funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany's Excellence Strategy. This work has been partially supported by OpenAI's Academic Researchers program.
