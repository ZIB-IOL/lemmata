"""Exhaust the signs of small split games and compare both new band algorithms."""
import itertools,random,subprocess,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def mask(a):return sum((s<0)<<i for i,s in enumerate(a))
def canonical(a,perms):
    vals=[]
    for p,s in perms:
        b=[0]*len(a)
        for i,v in enumerate(a):b[p[i]]=v*s[i]
        if b[0]<0:b=[-v for v in b]
        vals.append(mask(b))
    return min(vals)
def score(M,b):return sum(abs(sum(a*v for a,v in zip(row,b))) for row in M)
def put(path,A):path.write_text(''.join(' '.join(map(str,r))+'\n' for r in A))
def main():
    rng=random.Random(261127417);cases=0
    with tempfile.TemporaryDirectory() as name:
        tmp=Path(name);transform=tmp/'transpose';scorer=tmp/'scorer'
        for src,exe in [('bob_band.cpp',transform),('score_split.cpp',scorer)]:
            subprocess.run(['g++','-std=c++17','-O2','-fopenmp',str(HERE/src),'-o',str(exe)],check=True)
        for n in [5,6,7,8]:
            u=[rng.choice((-1,1)) for _ in range(n)];v=[rng.choice((-1,1)) for _ in range(n)]
            row=[rng.randint(-11,11) for _ in range(n)]
            K=[[u[i]*v[j]*row[(j-i)%n] for j in range(n)] for i in range(n)]
            rp=[];bp=[]
            for g in range(n):
                p=[(i+g)%n for i in range(n)]
                rp.append((p,[u[i]*u[p[i]] for i in range(n)]));bp.append((p,[v[j]*v[p[j]] for j in range(n)]))
            allsign=list(itertools.product((-1,1),repeat=n))
            vals=sorted(set(score(K,b) for b in allsign))
            for T in [vals[0]-1,vals[len(vals)//2],vals[-2]]:
                rows={}
                for a in allsign:
                    value=score(list(zip(*K)),a)
                    if value>T:rows[canonical(a,rp)]=value
                inp=[[n,n,n,len(rows),T],*K]
                for p,s in bp:inp.extend([p,s])
                inp.extend([[value,*[1-2*((bits>>i)&1) for i in range(n)]] for bits,value in rows.items()])
                put(tmp/'in',inp)
                subprocess.run([str(transform),str(tmp/'in'),str(tmp/'bob')],check=True,stdout=subprocess.DEVNULL)
                actual={int(k):int(t) for t,k,*_ in [line.split() for line in (tmp/'bob').read_text().splitlines()]}
                want={canonical(b,bp):score(K,b) for b in allsign if score(K,b)>T}
                assert actual==want
                # A signed neighboring-row transport yields a genuine cyclic orbit of extra settings.
                H=[list(r) for r in K]
                H.extend([[K[i][j]+u[i]*u[(i+1)%n]*K[(i+1)%n][j] for j in range(n)] for i in range(n)])
                Vmass=3
                G=[list(r) for r in H];gamma=rng.choice([1,2,3])
                for i in range(n):
                    G[i][i]+=gamma*u[i]*v[i]
                ht=T*Vmass
                eligible={canonical(b,bp):score(H,b) for b in allsign if score(H,b)>ht}
                if not eligible:continue
                put(tmp/'H',H);put(tmp/'G',G)
                report=subprocess.check_output([str(scorer),str(tmp/'G'),str(tmp/'H'),str(tmp/'bob'),str(ht),str(tmp/'new'),'2'],text=True)
                cnt,best,*_=map(int,report.split())
                out={int(k):int(t) for t,k,*_ in [line.split() for line in (tmp/'new').read_text().splitlines()]}
                assert out==eligible and cnt==len(eligible)
                true=max(score(G,b) for b in allsign)
                assert best==max(score(G,b) for b in allsign if score(H,b)>ht) and true<=max(best,ht+n*gamma)
                cases+=1
    print(f'All 12 transpositions matched exhaustive enumeration. {cases} nonempty split bands and their classical bounds matched the direct test.')
if __name__=='__main__':main()
