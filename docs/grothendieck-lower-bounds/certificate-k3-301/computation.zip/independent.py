"""Independently re-evaluate the sign lists and rational witness by dense dot products."""
import argparse
from fractions import Fraction
from pathlib import Path

import numpy as np

from certificate import PARENT, T, matrix, read, reconstruct


class ExactFields:
    def __init__(self, coefficients):
        radix = self.radix = 1 << 24
        a = np.array(coefficients, dtype=np.int64)
        high = a // radix
        low = a - high * radix
        hi_bound = max(sum(abs(int(v)) for v in row) for row in high)
        lo_bound = max(sum(abs(int(v)) for v in row) for row in low)
        assert hi_bound < 2**53 and lo_bound < 2**53
        assert radix * hi_bound + lo_bound < 2**63
        assert sum(abs(int(v)) for v in a.ravel()) < 2**63
        self.high = high.T.astype(float)
        self.low = low.T.astype(float)

    def __call__(self, signs):
        # Every binary64 dot product is exact since every signed partial sum is an integer below 2^53.
        return (signs @ self.high).astype('i8') * self.radix + (signs @ self.low).astype('i8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', type=Path)
    parser.add_argument('parentband', type=Path)
    args = parser.parse_args()
    _, _, k, h, m, mass, outside = reconstruct(PARENT, args.case)
    parent = np.loadtxt(args.parentband, dtype='uint64', ndmin=2)
    words = np.ascontiguousarray(parent[:, 1:].astype('<u8'))
    signs = 1 - 2 * np.unpackbits(words.view('u1'), axis=1, bitorder='little')[:, :len(k[0])].astype('i1')
    new = np.loadtxt(args.case / 'split-band.txt', dtype='uint64', ndmin=2)
    result = read(args.case / 'result.json')
    calibration = read(args.case / 'calibration.json')
    final = read(args.case / 'final.json')
    weight = calibration['remainder_weight']
    denominator = calibration['reference_weight']
    field_k, field_h, field_m = map(ExactFields, (k, h, m))
    offset = 0
    near = peak = -1
    for start in range(0, len(signs), 2500):
        b = signs[start:start + 2500].astype(float)
        records = parent[start:start + len(b)]
        assert np.array_equal(abs(field_k(b)).sum(axis=1), records[:, 0])
        hv = field_h(b)
        mv = field_m(b)
        scores = abs(hv).sum(axis=1)
        use = scores > mass * T
        block = new[offset:offset + sum(use)]
        assert np.array_equal(block[:, 1:], records[use, 1:])
        assert np.array_equal(block[:, 0], scores[use])
        offset += len(block)
        raw_scores = abs(mv).sum(axis=1)
        if (~use).any():
            assert int(raw_scores[~use].max()) <= outside
        if use.any():
            near = max(near, int(raw_scores[use].max()))
            calibrated = weight * mv[use].astype(object) + (denominator - weight) * hv[use].astype(object)
            peak = max(peak, int(abs(calibrated).sum(axis=1).max()))
    assert offset == len(new) == result['split_records']
    assert near == result['near_maximum']
    far = denominator * mass * T + weight * (outside - mass * T)
    assert far == Fraction(calibration['far_numerator'], calibration['far_denominator'])
    assert far <= peak == calibration['near'] == final['classical_lower']
    coefficients = np.array(matrix(args.case / 'matrix.txt'), dtype=object)
    assert np.array_equal(coefficients, weight * np.array(m, dtype=object) + (denominator - weight) * np.array(h, dtype=object))
    for name, data, coef, upper in [
        ('vectors.json', result, np.array(m, dtype=object), max(near, outside)),
        ('final-vectors.json', final, coefficients, peak),
    ]:
        vectors = read(args.case / name)
        d = vectors.get('denominator', vectors.get('vector_denominator'))
        x = np.array(vectors['alice'], dtype=object)
        y = np.array(vectors['bob'], dtype=object)
        assert x.shape == (len(m), 3) and y.shape == (len(k[0]), 3)
        assert ((x * x).sum(axis=1) <= d*d).all() and ((y * y).sum(axis=1) <= d*d).all()
        numerator = int((coef * (x @ y.T)).sum())
        assert numerator == data['quantum_numerator']
        assert Fraction(numerator, d*d) / upper > Fraction(data['strict_lower'])
    print('Dense exact dot products verified', len(parent), 'parent representatives,', len(new),
          'split representatives, the calibrated classical maximum and both rational vector numerators.')


if __name__ == '__main__':
    main()
