"""Bound an averaged reference embedding using the exact sign constraints created by merged settings."""
from functools import cache
import json
from pathlib import Path
import struct
from certificate import T, matrix, second_endpoint
from packed_scores import Scores

@cache
def parent_signs(root):
    k, _, ops = second_endpoint(root, matrix(root/'base.txt'), matrix(root/'lifted_matrix.txt'),
                                list(map(int,(root/'split_rows.txt').read_text().split())),matrix(root/'symmetry.txt'))
    records = [sum(w<<(32*i) for i,w in enumerate(r[1:])) for r in struct.iter_unpack('<6I',(root/'second/band.bin').read_bytes())]
    return k, ops, records, sign_columns(ops,records,len(k))

def sign_columns(ops,records,dimension):
    count = len(records)
    mask = (1<<count)-1
    # Bit r of a column records the sign at one source setting for parent record r.
    columns = [sum(((a>>i)&1)<<r for r,a in enumerate(records)) for i in range(dimension)]
    images = [0]*dimension
    for g,(p,s,_,_) in enumerate(ops):
        for i,j in enumerate(p):
            images[j] |= (columns[i] ^ (mask if s[i]<0 else 0)) << (count*g)
    return images

def normalize(v,support):
    return v^support if v & (support & -support) else v

@cache
def for_atom(root,action_json,atom_json):
    k, ops, records, images = parent_signs(Path(root))
    act, atom = json.loads(action_json), json.loads(atom_json)
    return bound(k,ops,records,images,act,atom,T)

def bound(k,ops,records,images,act,atom,cutoff,limit=256):
    rows, sr = atom['rows'],atom['row_signs']
    cols, sc = atom['columns'],atom['column_signs']
    assert atom['kind']=='reference' and len(rows)==len(sr)==len(k) and len(cols)==len(sc)==len(k[0])
    assert all(v in (-1,1) for v in sr+sc)
    assert all(0<=i<len(act[0][0]) for i in rows) and all(0<=j<len(k[0]) for j in cols)
    count=len(records)
    all_bits=(1<<(count*len(ops)))-1
    possible=all_bits
    first={}
    for i,target in enumerate(rows):
        if target in first:
            other=first[target]
            opposite=images[i]^images[other]
            possible &= opposite if sr[i]!=sr[other] else all_bits^opposite
        else:
            first[target]=i
    used=list(first)
    support=sum(1<<j for j in used)
    unique_cols={j:i for i,j in enumerate(sorted(set(cols)))}
    projected=[]
    for row in k:
        part=[0]*len(unique_cols)
        for x,j,s in zip(row,cols,sc):part[unique_cols[j]] += x*s
        projected.append(part)
    score=Scores(projected)
    highs={}
    # Iterating 32-bit chunks avoids repeatedly copying a 258,540-bit integer.
    chunks=possible.to_bytes((count*len(ops)+31)//32*4,'little')
    for pos,(word,) in enumerate(struct.iter_unpack('<I',chunks)):
        while word:
            bit=word & -word;word-=bit
            g,r=divmod(32*pos+bit.bit_length()-1,count)
            pa,sign,_,_=ops[g];a=records[r]
            source=sum((1<<j) for i,j in enumerate(pa) if ((a>>i)&1) != (sign[i]<0))
            value=score(source)
            if value>cutoff:
                assignment=sum(1<<j for j,i in first.items() if ((source>>i)&1)!=(sr[i]<0))
                key=normalize(assignment,support)
                assert highs.get(key,value)==value
                highs[key]=value
    if not highs:return cutoff
    ceiling=cutoff
    if len(highs)>limit:
        ceiling=sorted(highs.values(),reverse=True)[limit]
        highs={key:v for key,v in highs.items() if v>ceiling}
    # After orienting a largest term at the identity, every other term shares its signs on the overlap.
    totals={key:0 for key in highs}
    for p,s in act:
        rotated_support=sum(1<<p[j] for j in used)
        overlap=support & rotated_support
        lookup={}
        for key,value in highs.items():
            rotated=sum(1<<p[j] for j in used if ((key>>j)&1)!=(s[j]<0))
            common=normalize(rotated & overlap,overlap)
            lookup[common]=max(lookup.get(common,ceiling),value)
        for key,value in highs.items():
            common=normalize(key & overlap,overlap)
            totals[key]+=min(value,lookup.get(common,ceiling))
    best=max([len(act)*ceiling,*totals.values()])
    return (best+len(act)-1)//len(act)

def encoding(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'))

def cap(root,action,atom):
    return for_atom(root,encoding(action),encoding(atom))
