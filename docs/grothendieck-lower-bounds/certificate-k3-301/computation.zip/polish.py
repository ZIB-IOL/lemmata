"""Check the strongest explicit matrix, and enclose its optimum in every real vector dimension."""
import argparse
from decimal import Decimal,localcontext
from fractions import Fraction as F
from pathlib import Path
import sys
from certificate import PARENT,HERE,read,dump,put,matrix,reconstruct

def final_matrix(case):
    w=read(case/'calibration.json');p=w['remainder_weight'];q=w['reference_weight']
    _,_,_,H,M,_,_=reconstruct(PARENT,case)
    return [[q*y+p*(x-y) for x,y in zip(row,h)] for row,h in zip(M,H)]

def process(case,build=False):
    sys.path.insert(0,str(PARENT))
    from fixed_matrix import refine,propose,bound
    m=final_matrix(case);cal=read(case/'calibration.json');C=cal['near'];far=F(cal['far_numerator'],cal['far_denominator']);upper_c=max(F(C),far)
    if build:
        put(case/'matrix.txt',m)
        old=read(case/'vectors.json');D=10**40;N,X,Y=refine(m,old['alice'],denominator=D,steps=140)
        dc=propose(m,X,Y,D)
        dump(case/'vector-upper.json',dc);dump(case/'final-vectors.json',{'denominator':D,'alice':X,'bob':Y})
    else:
        assert m==matrix(case/'matrix.txt')
        w=read(case/'final-vectors.json');D,X,Y=w['denominator'],w['alice'],w['bob'];dc=read(case/'vector-upper.json')
    assert type(D) is int and D>0 and len(X)==len(m) and len(Y)==len(m[0])
    assert all(len(x)==3 and all(type(t) is int for t in x) and sum(t*t for t in x)<=D*D for x in X+Y)
    N=sum(t*sum(a*b for a,b in zip(x,y)) for row,x in zip(m,X) for t,y in zip(row,Y))
    lower=F(N,D*D)/upper_c;upper=bound(m,dc,C);gap=upper-lower
    assert lower>=F(cal['quantum_numerator'],read(case/'vectors.json')['vector_denominator']**2)/upper_c and gap>=0
    strict=lower.numerator*10**16//lower.denominator
    data={'strict_lower':f'{strict//10**16}.{strict%10**16:016d}','quantum_numerator':N,'vector_denominator':D,
          'classical_lower':C,'classical_upper_numerator':upper_c.numerator,'classical_upper_denominator':upper_c.denominator,
          'fixed_matrix_upper_numerator':upper.numerator,'fixed_matrix_upper_denominator':upper.denominator}
    assert lower>F(data['strict_lower'])
    if build:dump(case/'final.json',data)
    else:assert read(case/'final.json')==data
    with localcontext() as ctx:
        ctx.prec=55
        print('Strict rank-three bound',data['strict_lower'],'witness ratio',Decimal(lower.numerator)/Decimal(lower.denominator),
              'all-dimensional fixed-matrix gap',Decimal(gap.numerator)/Decimal(gap.denominator),'attained classical maximum',upper_c==C,flush=True)
    return lower,upper
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);ap.add_argument('--build',action='store_true');o=ap.parse_args();process(o.case,o.build)
