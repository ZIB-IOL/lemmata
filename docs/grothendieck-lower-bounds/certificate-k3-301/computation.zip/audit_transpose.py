"""Check the complete Bob list by covering all high sign pairs, including nonmaximizing Alice signs."""
import argparse
from operator import xor
from pathlib import Path
import struct
import numpy as np

from certificate import PARENT, T, matrix


def read_keys(path, word_count):
    rows = np.loadtxt(path, dtype='<u8', ndmin=2)
    words = np.ascontiguousarray(rows[:, 1:].astype('>u8'))
    assert words.shape[1] == word_count
    result = {int.from_bytes(row.tobytes(), 'big') for row in words}
    assert len(result) == len(rows)
    return result


def verify(path):
    k = np.array(matrix(PARENT / 'second/endpoint.txt'), dtype='i8')
    n, m = k.shape
    word_count = (m+63)//64
    supplied = read_keys(path, word_count)
    maps = matrix(PARENT / 'symmetry.txt')
    permutations = np.array(maps[4::4], dtype=int)
    negations = np.array(maps[5::4]) < 0
    elements = np.arange(len(permutations))[:, None]
    assert n <= 160 and word_count == 6
    # The C++ key orders six unsigned words lexicographically, with low direction indices in its first word.
    bits = [1 << (64*(word_count-1-j//64)+j%64) for j in range(m)]
    full = sum(bits)
    changes = [[bits[destination] ^ (full if destination == 0 else 0) for destination in col]
               for col in permutations.T]
    assert sum(abs(int(v)) for v in k.ravel()) < 2**63
    found = set()
    checked_pairs = 0
    for half_score, *words in struct.iter_unpack('<6I', (PARENT / 'second/band.bin').read_bytes()):
        row_mask = sum(w << (32*i) for i, w in enumerate(words))
        a = np.array([1-2*((row_mask>>i)&1) for i in range(n)], dtype='i8')
        h = a @ k
        best = int(abs(h).sum())
        assert best == 2 * half_score > T
        image = np.empty_like(negations)
        image[elements, permutations] = (h[None, :] < 0) ^ negations
        signed = image ^ image[:, :1]
        packed = np.packbits(signed, axis=1, bitorder='little')
        padded = np.pad(packed, ((0,0),(0,8*word_count-packed.shape[1])))
        words = np.ascontiguousarray(padded).view('<u8').astype('>u8')
        keys = [int.from_bytes(r.tobytes(),'big') for r in words]
        # A partial subset and its sign-flipped extension are valid if their exact budget permits.
        # Process the largest costs first. Each distinct subset is emitted once, when its final flip is added.
        room = (best-T-1)//2
        available = sorted(((abs(int(v)),j) for j,v in enumerate(h) if abs(int(v))<=room), reverse=True)
        def cover(position, budget, images):
            count = 1
            key = min(images)
            assert key in supplied
            found.add(key)
            for index in range(position,len(available)):
                cost, j = available[index]
                if cost <= budget:
                    count += cover(index+1,budget-cost,list(map(xor,images,changes[j])))
            return count
        checked_pairs += cover(0,room,keys)
    assert found == supplied
    print('All', checked_pairs, 'strictly high pairs covered exactly the supplied',len(found),'Bob classes.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('parentband',type=Path)
    verify(parser.parse_args().parentband)
