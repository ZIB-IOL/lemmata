"""Signed embeddings of two already certified games into a larger set of directions."""
from fractions import Fraction as F
def source(root,tag,w,K):
    if tag=='reference':return K,w['reference_classical']
    assert tag=='compact'
    from cover import matrix
    M=matrix(root/'second/matrix.txt');q=w['scale_denominator']
    def rounded(v):return (1 if v>=0 else -1)*((abs(v)+q//2)//q)
    S=[[rounded(x) for x in row] for row in M]
    err=sum(abs(q*y-x) for r,h in zip(M,S) for x,y in zip(r,h))
    upper=(F(w['classical_upper_numerator'],w['classical_upper_denominator'])+err)/q
    return S,-(-upper.numerator//upper.denominator)
def compute_numpy(src,cap,desc,idx,sg,bad,ids):
    import numpy as np
    ia,sa,ib,sb=[np.array(desc[t]) for t in ('rows','row_signs','columns','column_signs')]
    raw=np.zeros(idx.shape,dtype=np.int64);np.add.at(raw,(ia[:,None],ib[None,:]),src*sa[:,None]*sb)
    val=np.bincount(idx.ravel(),weights=(sg*raw).ravel()).astype(np.int64);freq=np.bincount(idx.ravel())
    rounded=np.sign(val)*((abs(val)+freq//2)//freq)
    err=abs(val-freq*rounded);err[list(bad)]=0;rounded[list(bad)]=0
    return rounded[ids],int(cap+sum(err))
