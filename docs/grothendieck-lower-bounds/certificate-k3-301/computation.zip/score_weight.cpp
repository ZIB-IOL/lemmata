// Score an integer interpolation of two verified matrices on the split band.
#define SPLIT_TABLE_ONLY
#include "score_split.cpp"
std::string wide_string(Wide x){
    if(x==0)return "0";bool negative=x<0;if(negative)x=-x;std::string s;
    while(x){s.push_back(char('0'+x%10));x/=10;}if(negative)s.push_back('-');
    std::reverse(s.begin(),s.end());return s;
}
int main(int argc,char** argv){try{
    require(argc==7,"usage: score_weight matrix reference band scale weight threads");
    auto x=read_matrix(argv[1]),h=read_matrix(argv[2]);require(x.size()==h.size()&&x.front().size()==h.front().size(),"mismatched matrices");
    Table X(x),H(h);I den=std::stoll(argv[4]),w=std::stoll(argv[5]);int nt=std::stoi(argv[6]);
    require(den>0&&w>=0&&den<=10000000000000LL&&w<=20000000000000LL&&nt>0&&nt<=128,"invalid coefficients");
    std::ifstream in(argv[3]);std::vector<Mask> bs;I t;Mask mask;
    while(in>>t){for(auto& v:mask)require(bool(in>>v),"invalid band");bs.push_back(mask);}
    require(in.eof()&&!bs.empty(),"empty band");std::vector<Wide> vals(bs.size());
    #pragma omp parallel num_threads(nt)
    {
        Row a(X.stride),b(H.stride);
        #pragma omp for schedule(static)
        for(size_t i=0;i<bs.size();++i){X(bs[i],a);H(bs[i],b);Wide z=0;
            for(int j=0;j<X.n;++j){Wide v=Wide(den-w)*b[j]+Wide(w)*a[j];z+=v<0?-v:v;}
            vals[i]=z;
        }
    }
    size_t id=std::max_element(vals.begin(),vals.end())-vals.begin();std::cout<<wide_string(vals[id]);for(auto v:bs[id])std::cout<<' '<<v;std::cout<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
