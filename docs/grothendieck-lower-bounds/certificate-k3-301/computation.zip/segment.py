"""A rational upper bound for all positive mixtures of two explicit matrices, allowing vectors of any dimension."""
from fractions import Fraction as F
import argparse
from pathlib import Path
from certificate import PARENT,read,matrix

def upper_on_segment(first,second):
    from fixed_matrix import bound as gram_bound
    cases=(first,second)
    matrices=[matrix(case/'matrix.txt') for case in cases]
    v=[read(case/'final.json') for case in cases]
    c=[t['classical_lower'] for t in v]
    u=[F(t['fixed_matrix_upper_numerator'],t['fixed_matrix_upper_denominator']) for t in v]
    for m,case,ct,expected in zip(matrices,cases,c,u):
        assert gram_bound(m,read(case/'vector-upper.json'),ct)==expected
    lines=[]
    for i,case in enumerate(cases):
        mask=read(case/'calibration.json')['mask']
        b=[1-2*((mask[j//64]>>(j%64))&1) for j in range(len(matrices[i][0]))]
        fields=[[sum(x*t for x,t in zip(row,b)) for row in m] for m in matrices]
        a=[1 if (x if x else y)>=0 else -1 for x,y in zip(fields[i],fields[1-i])]
        p,q=[F(sum(x*t for x,t in zip(ff,a)),z) for ff,z in zip(fields,c)]
        assert (p,q)[i]==1
        assert min(p,q)>0
        lines.append((p,q))
    (a,b),(d,e)=lines
    if a-b-d+e:
        cross=(a-d)/(a-b-d+e)
        times=[0,1]+([cross] if 0<cross<1 else [])
    else:times=[0,1]
    def bound(t):return ((1-t)*u[0]+t*u[1])/max((1-t)*p+t*q for p,q in lines)
    return max(bound(t) for t in times),max(u),lines

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('first',type=Path);ap.add_argument('second',type=Path);o=ap.parse_args()
    up,best,lines=upper_on_segment(o.first,o.second)
    print('Certified segment upper',up,'headroom over the stronger endpoint vector upper',up-best,
          'approximate segment upper',float(up),flush=True)
