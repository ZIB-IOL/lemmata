"""Regenerate the complete column band from the old verified row band."""
import argparse
from pathlib import Path
import struct,subprocess,tempfile
T=641519292
def rows(path):return [list(map(int,line.split())) for line in path.read_text().splitlines() if line.strip()]
def run(root,out,exe=None):
    root=Path(root);out=Path(out)
    K=rows(root/'second/endpoint.txt');sym=rows(root/'symmetry.txt');n=len(K);m=len(K[0])
    rec=list(struct.iter_unpack('<6I',(root/'second/band.bin').read_bytes()))
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        if not exe:
            exe=tmp/'transpose'
            subprocess.run(['g++','-std=c++17','-O3',str(Path(__file__).with_name('bob_band.cpp')),'-o',str(exe)],check=True)
        with (tmp/'input').open('w') as f:
            print(n,m,(len(sym)-2)//4,len(rec),T,file=f)
            for row in K:print(*row,file=f)
            for g in range(2,len(sym),4):
                print(*sym[g+2],file=f);print(*sym[g+3],file=f)
            for score,*words in rec:
                a=[1-2*((words[i//32]>>(i%32))&1) for i in range(n)]
                print(2*score,*a,file=f)
        subprocess.run([str(exe),str(tmp/'input'),str(out)],check=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);o=p.parse_args();run(o.root,o.out)
