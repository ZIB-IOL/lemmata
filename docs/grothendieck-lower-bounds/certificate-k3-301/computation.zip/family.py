"""Upper bound for the search family's certificate ratio with the displayed directions fixed."""
from fractions import Fraction as F
from math import isqrt,lcm
from pathlib import Path
import argparse,json,struct

from certificate import HERE,PARENT,T,matrix,read,dump
from dictionary import embedded,layout
from embedding_atoms import source
from group_atoms import regenerate_groups


def ceil_sqrt(n):
    v=isqrt(n)
    return v+(v*v<n)


def projected_difference(x,y,D,ops,weights,wd,alice,bob):
    n,m=len(x),len(y)
    assert len(weights)==len(alice)==len(bob)
    assert all(type(v) is int and v>=0 for v in weights) and sum(weights)<2**63
    assert all(len(row)==n and all(v in (-1,1) for v in row) for row in alice)
    assert all(len(row)==m and all(v in (-1,1) for v in row) for row in bob)
    def pack(row):
        value=0
        for k in reversed(row):value=value*2**64+k
        return value
    half=2**63
    offset=pack([half]*m)
    terms=[w*pack(b) for w,b in zip(weights,bob)]
    unpack=struct.Struct('<'+'Q'*m).unpack
    den=lcm(D*D,wd);dv,ds=den//(D*D),den//wd
    raw=[]
    for i,(a,b,c) in enumerate(x):
        coded=offset+sum(aa[i]*z for aa,z in zip(alice,terms))
        signs=unpack(coded.to_bytes(8*m,'little'))
        raw.append([(a*r+b*s+c*t)*dv-(value-half)*ds for (r,s,t),value in zip(y,signs)])
    total=len(ops)
    out=[[0]*m for _ in range(n)]
    for orbit in layout(ops,n,m):
        numerator=sum(raw[i][j]*s for i,j,s in orbit)
        scale,rem=divmod(total,len(orbit));assert rem==0
        for i,j,s in orbit:out[i][j]=s*scale*numerator
    return out,den*total


def prices(case,cert,root=PARENT):
    w=read(root/'second/witness.json')
    k=matrix(root/'second/endpoint.txt')
    v=read(case/'final-vectors.json');x=v['alice'];y=v['bob'];D=v['denominator'];n=len(x);m=len(y)
    assert all(len(row)==3 and sum(t*t for t in row)<=D*D for row in x+y)
    sym=matrix(root/'symmetry.txt');act=read(case/'symmetry.json')
    ops=[(p,s,sym[4+4*g],sym[5+4*g]) for g,(p,s) in enumerate(act)]
    wd=cert['weight_denominator'];fd=cert['factor_denominator'];weights=cert['weights']
    assert type(wd) is int and type(fd) is int and min(wd,fd)>0
    Z,den=projected_difference(x,y,D,ops,weights,wd,cert['alice'],cert['bob'])
    row_factor,col_factor=cert['row_factor'],cert['column_factor']
    assert len(row_factor)==n and len(col_factor)==m
    assert len({len(a) for a in row_factor+col_factor})==1 and all(type(z) is int for row in row_factor+col_factor for z in row)
    maxrow=max(sum(t*t for t in a) for a in row_factor);maxcol=max(sum(t*t for t in b) for b in col_factor)
    f2=fd*fd
    max_error=max(abs(z*f2-den*sum(i*j for i,j in zip(a,b))) for a,r in zip(row_factor,Z) for z,b in zip(r,col_factor))
    factor_price=F(ceil_sqrt(maxrow*maxcol),f2)+F(ceil_sqrt(n)*max_error,den*f2)
    # The maximizing destination can be chosen separately for each source column of the transport.
    tr=sum(max(abs(sum(a*b for a,b in zip(src,r))) for r in Z) for src in k)
    transport=F(tr,den*T)
    def product(A):
        return sum(sum(v*z for v,z in zip(a,r)) for a,r in zip(A,Z))
    groups,costs=regenerate_groups(root,'blocks24')
    group_price=max(F(product(A),den*c) for A,c in zip(groups,costs) if c)
    assert all(c or all(not any(row) for row in A) for A,c in zip(groups,costs))
    spec=read(case/'parameters.json')
    assert spec['groups']=='blocks24' and spec['separate_old_delta'] and not spec.get('extra_games')
    dictionary=cert['embeddings']
    pool=HERE/'discovery/filled-emb.json'
    if not pool.exists():pool=HERE/'filled-emb.json'
    assert dictionary==read(pool)
    assert {json.dumps(a,sort_keys=True) for a,u in spec['extra_embeddings']} <= {json.dumps(a,sort_keys=True) for a in dictionary}
    sources={tag:source(root,tag,w,k) for tag in {a['kind'] for a in dictionary}}
    emb_price=F(0)
    for a in dictionary:
        src,cap=sources[a['kind']]
        if a['kind']=='reference':cap=T
        A,c=embedded(src,ops,a,n,m,cap)
        emb_price=max(emb_price,F(product(A),den*c))
    upper=F(sum(weights),wd)+max(F(0),factor_price,transport,group_price,emb_price)
    return upper,dict(vector=factor_price,transport=transport,groups=group_price,embeddings=emb_price)


def check(case):
    cert=read(case/'family.json');upper,p=prices(case,cert)
    assert upper==F(cert['upper_numerator'],cert['upper_denominator']) and upper<F(cert['decimal_upper'])
    v=read(case/'final.json')
    actual=F(v['quantum_numerator']*v['classical_upper_denominator'],v['vector_denominator']**2*v['classical_upper_numerator'])
    assert F(v['strict_lower'])<actual<=upper
    print('Fixed-direction certificate-family upper',cert['decimal_upper'],'for',len(cert['embeddings']),'listed embeddings.',flush=True)
    return upper

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);check(ap.parse_args().case)
