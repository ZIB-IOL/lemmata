"""Rebuild a new Alice-orbit split and certify its classical and three-dimensional scores."""
from math import isqrt
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
import argparse,hashlib,json,os,struct,subprocess,sys,tempfile

HERE=Path(__file__).resolve().parent
PARENT=HERE/'parent'
sys.path.insert(0,str(PARENT))
from cover import matrix
from band_certificate import second_endpoint,norm
from dictionary import layout
T=641519292

def dump(path,x):path.write_text(json.dumps(x,separators=(',',':'))+'\n')
def read(p):return json.loads(p.read_text())
def put(path,x):
    with path.open('w') as f:
        for row in x:print(*row,file=f)

def parent_data(root):
    w=read(root/'second/witness.json');K=matrix(root/'second/endpoint.txt');M=matrix(root/'second/matrix.txt')
    W=matrix(root/'second/transport.txt');t=w['transport_mass'];assert all(v==(t if i==j else 0) for i,r in enumerate(W) for j,v in enumerate(r))
    R=[[x-t*y for x,y in zip(row,k)] for row,k in zip(M,K)]
    U=F(w['outside_numerator'],w['outside_denominator'])-T*t
    return w,K,R,U

def reconstruct(root,work):
    spec=read(work/'parameters.json');w,K,R,U=parent_data(root);V=matrix(work/'transport.txt')
    q=spec['scale'];Q=w['scale_denominator'];z=spec['old_remainder'];d=spec['delta_denominator'];n=len(K);m=len(K[0]);nr=len(V)
    assert all(type(v) is int for v in (q,z,d)) and q>0 and d>0 and q%d==0 and z>=0
    assert nr>n and all(len(v)==n for v in V)
    D=matrix(work/'delta.txt')
    assert len(D)==nr and all(len(row)==m for row in D)
    separated=spec.get('separate_old_delta',False)
    if separated:
        p=w['delta_denominator'];old=matrix(root/'second/delta.txt')
        for row,delta in zip(R,old):
            for j,x in enumerate(delta):row[j]-=Q//p*x
        U-=F(Q*read(root/'second/norm.json')['upper'],p)
    if spec.get('groups'):
        from group_atoms import regenerate_groups
        G,C=regenerate_groups(root,spec['groups'])
        for block in G:
            for row,h in zip(R,block):
                for j,v in enumerate(h):row[j]-=v
        U-=sum(C)
    else:G=[];C=[]
    assert U>=0
    if separated and G:
        assert U==0 and all(not any(row) for row in R)
    N=norm(D,read(work/'norm.json')) if any(any(row) for row in D) else 0
    sparse=[[(i,x) for i,x in enumerate(row) if x] for row in V]
    H=[[sum(x*K[i][j] for i,x in terms) for j in range(m)] for terms in sparse]
    def rounded(a):return (1 if a>=0 else -1)*((abs(a)+Q//2)//Q)
    weight=spec.get('group_weights',[])
    assert all(type(u) is int and u>=0 for u in weight) and len(weight)==len(G)
    M=[];error=0
    for i,(h,delta) in enumerate(zip(H,D)):
        row=[]
        for j,(v,e) in enumerate(zip(h,delta)):
            raw=(z*R[i][j]+sum(u*g[i][j] for u,g in zip(weight,G))) if i<n else 0
            r=rounded(raw);error+=abs(Q*r-raw)
            row.append(v+(q//d)*e+r)
        M.append(row)
    new_budget=0
    if spec.get('extra_games') or spec.get('extra_embeddings'):
        from games import changes
        parent_sym=matrix(root/'symmetry.txt');act=read(work/'symmetry.json')
        ops=[(p,s,parent_sym[4+4*j],parent_sym[5+4*j]) for j,(p,s) in enumerate(act)]
        terms=[]
        for seed,value in spec.get('extra_games',[]):
            i,k,j,l,v,u=seed
            terms.append(dict(numerator=value,classical=2,entries=[[i,j,v],[k,j,v],[i,l,u],[k,l,-u]]))
        additional,new_budget=changes(ops,terms,nr,m)
        for row,g in zip(M,additional):
            for j,v in enumerate(g):row[j]+=v
    if spec.get('extra_embeddings'):
        from dictionary import embedded
        from embedding_atoms import source
        cache={}
        for atom,u in spec['extra_embeddings']:
            assert type(u) is int and u>=0
            if atom['kind'] not in cache:cache[atom['kind']]=source(root,atom['kind'],w,K)
            S,cap=cache[atom['kind']]
            if spec.get('collision_caps') and atom['kind']=='reference':
                from collision_caps import cap as collision_bound
                cap=min(cap,collision_bound(root,act,atom))
            A,c=embedded(S,ops,atom,nr,m,cap)
            for row,h in zip(M,A):
                for j,v in enumerate(h):row[j]+=u*v
            new_budget+=u*c
    mass=max(sum(map(abs,col)) for col in zip(*V))
    outside=new_budget+mass*T+(z*U+sum(u*c for u,c in zip(weight,C))+error)/Q+F(q*N,d)
    return spec,w,K,H,M,mass,outside

def equivariance(root,spec,K,H,M,work):
    pp=matrix(root/'symmetry.txt');I=list(map(int,(root/'split_rows.txt').read_text().split()))
    _,_,ops=second_endpoint(root,matrix(root/'base.txt'),matrix(root/'lifted_matrix.txt'),I,pp)
    act=read(work/'symmetry.json');V=matrix(work/'transport.txt');ops2=[]
    for (pa,sa,pb,sb),(p,s) in zip(ops,act):
        assert sorted(p)==list(range(len(M))) and len(s)==len(p) and all(v in (-1,1) for v in s)
        assert p[:len(K)]==pa and s[:len(K)]==sa
        # Verify commutation directly. Then the same source symmetries act on every new band.
        assert all(V[p[i]][pa[j]]==s[i]*sa[j]*v for i,row in enumerate(V) for j,v in enumerate(row))
        assert all(M[p[i]][pb[j]]==s[i]*sb[j]*v for i,row in enumerate(M) for j,v in enumerate(row))
        ops2.append((p,s,pb,sb))
    assert len(ops)==len(act) and len(ops)==60
    layout(ops2,len(M),len(M[0]))
    return ops2

def evaluate_bob(K,H,M,work,parent_band,mass,threads,exe):
    with tempfile.TemporaryDirectory() as name:
        tmp=Path(name);put(tmp/'M.txt',M);put(tmp/'H.txt',H)
        words=subprocess.check_output([str(exe),str(tmp/'M.txt'),str(tmp/'H.txt'),str(parent_band),str(mass*T),str(tmp/'new.txt'),str(threads)],text=True).split()
        data=(tmp/'new.txt').read_bytes()
    count,near,*mask=map(int,words)
    assert len(mask)==6 and count>0
    b=[1-2*((mask[j//64]>>(j%64))&1) for j in range(len(K[0]))]
    assert sum(abs(sum(x*y for x,y in zip(row,b))) for row in M)==near
    return count,near,mask,data

def ratio_for(M,outside,near,w):
    X=w['alice'];Y=w['bob'];D=w['vector_denominator']
    assert len(X)==len(M) and len(Y)==len(M[0]) and type(D) is int and D>0
    assert all(len(v)==3 and all(type(t) is int for t in v) and sum(t*t for t in v)<=D*D for v in X+Y)
    N=sum(k*sum(a*b for a,b in zip(x,y)) for row,x in zip(M,X) for k,y in zip(row,Y))
    return N,F(N,D**2)/max(outside,F(near))

def calc(root,work,parent_band,exe,threads=4,build=False):
    spec,w,K,H,M,mass,outside=reconstruct(root,work);equivariance(root,spec,K,H,M,work)
    count,near,mask,data=evaluate_bob(K,H,M,work,parent_band,mass,threads,exe)
    if build: (work/'split-band.txt').write_bytes(data)
    else:assert (work/'split-band.txt').read_bytes()==data
    a=read(work/'vectors.json');N,rate=ratio_for(M,outside,near,a);lower=rate.numerator*10**16//rate.denominator
    report=dict(rows=len(M),columns=len(M[0]),transport_mass=mass,threshold=mass*T,split_records=count,
                near_maximum=near,attaining_bob_mask=mask,outside_numerator=outside.numerator,outside_denominator=outside.denominator,
                quantum_numerator=N,strict_lower=f'{lower//10**16}.{lower%10**16:016d}')
    assert rate>F(report['strict_lower'])
    if build:dump(work/'result.json',report)
    else:assert read(work/'result.json')==report
    with localcontext() as ctxt:
        ctxt.prec=50
        print('split records',count,'near',near,'outside',outside,'ratio',Decimal(rate.numerator)/Decimal(rate.denominator),flush=True)
    return report

if __name__=='__main__':
    from transpose_band import run
    from construction.rebuild import rebuild
    from band_certificate import signed
    if not __debug__:raise RuntimeError('Run Python with assertions enabled.')
    p=argparse.ArgumentParser();p.add_argument('--case',type=Path,default=HERE/'witness');p.add_argument('--threads',type=int,default=4)
    p.add_argument('--from-scratch',action='store_true',help='also regenerate the archived parent Alice list')
    args=p.parse_args();root=PARENT
    assert 1<=args.threads<=128
    manifest=HERE/'SHA256SUMS.json'
    if manifest.is_file():
        for path,expected in read(manifest).items():
            assert hashlib.sha256((HERE/path).read_bytes()).hexdigest()==expected,path
    if args.from_scratch:
        subprocess.run([sys.executable,'-B',str(root/'verify_strongest.py'),'--threads',str(args.threads)],check=True)
    w=read(root/'second/witness.json');base=matrix(root/'base.txt');first=rebuild();idx=list(map(int,(root/'split_rows.txt').read_text().split()));sym=matrix(root/'symmetry.txt')
    assert T==2*(320975646-w['reference_margin'])
    signed(w,root,base,first,idx,sym,root/'second/band.bin')
    with tempfile.TemporaryDirectory() as name:
        t=Path(name);run(root,t/'parent-bob.txt');exe=t/'score_split'
        subprocess.run(['g++','-std=c++17','-O3','-fopenmp',str(HERE/'score_split.cpp'),'-o',str(exe)],check=True)
        calc(root,args.case,t/'parent-bob.txt',exe,args.threads)
        if (args.case/'calibration.json').exists():
            from calibrate import process
            xe=t/'score_weight';subprocess.run(['g++','-std=c++17','-O3','-fopenmp',str(HERE/'score_weight.cpp'),'-o',str(xe)],check=True)
            process(args.case,xe,args.threads)
            result='calibration.json'
            if (args.case/'final.json').is_file():
                from polish import process as check_final
                check_final(args.case)
                result='final.json'
                if (args.case/'family.json').is_file():
                    from family import check
                    check(args.case)
            print('Verified K_G(3) >', read(args.case/result)['strict_lower'],flush=True)
