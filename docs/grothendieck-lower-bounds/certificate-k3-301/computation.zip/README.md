# A lower bound for the real Grothendieck constant of order three

An explicit 301 by 321 integer matrix gives **$K_G(3)>1.4397098471655953$**. Its classical maximum is exactly 641951269303647081416258863417. Rational triples with common denominator $10^{40}$ give a ratio beginning 1.4397098471655953648981198686680622. For this particular matrix, the vector optimum even in arbitrary real dimension exceeds the exhibited ratio by less than $7.2\times 10^{-35}$.

[Read the proof](PROOF.md) · [Integer matrix](witness/matrix.txt) · [Rational triples](witness/final-vectors.json) · [Exact result](witness/final.json)

The conjecture of Vijay Bhattiprolu and Otte Heinävaara is $K_G(3)=1/\ln 2$, approximately $1.442695040889$. The present lower bound is about 0.002985194 below this value. Under projective measurements the two-qubit Werner critical visibility is $1/K_G(3)$. [Heinävaara, §3.15](https://web.math.princeton.edu/~oeh/research_statement_Otte.pdf) · [Acín, Gisin and Toner](https://arxiv.org/abs/quant-ph/0606138)

## Verify the bound

From the extracted directory, run the following command with Python 3 and a C++17 compiler supporting OpenMP and 128-bit integers. The tested compiler is GCC on 64-bit Linux. The verifier uses the Python standard library and compiles its own executables. Run Python with assertions enabled.

```sh
python3 -B certificate.py --threads 4
```

The command checks the archive hashes, verifies the parent certificate against its stored 4,309 Alice sign records, regenerates the 625,968 Bob representatives, rebuilds the 101,967-record list for the new matrix, and checks the attained classical maximum, rational numerator and fixed-matrix vector upper bound.

To regenerate the 4,309 parent Alice records as well, run the longer command below. This traces the search back to the 81 by 321 base matrix, verifies its suffix bounds, enumerates 7,832,114 base records above the required cutoff, and transfers them to the 141-row reference. This is the computationally expensive part.

```sh
python3 -B certificate.py --from-scratch --threads 4
```

## Independent checks

The next two checks use NumPy. The first covers every one of the 811,958 eligible sign pairs by a second implementation that keeps nonmaximizing Alice signs as well. The second recomputes all 625,968 parent scores with dense dot products. It independently checks the new list, the calibrated maximum and the vector numerator of the distributed matrix. The last two commands run exhaustive tests on small signed games using Python and GCC.

```sh
OPENBLAS_NUM_THREADS=1 python3 -B audit_transpose.py discovery/parent-column-band.txt
OPENBLAS_NUM_THREADS=1 python3 -B independent.py witness discovery/parent-column-band.txt
python3 -B test_bands.py
python3 -B test_collision.py
```

Lean 4.35.0 also reads the matrix, checks the vector lengths and exact objective, evaluates the attaining signing, and proves the strict decimal comparison. Its input is the same plain-text matrix used by the other verifiers. The exhaustive classical upper bound is checked by the Python and C++ computation above.

```sh
(cd lean && lean CheckWitness.lean)
```

## Rebuild the search result

The `discovery` directory contains the numerical search, its seed configurations, priced comparison games, intermediate checkpoints, solver logs and the exact checkpoint selected for this witness. The search was run with Python 3.12.14. Use the versions in `discovery/requirements.txt` for a numerical replay. The main verifier works directly from the integer data.

To reconstruct the witness from its saved numerical checkpoint in a fresh output directory, run the following from the archive root.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
g++ -O3 -std=c++17 -fopenmp score_split.cpp -o discovery/score_split
python3 -B discovery/build.py discovery/winning/best.npz rebuilt --tight
python3 -B calibrate.py rebuilt --build --threads 4
python3 -B polish.py rebuilt --build
python3 -B certificate.py --case rebuilt --threads 4
```

To rerun the winning search itself, first run `python3 -B discovery/setup.py` to unpack the reference sign matrix. Then use the command below. Numerical solvers and linear algebra libraries can follow different paths on different machines. The stored checkpoint fixes the input for the integer reconstruction.

```sh
python3 -B discovery/split_fit.py --theta 9 --character 0 --also 22 0 6 --holes discovery/holes.json --indices 0 1 2 --sdp --grouped --embeddings discovery/filled-emb.json --cap-table discovery/cap-table.json --start discovery/start-settled/best.npz --accelerate 1 --rounds 14 --stall 0.0000001 --out new-search
```

`witness/calibration.json` encodes the attaining Bob signing in six unsigned words. Bit $j\bmod64$ of word $\lfloor j/64\rfloor$ is one precisely when the $j$th sign is $-1$, with indices starting at zero. `witness/final.json` gives both sides of the fixed-matrix interval as exact integers or rational numbers.

## The limit with these directions held fixed

A separate certificate puts the fixed-vector score below 1.4397119 for the 24 comparison groups, 128 listed embeddings, arbitrary row transports, and semidefinite perturbation bound used here. This ceiling applies under the denominator rules in the final section of the proof. The main command verifies it alongside the lower bound. To check this part alone, run `python3 -B family.py witness`.

The numerical weights used for this ceiling are included in `discovery/winning/family-prices.npz`. To rebuild the family certificate after reconstructing the witness, run the following.

```sh
OPENBLAS_NUM_THREADS=1 python3 -B discovery/discover_family.py rebuilt discovery/winning --prices discovery/winning/family-prices.npz
python3 -B family.py rebuilt
```

An earlier set of 301 directions had a certified ceiling of 1.4397076 under the same rules. Its directions, dual weights and certificate are included for comparison. Run `python3 -B family.py discovery/first-301-ceiling` to verify that earlier ceiling.

## Comparing the two best matrices

To check an all-dimensional upper bound on the score ratio of every positive linear combination of the two finalists, run `python3 -B segment.py witness discovery/second-finalist`. The check evaluates each finalist's attaining sign pair on both matrices, bounds the vector numerator by convexity, and maximizes the resulting quotient of affine functions on the unit interval. The exact result is in [the comparison log](checks/final-segment.log).
