// Given a complete parent Bob band, form the new split-reference band and score the witness on it.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <omp.h>
using I=std::int64_t;using U=std::uint64_t;using Wide=__int128_t;
using Row=std::vector<I>;using Matrix=std::vector<Row>;using Mask=std::array<U,6>;
void require(bool b,const char* msg){if(!b)throw std::runtime_error(msg);}
Matrix read_matrix(const char* name){
    std::ifstream in(name);Matrix x;std::string line;Wide limit=0;
    while(std::getline(in,line)){
        std::istringstream s(line);Row row;I v;
        while(s>>v){Wide mag=v>=0?Wide(v):-Wide(v);require(mag*2<std::numeric_limits<I>::max(),"single table update overflow");limit+=mag;row.push_back(v);}
        require(s.eof()&&!row.empty()&&(x.empty()||x.front().size()==row.size()),"invalid matrix");x.push_back(std::move(row));
    }
    require(!x.empty()&&limit<std::numeric_limits<I>::max(),"int64 sum bound");return x;
}
struct Table{
    int n,m,stride,count;std::vector<I> values;
    Table(const Matrix& a):n(a.size()),m(a.front().size()),stride((n+7)/8*8),count((m+7)/8),values(count*256*stride){
        require(count<=48,"mask too short");
        for(int g=0;g<count;++g){
            I* t=values.data()+g*256*stride;
            for(int i=0;i<n;++i)for(int j=g*8;j<std::min(m,g*8+8);++j)t[i]+=a[i][j];
            for(int b=1;b<256;++b){int low=b&-b,j=g*8+__builtin_ctz(unsigned(low));
                for(int i=0;i<n;++i)t[b*stride+i]=t[(b-low)*stride+i]-(j<m?2*a[i][j]:0);}
        }
    }
    I operator()(const Mask& mask,Row& fields)const{
        std::fill(fields.begin(),fields.end(),0);
        for(int g=0;g<count;++g){
            unsigned b=(mask[g/8]>>(8*(g%8)))&255;
            const I* p=values.data()+(g*256+b)*stride;
            #pragma omp simd
            for(int i=0;i<stride;++i)fields[i]+=p[i];
        }
        I v=0;
        #pragma omp simd reduction(+:v)
        for(int i=0;i<n;++i)v+=std::abs(fields[i]);
        return v;
    }
};
#ifndef SPLIT_TABLE_ONLY
int main(int argc,char** argv){try{
    require(argc==7,"usage: score_split matrix reference parent_band threshold new_band threads");
    auto x=read_matrix(argv[1]),k=read_matrix(argv[2]);
    require(k.size()==x.size() && k.front().size()==x.front().size(),"mismatched matrices");
    Table game(x),reference(k);I T=std::stoll(argv[4]);int nt=std::stoi(argv[6]);require(nt>=1&&nt<=256,"invalid threads");
    std::ifstream in(argv[3]);std::vector<Mask> bs;I value;Mask mask{};
    while(in>>value){for(U& v:mask)require(bool(in>>v),"bad parent band");bs.push_back(mask);}
    require(in.eof()&&!bs.empty(),"empty or invalid parent band");
    std::vector<I> ref(bs.size()),score(bs.size(),-1);
    #pragma omp parallel num_threads(nt)
    {
        Row f(game.stride);
        #pragma omp for schedule(static)
        for(size_t i=0;i<bs.size();++i){ref[i]=reference(bs[i],f);if(ref[i]>T)score[i]=game(bs[i],f);}
    }
    std::ofstream out(argv[5]);I count=0,best=-1;size_t winner=0;
    for(size_t i=0;i<bs.size();++i)if(score[i]>=0){
        ++count;out<<ref[i];for(auto z:bs[i])out<<' '<<z;out<<'\n';
        if(score[i]>best){best=score[i];winner=i;}
    }
    require(bool(out)&&count>0,"no surviving records");
    std::cout<<count<<' '<<best;for(auto x:bs[winner])std::cout<<' '<<x;std::cout<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
#endif
