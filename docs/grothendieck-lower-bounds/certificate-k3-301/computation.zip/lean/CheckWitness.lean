import Std

/-! Integer checks for the finite Grothendieck witness in the accompanying archive.
The global classical upper bound is verified by certificate.py. -/

namespace GrothendieckWitness

abbrev Table := Array (Array Int)

def parseTable (text : String) : Option Table := do
  let lines := text.trimAscii.toString.splitOn "\n"
  let rows ← lines.mapM fun line => do
    let values ← (line.splitOn " ").mapM String.toInt?
    pure values.toArray
  pure rows.toArray

def matrixText := include_str "../witness/matrix.txt"
def aliceText := include_str "Alice.txt"
def bobText := include_str "Bob.txt"
def signingText := include_str "Signing.txt"

def denominator : Int := 10000000000000000000000000000000000000000
def numerator : Int := 92422356381691369081494724621543334927103898587805286507057963067018402350722593401925517175131539945819591534
def classical : Int := 641951269303647081416258863417
def decimalNumerator : Int := 14397098471655953

def dot (x y : Array Int) : Int := Id.run do
  let mut s := 0
  for k in [:x.size] do
    s := s + x[k]! * y[k]!
  return s

def shape (t : Table) (r c : Nat) : Bool :=
  t.size == r && t.all fun x => x.size == c

def vectorNumerator (m a b : Table) : Int := Id.run do
  let mut s := 0
  for i in [:m.size] do
    for j in [:m[i]!.size] do
      s := s + m[i]![j]! * dot a[i]! b[j]!
  return s

def signingScore (m : Table) (b : Array Int) : Int :=
  m.foldl (fun s row => s + (dot row b).natAbs) 0

def witnessChecks : Bool :=
  ((do
    let m ← parseTable matrixText
    let a ← parseTable aliceText
    let b ← parseTable bobText
    let signs ← parseTable signingText
    let s ← signs[0]?
    pure (shape m 301 321 && shape a 301 3 && shape b 321 3 &&
      shape signs 1 321 && s.all (fun t => t.natAbs == 1) &&
      a.all (fun x => decide (dot x x ≤ denominator ^ 2)) &&
      b.all (fun x => decide (dot x x ≤ denominator ^ 2)) &&
      vectorNumerator m a b == numerator && signingScore m s == classical)) : Option Bool).getD false

theorem finite_witness_checks : witnessChecks = true := by native_decide

theorem strict_ratio :
    decimalNumerator * classical * denominator ^ 2 < 10 ^ 16 * numerator := by decide

end GrothendieckWitness
