// Transpose an exhaustive high-score list for a signed matrix game.
// Every row attaining a high column signing is itself in the input band up to group symmetry.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <vector>
using I=std::int64_t;
using U=std::uint64_t;
using Mask=std::array<U,6>;
using Row=std::vector<int>;
void check(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
void toggle(Mask& b,int j){b[j/64]^=U(1)<<(j%64);}
bool negative(const Mask& b,int j){return (b[j/64]>>(j%64))&1;}
int main(int argc,char** argv){try{
    check(argc==3,"usage: bob_band input.txt output.txt");
    std::ifstream input(argv[1]); int n,m,G,N,T;input>>n>>m>>G>>N>>T;
    check(input && n>0 && m>0 && m<=384 && G>0 && N>0 && T>=0,"invalid dimensions");
    std::vector<Row> K(n,Row(m)),KT(m,Row(n));
    I total=0;
    for(int i=0;i<n;++i)for(int j=0;j<m;++j){input>>K[i][j];total+=std::abs(I(K[i][j]));KT[j][i]=K[i][j];}
    for(const auto* mat:{&K,&KT}) for(const auto& row:*mat){
        I bound=0;for(int t:row)bound+=std::abs(I(t));check(bound<std::numeric_limits<int>::max(),"32-bit field bound");
    }
    for(const auto& row:K)for(int v:row)check(2*std::abs(I(v))<std::numeric_limits<int>::max(),"field update overflow");
    std::vector<Row> p(G,Row(m)),sg(G,Row(m));
    for(int g=0;g<G;++g){for(int& j:p[g])input>>j;for(int& s:sg[g])input>>s;
        auto q=p[g];std::sort(q.begin(),q.end());
        for(int j=0;j<m;++j)check(q[j]==j&&std::abs(sg[g][j])==1,"invalid column permutation");}
    std::map<Mask,int> records;
    I enumerated=0,optimal=0;
    for(int rec=0;rec<N;++rec){
        int value;input>>value;Row a(n);for(int& v:a){input>>v;check(std::abs(v)==1,"bad row sign");}
        Row h(m);Mask b{};I score=0;
        for(int j=0;j<m;++j){for(int i=0;i<n;++i)h[j]+=a[i]*K[i][j];score+=std::abs(h[j]);if(h[j]<0)toggle(b,j);}
        check(value==score && value>T,"input record disagrees with matrix");
        std::vector<int> weak;
        for(int j=0;j<m;++j)if(2*I(std::abs(h[j]))<score-T)weak.push_back(j);
        std::sort(weak.begin(),weak.end(),[&](int i,int j){return std::abs(h[i])<std::abs(h[j]);});
        std::vector<Row> all_fields(weak.size()+1,Row(n));
        for(int i=0;i<n;++i)for(int j=0;j<m;++j)all_fields[0][i]+=(negative(b,j)?-1:1)*K[i][j];
        // Precompute all symmetry images of the central Bob signing. A few bit flips suffice for its neighbors.
        std::vector<Mask> images(G);
        for(int g=0;g<G;++g)for(int j=0;j<m;++j)if(negative(b,j)!=(sg[g][j]<0))toggle(images[g],p[g][j]);
        std::vector<int> flips;
        auto visit=[&](auto&& self,int start,int depth,int remaining,int pair_value)->void{
            ++enumerated;const auto& field=all_fields[depth];
            bool attains=true;
            for(int i=0;i<n && attains;++i)if(a[i]*field[i]<0)attains=false;
            if(attains){
                ++optimal;Mask best{};best.fill(~U(0));
                for(int g=0;g<G;++g){
                    Mask v=images[g];for(int j:flips)toggle(v,p[g][j]);
                    if(negative(v,0)){
                        for(U& x:v)x=~x;
                        if(m%64)v[(m-1)/64]&=(U(1)<<(m%64))-1;
                        for(int k=(m+63)/64;k<6;++k)v[k]=0;
                    }
                    if(v<best)best=v;
                }
                auto [it,ok]=records.emplace(best,pair_value);check(ok||it->second==pair_value,"symmetric scores disagree");
            }
            for(int k=start;k<int(weak.size());++k){
                int j=weak[k],cost=std::abs(h[j]);if(cost>remaining)break;
                int factor=negative(b,j)?2:-2;auto& next=all_fields[depth+1];
                for(int i=0;i<n;++i)next[i]=field[i]+factor*KT[j][i];
                flips.push_back(j);self(self,k+1,depth+1,remaining-cost,pair_value-2*cost);flips.pop_back();
            }
        };
        visit(visit,0,0,(score-T-1)/2,score);
    }
    check(bool(input),"short input");
    std::ofstream out(argv[2]);for(const auto& [b,score]:records){out<<score;for(U x:b)out<<' '<<x;out<<'\n';}
    check(bool(out),"write failed");
    std::cout<<"listed row representatives "<<N<<"; eligible sign pairs "<<enumerated<<"; attaining pairs "<<optimal<<"; column orbits "<<records.size()<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
