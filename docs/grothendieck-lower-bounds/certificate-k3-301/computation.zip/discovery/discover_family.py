"""Convert the cutting-plane dual and a Gram factor into an exactly checkable family ceiling."""
import argparse,json,sys
from fractions import Fraction as F
from pathlib import Path
from assess_room import averaged_fit,factors
from certificate import read,dump
from family import prices
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);ap.add_argument('checkpoint',type=Path);ap.add_argument('--prices',type=Path);o=ap.parse_args()
Z,(pa,sa,pb,sb),w,d,dual,k=averaged_fit(o.case,o.checkpoint,o.prices)
A,B,val=factors(Z,pa,pb)
fd=10**12
atoms=json.loads(str(np.load(o.checkpoint/'best.npz')['emb_defs']))
cert=dict(weight_denominator=d,factor_denominator=fd,weights=w.tolist(),alice=dual['alice'].tolist(),bob=dual['bob'].tolist(),
          row_factor=np.rint(fd*A).astype('i8').tolist(),column_factor=np.rint(fd*B).astype('i8').tolist(),embeddings=atoms)
up,parts=prices(o.case,cert);down=up.numerator*10**7//up.denominator+1
cert.update(upper_numerator=up.numerator,upper_denominator=up.denominator,decimal_upper=f'{down//10**7}.{down%10**7:07d}')
if not (o.case/'family.json').exists() or up<F(read(o.case/'family.json')['upper_numerator'],read(o.case/'family.json')['upper_denominator']):
    dump(o.case/'family.json',cert)
print('Fixed directions, bounded certificate family',float(up),'prices',{k:float(v) for k,v in parts.items()},'dual sign mass',sum(w)/d,flush=True)
