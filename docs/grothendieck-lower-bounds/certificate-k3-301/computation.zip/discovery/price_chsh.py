"""Price signed CHSH orbits against the active classical multipliers of the split search."""
import argparse
from setup import *
from game_atoms import atom_key
ap=argparse.ArgumentParser();ap.add_argument('fit',type=Path);ap.add_argument('out',type=Path);ap.add_argument('--number',type=int,default=100);ap.add_argument('--previous',type=Path)
o=ap.parse_args();z=np.load(o.fit/'best.npz');d=np.load(o.fit/'price.npz')
K,M,X,Y,maps,w=load();pp,ss=z['permutation'],z['sign']
Q=z['A']@z['B'].T-d['alice'].T.astype(float)@(d['weights'][:,None]*d['bob'])
H=np.zeros_like(Q)
for p,s,b,t in zip(pp,ss,*maps[2:]):H[np.ix_(p,b)]+=s[:,None]*t*Q
H/=len(pp)
grid,sg,bad=orbit_basis(pp,ss,*maps[2:]);bad=set(bad)
games=[] if o.previous is None else json.loads(o.previous.read_text());seen={atom_key(g,grid,sg,bad) for g in games};rank=[]
for i,u in enumerate(H):
 for k in range(i+1,len(H)):
    plus=u+H[k];minus=u-H[k]
    js=np.argpartition(abs(plus),-2)[-2:];ls=np.argpartition(abs(minus),-2)[-2:]
    for j in js:
      for l in ls:
        if j!=l:
            g=(i,k,int(j),int(l),1 if plus[j]>0 else -1,1 if minus[l]>0 else -1)
            rank.append((abs(plus[j])+abs(minus[l]),g))
rank.sort(reverse=True);start=len(games)
for score,g in rank:
    c=atom_key(g,grid,sg,bad)
    if c and c not in seen:
        games.append(g);seen.add(c)
        if len(games)>=start+o.number:break
o.out.write_text(json.dumps(games,separators=(',',':'))+'\n')
print('top CHSH normalized',rank[0][0]/2,'games',len(games))
