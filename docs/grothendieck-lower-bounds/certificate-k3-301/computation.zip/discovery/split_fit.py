"""Optimize an orbit of split row directions using a complete Bob-sign cutoff."""
import argparse,json,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from setup import HERE,PREV,PKG,load,design,vectors,band,fast_scores,orbit_basis
from sdp_dictionary import decompose,all_orbits
from search import quantum,norm

T=641519292.
class Problem:
    def __init__(self,theta,character,seed=6,reach=52,sd=False,also=(),grouped=False,games=None,embeds=None,hole_seeds=None,cap_table=None):
        K,M,X,Y,maps,w=load();self.K=K;self.M=M;self.source=X;self.Y=Y;self.w=w;self.theta=theta;self.character=character;self.seed=seed
        self.told=w['transport_mass']/w['scale_denominator'];self.out=w['outside_numerator']/w['outside_denominator']/w['scale_denominator']
        self.U=self.out-T*self.told;self.C=w['attained']/w['scale_denominator'];self.n=len(K);self.m=K.shape[1]
        pa,sa,pb,sb=maps
        self.n=len(X);n=len(X)
        self.specs=[(seed,character,theta),*also]
        perms=[pa];sgs=[sa];xrows=[X];nn=n
        for seed1,character1,theta1 in self.specs:
            par,_,rows,tang,(splits,signs,_,_)=design(maps,X,seed1,character1)
            k=len(rows);offset=nn
            def translate(d):return offset+int(np.searchsorted(rows,d)) if d<n else offset+k+d-n
            newp=np.array([[translate(splits[l,i]) for i in rows]+[translate(splits[l,n+j]) for j in range(k)] for l in range(len(pa))])
            perms.append(newp);sgs.append(np.hstack([sa[:,rows],sa[:,rows]]))
            tmp=vectors(X,rows,tang,theta1);xrows.extend([tmp[rows],tmp[n:]])
            nn+=2*k
        self.extra_seeds=[] if hole_seeds is None else hole_seeds
        if self.extra_seeds:
            from holes import orbit,rotations
            rot=rotations(X,maps)
            for pole in self.extra_seeds:
                v,p,ss=orbit(np.array(pole),rot);perms.append(nn+p);sgs.append(ss);xrows.append(v);nn+=len(v)
        self.maps=(np.hstack(perms),np.hstack(sgs),pb,sb)
        assert all(np.array_equal(np.sort(p),np.arange(nn)) for p in self.maps[0])
        self.X=np.vstack(xrows)
        self.R=np.vstack([M-self.told*K,np.zeros((nn-n,self.m))])
        self.K0=np.vstack([K,np.zeros((nn-n,self.m))]);self.M0=self.told*self.K0+self.R
        self.P0=np.vstack([np.eye(n),np.zeros((nn-n,n))])
        self.groups=all_orbits(pa);self.rowgroup=all_orbits(self.maps[0]);self.colgroup=all_orbits(pb)
        self.idx,self.sg,bad=orbit_basis(*self.maps);self.ids=np.array(sorted(set(range(self.idx.max()+1))-set(bad)))
        _,first=np.unique(self.idx,return_index=True);self.reps=first[self.ids]
        def compact(A):return (A*self.sg).ravel()[self.reps]
        self.compact=compact;self.Kr=compact(self.K0);self.Rr=compact(self.R)
        # Every elementary transport sends one unit of each source-column mass to a signed destination orbit.
        # The parent setting is present as a baseline destination.
        C=X@self.X.T;self.tags=[];self.moves=[];self.V=[]
        for gi,gp in enumerate(self.groups):
            i=gp[0];seen=set()
            for j in np.flatnonzero(abs(C[i])>=np.cos(np.deg2rad(reach))):
                if j==i:continue
                t=1 if C[i,j]>0 else -1
                sites=sorted(set(zip(self.maps[0][:,j].tolist(),pa[:,i].tolist(),(t*self.maps[1][:,j]*sa[:,i]).tolist())))
                key=tuple(sites)
                if key in seen:continue
                seen.add(key)
                V=np.zeros((nn,n))
                for v,u,b in sites:V[v,u]+=b
                V/=len(sites)/len(gp);V[gp,gp]-=1.
                self.tags.append((int(i),int(j),t,gi));self.V.append(V)
                self.moves.append(compact(V@K))
        self.moves=np.array(self.moves);self.V=np.array(self.V)
        self.rweight=1.e-3;self.zweight=.02;self.mweight=.015;self.unit=1000.
        self.bases=np.vstack((self.rweight*self.Kr,self.zweight*self.Rr,self.mweight*self.moves))
        self.grouped=grouped
        self.offset=len(self.tags)+2
        self.chips=[];self.chip_caps=[];self.chip_base=[];self.noldgroups=0
        self.game_defs=[] if not games else json.loads(Path(games).read_text())
        self.plant=self.M0.copy()
        if grouped:
            cache=HERE/'grouped.npz'
            if not cache.is_file():
                from group_atoms import regenerate_groups
                lookup,cs=regenerate_groups(PREV,'blocks24')
                np.savez_compressed(cache,mats=np.array(lookup,dtype='i8'),caps=np.array(cs,dtype='i8'))
            data=np.load(cache);self.noldgroups=len(data['caps'])
            for src,c in zip(data['mats'],data['caps']):
                mat=np.zeros_like(self.M0);mat[:n]=src/w['scale_denominator']
                self.chips.append(compact(mat));self.chip_caps.append(c/w['scale_denominator']);self.chip_base.append(1.)
            self.R=np.zeros_like(self.R);self.Rr=compact(self.R);self.U=0.
            self.M0=self.told*self.K0
            for chip in self.chips:
                full=np.zeros(self.idx.max()+1);full[self.ids]=chip;self.M0+=full[self.idx]*self.sg
            self.out=self.told*T+sum(self.chip_caps)
            self.bases[1]=0
        if self.game_defs:
            from game_atoms import coefficients
            atoms=coefficients(self.game_defs,self.idx,self.sg,set(bad),self.ids)
            for gd in atoms:
                self.chips.append(gd);self.chip_caps.append(2*len(pa));self.chip_base.append(0.)
        self.emb_defs=[] if not embeds else json.loads(Path(embeds).read_text())
        verified_caps={}
        if cap_table:
            from collision_caps import encoding
            from hashlib import sha256
            supplied=json.loads(Path(cap_table).read_text())
            action=list(zip(self.maps[0].tolist(),self.maps[1].tolist()))
            assert supplied['action']==sha256(encoding(action).encode()).hexdigest()
            verified_caps=supplied['caps']
        if self.emb_defs:
            from embedding_atoms import source,compute_numpy
            sys.path.insert(0,str(PREV))
            sources={k:source(PREV,k,w,K.tolist()) for k in {a['kind'] for a in self.emb_defs}}
            for atom in self.emb_defs:
                S,cap=sources[atom['kind']]
                if verified_caps and atom['kind']=='reference':
                    cap=min(cap,verified_caps[encoding(atom)])
                gd,c=compute_numpy(np.array(S,dtype='i8'),cap,atom,self.idx,self.sg,set(bad),self.ids)
                self.chips.append(gd);self.chip_caps.append(c);self.chip_base.append(0.)
        self.chips=np.array(self.chips).reshape(-1,len(self.ids))
        self.chip_base=np.array(self.chip_base);self.chip_caps=np.array(self.chip_caps)
        self.chip_step=160000./np.maximum(self.chip_caps,1.e-12)
        if len(self.chips):self.bases=np.vstack([self.bases,self.chip_step[:,None]*self.chips])
        self.Bs=np.unique(np.vstack([np.load(HERE/'active-bob.npy'),np.load(PKG/'search/warm_planes.npz')['bob']]),axis=0)
        self.seen=set();self.cuts=[];self.rhs=[];self.keys=[]
        self.sd=sd
        if sd:
            self.spaces,self.inv,_=decompose(self.maps,self.idx,self.sg,self.ids,None)
        self.setcuts(self.Bs,self.plant,initial=250)
    def aggregate(self,A):
        return np.bincount(self.idx.ravel(),weights=(A*self.sg).ravel(),minlength=self.idx.max()+1)[self.ids]
    def setcuts(self,bob,mat,initial=0):
        fields=bob.astype(float)@mat.T
        scores=abs(fields).sum(axis=1)
        ids=np.argsort(scores)[::-1][:initial] if initial else np.flatnonzero(scores>self.C+.0001)
        if len(ids)>500:ids=ids[np.argsort(scores[ids])[::-1][:500]]
        count=0
        for i in ids:
            a=np.where(fields[i]>=0,1,-1)
            count+=self.insert_cut(a,bob[i])
        return count
    def insert_cut(self,a,b):
        c=self.aggregate(a[:,None]*b)
        key=c.astype(np.int16).tobytes()
        if key in self.seen:return 0
        self.seen.add(key);self.keys.append((a.astype('i1'),np.array(b,dtype='i1')))
        v=self.bases@c/self.unit
        if self.sd:v=np.r_[v,c@self.inv]
        self.cuts.append(v);self.rhs.append((self.C-c@self.compact(self.M0))/self.unit)
        return 1
    def solve(self,X,Y):
        unit=self.unit;d=self.bases.shape[0];grp=[]
        far=np.r_[T*self.rweight/unit,self.U*self.zweight/unit,np.zeros(len(self.tags)),self.chip_caps*self.chip_step/unit]
        for i,g in enumerate(self.groups):
            grp.append(np.r_[-self.rweight,0,[self.mweight*(v[3]==i) for v in self.tags],np.zeros(len(self.chips))])
        gram=self.aggregate(X@Y.T);gradient=self.bases@gram/unit
        low=np.r_[-self.told/self.rweight,-1/self.zweight,np.zeros(len(self.tags)),-self.chip_base/self.chip_step]
        if not self.sd:
            a=np.vstack([far,*grp,*self.cuts]);b=np.r_[(self.C-self.out)/unit,np.full(len(grp),self.told),self.rhs]
            opt=linprog(-gradient,A_ub=a,b_ub=b,bounds=[(v,None) for v in low],method='highs',
                 options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
            assert opt.success,opt.message
            return opt.x,None,None,None
        import cvxpy as cp
        x=cp.Variable(d);rm=cp.Variable(len(self.rowgroup));cm=cp.Variable(len(self.colgroup));pieces=[]
        cs=[x>=low,np.stack(grp)@x<=self.told,rm>=1.e-7,cm>=1.e-7,
            far@x+.5*(rm@np.array(list(map(len,self.rowgroup)))+cm@np.array(list(map(len,self.colgroup))))<=(self.C-self.out)/unit-.0001]
        if self.grouped:cs.append(x[1]==0)
        for P,Q in self.spaces:
            nx,ny=P.shape[1],Q.shape[1];z=cp.Variable((nx,ny));pieces.append(cp.reshape(z,(nx*ny,),order='C'))
            aa=sum(rm[i]*(P[J].T@P[J]) for i,J in enumerate(self.rowgroup));bb=sum(cm[i]*(Q[J].T@Q[J]) for i,J in enumerate(self.colgroup))
            cs.append(cp.bmat([[aa,z],[z.T,bb]])>>0)
        p=cp.hstack(pieces);uv=cp.hstack([x,p]);grad=np.r_[gradient,gram@self.inv]
        cs.append(np.stack(self.cuts)@uv<=np.array(self.rhs))
        opt=cp.Problem(cp.Maximize(grad@uv),cs)
        opt.solve(solver='CLARABEL',max_threads=1,max_iter=200,tol_gap_rel=1e-8,tol_gap_abs=1e-8,tol_feas=2e-9)
        assert x.value is not None,opt.status
        self.dual=np.maximum(0,cs[-1].dual_value)
        vals=np.zeros(self.idx.max()+1);vals[self.ids]=self.inv@p.value*unit
        E=vals[self.idx]*self.sg;aw=np.zeros(len(X));bw=np.zeros(len(Y))
        for v,J in zip(rm.value,self.rowgroup):aw[J]=v*unit
        for v,J in zip(cm.value,self.colgroup):bw[J]=v*unit
        return x.value,E,aw,bw
    def search(self,out,rounds,start=None,accelerate=1.,stall=0.):
        X,Y=self.X.copy(),self.Y.copy();best=0;last_feasible=None;small_changes=0
        if out:out.mkdir(exist_ok=True,parents=True)
        if start:
            state=np.load(start);X,Y=state['A'],state['B']
            if len(X)<len(self.X):X=np.vstack([X,self.X[len(X):]])
            assert len(X)==len(self.X)
            if 'matrix' in state:old=state['matrix']
            else:
                oldR=self.M-self.told*self.K
                old=state['V']@self.K+state['E'];old[:self.n]+=state['z']*oldR
            if len(old)<len(self.X):old=np.vstack([old,np.zeros((len(self.X)-len(old),self.m))])
            score=fast_scores(band(),old);hit=np.argsort(score)[-600:]
            self.Bs=np.vstack([self.Bs,band()[hit]])
            self.setcuts(self.Bs,old,initial=900)
            pool=Path(start).parent/'price.npz'
            if not pool.is_file():pool=Path(start).parent/'plane_pool.npz'
            if pool.is_file():
                dd=np.load(pool)
                oldn=dd['alice'].shape[1]
                if oldn<len(X):
                    C=self.X[oldn:]@self.source.T;nearest=np.argsort(-abs(C),axis=1)[:,:4]
                    proxy=np.array([np.sum(np.sign(c[ids])[:,None]*self.K[ids]/np.maximum(np.linalg.norm(self.K[ids],axis=1)[:,None],1.)*(abs(c[ids])[:,None]**16),axis=0) for c,ids in zip(C,nearest)])
                limit=len(dd['alice']) if stall and oldn==len(X) else 500
                for aa,bb in zip(dd['alice'][:limit],dd['bob'][:limit]):
                    if len(aa)<len(X):aa=np.r_[aa,np.where(proxy@bb>=0,1,-1)]
                    if len(aa)==len(X):self.insert_cut(aa,bb)
        for step in range(rounds):
            p,E,aw,bw=self.solve(X,Y)
            t=self.told+self.rweight*p[0];z=1+self.zweight*p[1];mu=np.maximum(0,p[2:self.offset])*self.mweight
            V=t*self.P0+np.tensordot(mu,self.V,axes=1);core=V@self.K+z*self.R
            chips=np.maximum(0,self.chip_base+self.chip_step*p[self.offset:])
            if len(chips):
                cv=np.zeros(self.idx.max()+1);cv[self.ids]=chips@self.chips;core+=cv[self.idx]*self.sg
            if E is not None:core+=E
            near=abs(self.Bs.astype(float)@core.T).sum(axis=1);outside=T*abs(V).sum(axis=0).max()+z*self.U+chips@self.chip_caps
            if aw is not None:outside+=(aw.sum()+bw.sum())/2
            ncut=self.setcuts(self.Bs,core)
            # Check every orbit before accepting a candidate or rotating its vectors.
            if ncut==0 or step==rounds-1:
                B=band();scores=fast_scores(B,core);ind=np.argsort(scores)[::-1]
                if scores[ind[0]]>self.C+.0001:
                    select=ind[:300];self.Bs=np.vstack([self.Bs,B[select]]);ncut+=self.setcuts(B[select],core)
                peak=scores[ind[0]]
            else:peak=near.max()
            val,xx,yy=quantum(core,X,Y,300);ratio=val/max(peak,outside)
            neww=np.linalg.norm(core[len(self.K):]@yy,axis=1).sum()/val
            print('step',step,'rows',len(self.cuts),'excess',round(peak-self.C,4),'ratio',f'{ratio:.15f}','new fraction',f'{neww:.7g}','cuts',ncut,flush=True)
            if ncut==0 and ratio>best:
                best=ratio
                if out:
                    np.savez_compressed(out/'plane_pool.npz',alice=np.stack([a for a,b in self.keys]),bob=np.stack([b for a,b in self.keys]))
                    if self.sd:
                        dc=[(k,u) for k,u in zip(self.keys,self.dual) if u>1.e-10]
                        np.savez_compressed(out/'price.npz',alice=np.stack([k[0] for k,u in dc]),bob=np.stack([k[1] for k,u in dc]),weights=np.array([u for k,u in dc]))
                    np.savez_compressed(out/'best.npz',V=V,z=z,E=np.zeros_like(core) if E is None else E,A=xx,B=yy,
                        aw=np.array([]) if aw is None else aw,bw=np.array([]) if bw is None else bw,
                        theta=self.theta,character=self.character,seed=self.seed,permutation=self.maps[0],sign=self.maps[1],
                        t=t,mu=mu,tags=np.array(self.tags),observed=peak,approx=ratio,
                        matrix=core,specs=np.array(self.specs),separate=self.grouped,groups='blocks24' if self.grouped else '',extra_seeds=np.array(self.extra_seeds),
                        group_weights=chips[:self.noldgroups],game_weights=chips[self.noldgroups:self.noldgroups+len(self.game_defs)],game_defs=np.array(self.game_defs),emb_weights=chips[self.noldgroups+len(self.game_defs):],emb_defs=json.dumps(self.emb_defs))
            if self.sd and len(self.keys)>950 and step>=0:
                previous=len(self.dual)
                mass=self.dual
                keep=set(np.flatnonzero(mass>2.e-8).tolist())|set(range(max(0,previous-95),len(self.keys)))
                if len(keep)<420:keep.update(np.argsort(mass)[-420:].tolist())
                ids=sorted(keep);self.keys=[self.keys[i] for i in ids]
                self.cuts=[self.cuts[i] for i in ids];self.rhs=[self.rhs[i] for i in ids]
                self.seen={self.aggregate(a[:,None]*b).astype(np.int16).tobytes() for a,b in self.keys}
            if ncut==0:
                if stall and last_feasible is not None:
                    small_changes=small_changes+1 if ratio<=last_feasible+stall else 0
                    if small_changes>=2:
                        print('Stopped after two feasible direction updates within',stall,flush=True)
                        break
                last_feasible=ratio
                if not out or np.max(abs((xx@yy.T)-(X@Y.T)))<3e-6:break
                drift=max(np.linalg.norm(xx-X,axis=1).max(),np.linalg.norm(yy-Y,axis=1).max())
                speed=max(1.,min(accelerate,.11/max(drift,1.e-15)))
                X,Y=norm(X+speed*(xx-X)),norm(Y+speed*(yy-Y))
        return best
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--theta',type=float,required=True);ap.add_argument('--character',type=int,default=0)
    ap.add_argument('--seed',type=int,default=6);ap.add_argument('--reach',type=float,default=52);ap.add_argument('--sdp',action='store_true');ap.add_argument('--start',type=Path);ap.add_argument('--also',nargs=3,action='append',type=float,default=[]);ap.add_argument('--grouped',action='store_true');ap.add_argument('--embeddings',type=Path);ap.add_argument('--holes',type=Path);ap.add_argument('--indices',nargs='+',type=int,default=[0]);ap.add_argument('--games',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--rounds',type=int,default=12)
    ap.add_argument('--accelerate',type=float,default=1.)
    ap.add_argument('--cap-table',type=Path)
    ap.add_argument('--stall',type=float,default=0.)
    o=ap.parse_args();p=Problem(o.theta,o.character,o.seed,o.reach,o.sdp,[(int(i),int(c),a) for i,c,a in o.also],o.grouped,o.games,o.embeddings,([json.loads(o.holes.read_text())['holes'][i] for i in o.indices] if o.holes else None),o.cap_table);p.search(o.out,o.rounds,o.start,o.accelerate,o.stall)
