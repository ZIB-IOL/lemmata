"""Prepare the exact merged-setting bounds for a numerical search on this signed group action."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from setup import PREV
from collision_caps import cap,encoding
ap=argparse.ArgumentParser();ap.add_argument('fit',type=Path);ap.add_argument('atoms',type=Path);ap.add_argument('out',type=Path);o=ap.parse_args()
z=np.load(o.fit);action=list(zip(z['permutation'].tolist(),z['sign'].tolist()));terms=json.loads(o.atoms.read_text())
caps={encoding(a):cap(PREV,action,a) for a in terms if a['kind']=='reference'}
o.out.write_text(json.dumps(dict(action=hashlib.sha256(encoding(action).encode()).hexdigest(),caps=caps),separators=(',',':'))+'\n')
print('Verified',len(caps),'averaged reference embedding bounds. Range',min(caps.values()),max(caps.values()),flush=True)
