"""Estimate the dual ceiling at the present directions for the certified transport and comparison family."""
import argparse,json
from pathlib import Path
from setup import *
from scipy.optimize import minimize
from sdp_dictionary import all_orbits

def averaged_fit(case,checkpoint,prices_file=None):
    from certificate import read
    v=read(case/'final-vectors.json');D=float(v['denominator'])
    x=np.array(v['alice'],dtype=float)/D;y=np.array(v['bob'],dtype=float)/D
    dec=np.load(prices_file or checkpoint/'price.npz')
    den=10**13;weight=np.rint(dec['weights']*den).astype('int64')
    Z=x@y.T-dec['alice'].T.astype(float)@((weight/den)[:,None]*dec['bob'])
    z=np.load(checkpoint/'best.npz');pa,sa=z['permutation'],z['sign'];k,_,_,_,maps,_=load();_,_,pb,sb=maps
    av=np.zeros_like(Z)
    for p,s,b,t in zip(pa,sa,pb,sb):av[np.ix_(p,b)]+=s[:,None]*t*Z
    return av/len(pa),(pa,sa,pb,sb),weight,den,dec,k

def factors(R,pa,pb):
    groups=[all_orbits(pa),all_orbits(pb)]
    nr=len(groups[0])
    ns=np.array([len(x) for gp in groups for x in gp])
    ids=[]
    for gp in groups:
        ind=np.zeros(sum(map(len,gp)),int)
        for i,rows in enumerate(gp):ind[rows]=i
        ids.append(ind)
    def calc(x,ret=False):
        row=np.sqrt(x[:nr][ids[0]]);col=np.sqrt(x[nr:][ids[1]])
        u,s,v=np.linalg.svd(row[:,None]*R*col,full_matrices=False)
        left=u*np.sqrt(s)/row[:,None];right=v.T*np.sqrt(s)/col[:,None]
        l=(left*left).sum(axis=1);r=(right*right).sum(axis=1)
        if ret:return left,right,np.sqrt(l.max()*r.max())
        grad=np.array([l[j].sum() for j in groups[0]]+[r[j].sum() for j in groups[1]])*.5
        return -s.sum(),-grad
    c=np.zeros((2,len(ns)));c[0,:nr]=ns[:nr];c[1,nr:]=ns[nr:]
    from scipy.optimize import LinearConstraint
    start=np.r_[np.full(nr,1/len(pa[0])),np.full(len(ns)-nr,1/len(pb[0]))]
    sol=minimize(calc,start,method='SLSQP',jac=True,bounds=[(1.e-8,.18) for _ in ns],constraints=[LinearConstraint(c,[1.,1.],[1.,1.])],options=dict(ftol=1e-13,maxiter=170))
    return calc(sol.x,True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('fit',type=Path);a=p.parse_args()
    R,(pa,sa,pb,sb),wt,d,dec,K=averaged_fit(a.case,a.fit)
    A,B,f=factors(R,pa,pb);transport=abs(K@R.T).max(axis=1).sum()/641519292
    from group_atoms import regenerate_groups
    G,C=regenerate_groups(PREV,'blocks24');old=max(sum((np.array(g)*R[:len(K)]).ravel())/c for g,c in zip(G,C) if c)
    print('weights',wt.sum()/d,'SDP',f,'transport',transport,'groups',old,'upper before new embedding prices',wt.sum()/d+max(f,transport,old),flush=True)
