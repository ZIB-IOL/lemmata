"""Produce the integer matrices, norm certificate and rational three-dimensional witness."""
import argparse,sys,json
from pathlib import Path
import numpy as np
from setup import PKG,HERE,PREV
sys.path.insert(0,str(HERE.parent))
from certificate import dump,put,reconstruct,calc
sys.path.insert(0,str(PKG/'search'));sys.path.insert(0,str(PKG))
from make_band_product import factor_certificate
from fixed_matrix import refine
def main():
    ap=argparse.ArgumentParser();ap.add_argument('fit',type=Path);ap.add_argument('out',type=Path);ap.add_argument('--tight',action='store_true');o=ap.parse_args();o.out.mkdir(exist_ok=True,parents=True)
    z=np.load(o.fit);q=10**9;d=10**4
    V=np.rint(q*z['V']).astype(np.int64)
    E=np.rint(d*z['E']).astype(np.int64)
    np.savetxt(o.out/'transport.txt',V,fmt='%d');np.savetxt(o.out/'delta.txt',E,fmt='%d')
    spec=dict(scale=q,delta_denominator=d,old_remainder=round(float(z['z'])*q),seed=int(z['seed']),character=int(z['character']),angle=float(z['theta']),separate_old_delta=bool(z['separate']) if 'separate' in z else False)
    if o.tight:spec['collision_caps']=True
    if 'group_weights' in z:
        spec['groups']=str(z['groups']);spec['group_weights']=[round(float(a)*q) for a in z['group_weights']]
    if 'game_defs' in z:
        spec['extra_games']=[[list(map(int,g)),round(float(a)*q)] for g,a in zip(z['game_defs'],z['game_weights']) if round(float(a)*q)>0]
    if 'emb_defs' in z:
        spec['extra_embeddings']=[[g,round(float(a)*q)] for g,a in zip(json.loads(str(z['emb_defs'])),z['emb_weights']) if round(float(a)*q)>0]
    if 'specs' in z:spec['split_orbits']=z['specs'].tolist()
    dump(o.out/'parameters.json',spec)
    dump(o.out/'symmetry.json',list(zip(z['permutation'].tolist(),z['sign'].tolist())))
    if np.any(E):
        cert=factor_certificate(E,{'row_diagonal':z['aw'],'column_diagonal':z['bw']},d);dump(o.out/'norm.json',cert)
    _,_,_,_,M,_,_=reconstruct(PREV,o.out)
    D=10**32
    _,x,y=refine(M,[[int(float(v)*1e18) for v in a] for a in z['A']],denominator=D,steps=80)
    dump(o.out/'vectors.json',dict(vector_denominator=D,alice=x,bob=y))
    calc(PREV,o.out,HERE/'parent-column-band.txt',HERE/'score_split',4,True)
if __name__=='__main__':main()
