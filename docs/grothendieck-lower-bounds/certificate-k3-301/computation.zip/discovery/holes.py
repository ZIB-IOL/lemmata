"""Find the signed icosahedral orbits through the largest empty spherical caps."""
import sys,json,argparse
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from setup import load
def rotations(X,maps):
    out=[]
    for p,s in zip(*maps[:2]):
        u,_,v=np.linalg.svd(X.T@(s[:,None]*X[p]));out.append(u@v)
    return out
def orbit(seed,rot):
    vec=[]
    for r in rot:
        u=seed@r;u/=np.linalg.norm(u)
        if not any(abs(x@u)>1-1e-8 for x in vec):vec.append(u)
    X=np.array(vec);p=[];s=[]
    for r in rot:
        v=X@r@X.T;idx=abs(v).argmax(axis=1);dots=v[np.arange(len(X)),idx]
        assert np.min(abs(dots))>1-1e-7;p.append(idx);s.append(np.sign(dots).astype(int))
    return X,np.array(p),np.array(s)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('fit',type=Path);ap.add_argument('out',type=Path);o=ap.parse_args()
    _,_,X,_,maps,_=load();rot=rotations(X,maps);points=np.load(o.fit)['A'];cloud=np.vstack([points,-points]);hull=ConvexHull(cloud)
    candidates=[];seeds=[]
    for u in hull.equations[:,:3]:
        u=u/np.linalg.norm(u);distance=np.rad2deg(np.arccos(np.clip(abs(points@u).max(),-1,1)))
        candidates.append((distance,u))
    for dist,u in sorted(candidates,key=lambda q:-q[0]):
        if any(np.max(abs(v@u))>1-1e-7 for v in seeds):continue
        V,_,_=orbit(u,rot);seeds.append(V)
        if len(seeds)<=10:print(len(seeds)-1,'orbit',len(V),'covering angle',round(dist,4),'degrees')
    special=None
    for r in rot:
        q=r*np.linalg.det(r)
        if abs(np.trace(q))<1.e-6:
            eig,U=np.linalg.eigh(q+q.T);special=U[:,-1];break
    assert special is not None
    V,_,_=orbit(special,rot);print('threefold',len(V),'distance',np.rad2deg(np.arccos(max(abs(points@special)))))
    o.out.write_text(json.dumps({'threefold':special.tolist(),'holes':[v[0].tolist() for v in seeds]},indent=1)+'\n')
if __name__=='__main__':main()
