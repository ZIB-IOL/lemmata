"""Find relabelled reference games that use the new row settings."""
import argparse
from setup import *
from scipy.spatial.transform import Rotation
from embedding_atoms import source
ap=argparse.ArgumentParser();ap.add_argument('fit',type=Path);ap.add_argument('out',type=Path)
ap.add_argument('--number',type=int,default=40);ap.add_argument('--starts',type=int,default=60);ap.add_argument('--tag',choices=['reference','compact'],default='reference')
ap.add_argument('--previous',type=Path);ap.add_argument('--seed',type=int,default=85317);o=ap.parse_args()
z=np.load(o.fit/'best.npz');d=np.load(o.fit/'price.npz')
sys.path.insert(0,str(PREV));K,M,X,Y,maps,w=load();R,C=source(PREV,o.tag,w,K.tolist());R=np.array(R,float)
pp,ss=z['permutation'],z['sign'];U=z['A']
Q=U@z['B'].T-d['alice'].T.astype(float)@(d['weights'][:,None]*d['bob']);G=np.zeros_like(Q)
for p,s,b,t in zip(pp,ss,*maps[2:]):G[np.ix_(p,b)]+=s[:,None]*t*Q
G/=len(pp);rng=np.random.default_rng(o.seed);pool={}
old=[] if not o.previous else json.loads(o.previous.read_text())
warm=[a for a in old if a['kind']==o.tag]
for it in range(o.starts+min(15,len(warm))):
    if it<min(15,len(warm)):
        ia=np.array(warm[it]['rows']);sa=np.array(warm[it]['row_signs'])
    elif it%3==2 and pool:
        par=pool[sorted(pool,reverse=True)[min(len(pool)-1,int(rng.exponential(5)))]]
        ia=par[0].copy();sa=par[1].copy();ib,sb=par[2:];imp=(R*sb)@G[:,ib].T
        hit=rng.choice(len(R),rng.integers(2,max(3,len(R)//8)),replace=False);rows=imp[hit]
        cand=np.argpartition(-abs(rows),7,axis=1)[:,:8];ia[hit]=cand[np.arange(len(hit)),rng.integers(0,8,len(hit))]
        sa[hit]=np.where(rows[np.arange(len(hit)),ia[hit]]>=0,1,-1)
    else:
        rotation=Rotation.random(random_state=rng).as_matrix() if it else np.eye(3)
        centers=X@rotation@U.T+rng.normal(0,[0.,.02,.08,.4][it%4],size=(len(X),len(U)))
        ia=abs(centers).argmax(axis=1);sa=np.where(centers[np.arange(len(X)),ia]>=0,1,-1)
    last=-1.
    for step in range(45):
        cols=R.T@(G[ia]*sa[:,None]);ib=abs(cols).argmax(axis=1);sb=np.where(cols[np.arange(len(ib)),ib]>=0,1,-1)
        scores=(R*sb)@G[:,ib].T;ia=abs(scores).argmax(axis=1);sa=np.where(scores[np.arange(len(ia)),ia]>=0,1,-1)
        v=abs(scores).max(axis=1).sum()/C
        if v<=last+1.e-13:break
        last=v
    pool[round(v,11)]=(ia,sa,ib,sb)
out=list(old);seen={json.dumps(x,sort_keys=True) for x in out}
for val in sorted(pool,reverse=True)[:o.number]:
    rec=dict(kind=o.tag,**{k:v.tolist() for k,v in zip(('rows','row_signs','columns','column_signs'),pool[val])})
    if json.dumps(rec,sort_keys=True) not in seen:out.append(rec)
o.out.write_text(json.dumps(out,separators=(',',':'))+'\n')
print(o.tag,'max normalized price',max(pool),'new',len(out)-len(old),flush=True)
