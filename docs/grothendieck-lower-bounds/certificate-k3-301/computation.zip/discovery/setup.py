"""Geometry and certified reference inputs for splitting one orbit of Alice settings."""
import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/'parent'
PKG=PREV
sys.path[:0]=[str(HERE.parent),str(PKG/'search'),str(PKG/'search/support')]
from facet import maps_for
from search import norm,orbit_basis
def load():
    w=json.loads((PREV/'second/witness.json').read_text());K=np.loadtxt(PREV/'second/endpoint.txt',dtype=np.int64)
    M=np.loadtxt(PREV/'second/matrix.txt')/w['scale_denominator']
    X=np.array(w['alice_numerators'],float)/w['vector_denominator']
    Y=np.array(w['bob_numerators'],float)/w['vector_denominator']
    maps=maps_for(K,np.loadtxt(PREV/'split_rows.txt',int));W=np.loadtxt(PREV/'second/transport.txt',int)
    assert np.array_equal(W,w['transport_mass']*np.eye(len(W),dtype=int))
    return K,M,X,Y,maps,w
def design(maps,X,seed=6,character=0):
    pa,sa,pb,sb=maps;rows=np.unique(pa[:,seed]);loc={v:i for i,v in enumerate(rows)};n=len(X)
    rotations=[]
    for p,s in zip(pa,sa):
        u,_,v=np.linalg.svd(X.T@(s[:,None]*X[p]));r=u@v
        assert np.max(abs(X@r-s[:,None]*X[p]))<1e-7
        rotations.append(r)
    origin=X[seed]/np.linalg.norm(X[seed])
    _,_,v=np.linalg.svd(origin[None,:],full_matrices=True);basis=v[1:]
    # A stabilizer reflection distinguishes two tangent lines.
    for g in np.flatnonzero(pa[:,seed]==seed):
        e,u=np.linalg.eigh(basis@(sa[g,seed]*rotations[g])@basis.T)
        if e[1]-e[0]>1.5:break
    else:
        if sum(pa[:,seed]==seed)>2:raise ValueError('no invariant tangent line')
        u=np.eye(2)
    tangent=u[:,character]@basis
    tang=[]
    for j in rows:
        g=int(np.flatnonzero(pa[:,seed]==j)[0]);tang.append(sa[g,seed]*tangent@rotations[g])
    tang=np.array(tang); assert np.max(abs((tang*X[rows]).sum(axis=1)))<1.e-7
    parents=np.r_[np.arange(n),rows];dd=np.ones(n+len(rows));dd[rows]=.5;dd[n:]=.5
    perm=[];sg=[]
    for g,(p,s) in enumerate(zip(pa,sa)):
        dst=np.r_[p,p[rows]]; signs=np.r_[s,s[rows]]
        for l,i in enumerate(rows):
            k=loc[p[i]];d=(tang[l]@rotations[g])@(s[i]*tang[k]);assert abs(abs(d)-1)<1e-6
            if d>=0:dst[i]=p[i];dst[n+l]=n+k
            else:dst[i]=n+k;dst[n+l]=p[i]
        assert np.array_equal(np.sort(dst),np.arange(len(dst)))
        perm.append(dst);sg.append(signs)
    return parents,dd,rows,tang,(np.array(perm),np.array(sg),pb,sb)
def vectors(X,rows,tang,angle):
    a=np.deg2rad(angle);ret=np.vstack((X,X[rows]))
    ret[rows]=np.cos(a)*X[rows]+np.sin(a)*tang
    ret[len(X):]=np.cos(a)*X[rows]-np.sin(a)*tang
    return norm(ret)
def band():
    path=HERE/'Bsigns.npy'
    if not path.exists():
        arr=np.loadtxt(HERE/'parent-column-band.txt',dtype=np.uint64)
        words=np.ascontiguousarray(arr[:,1:].astype('<u8'))
        signs=1-2*np.unpackbits(words.view('u1'),axis=1,bitorder='little')[:,:321].astype('i1')
        np.save(path,signs);np.save(HERE/'Bvalues.npy',arr[:,0].astype('i4'))
    return np.load(path,mmap_mode='r')
def fast_scores(B,M): # matrices in reference units below one billion.
    out=np.empty(len(B))
    for j in range(0,len(B),4096):
        out[j:j+4096]=np.abs(B[j:j+4096].astype(float)@M.T).sum(axis=1)
    return out
def initialize():
    B=band();K,M,X,Y,maps,w=load()
    if not (HERE/'active-bob.npy').exists():
        s=fast_scores(B,M);idx=np.argsort(s)[-3000:]
        np.save(HERE/'active-bob.npy',B[idx])
        print('band',len(B),'old peak',s.max(),'groups in top',sum(s>s.max()-1.),'3000th gap',s.max()-s[idx[0]],flush=True)
    for c in (0,1):
        par,d,rows,tang,m=design(maps,X,6,c);print('split orbit',rows.tolist(),'character',c)
if __name__=='__main__':initialize()
