"""Export a self-contained Lean check of the displayed integer matrix and rational strategy."""
import argparse
import json
from pathlib import Path

def write_lean(case, out):
    def read(name):
        return json.loads((case / name).read_text())
    final = read('final.json')
    vec = read('final-vectors.json')
    raw = read('result.json')
    mask = read('calibration.json')['mask']
    lower = int(final['strict_lower'].replace('.', ''))
    d = vec['denominator']
    n, m = raw['rows'], raw['columns']
    b = [1-2*((mask[j//64]>>(j%64)) & 1) for j in range(m)]
    out.mkdir(exist_ok=True, parents=True)
    for name, rows in [('Alice',vec['alice']),('Bob',vec['bob']),('Signing',[b])]:
        (out / (name+'.txt')).write_text(''.join(' '.join(map(str, row))+'\n' for row in rows))
    template = Path(__file__).with_name('CheckWitness.template').read_text()
    for key, val in [('ROWS',n),('COLS',m),('DEN',d),('NUM',final['quantum_numerator']),
                     ('CLASS',final['classical_lower']),('LOWER',lower)]:
        template = template.replace('@'+key+'@',str(val))
    (out / 'CheckWitness.lean').write_text(template)
    (out / 'lean-toolchain').write_text('leanprover/lean4:v4.35.0\n')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);ap.add_argument('out',type=Path)
    o=ap.parse_args();write_lean(o.case,o.out)
