"""Fit nonnegative dual sign weights to the final rational directions with optimistic embedding costs."""
import argparse,json,hashlib,tempfile
from pathlib import Path
import numpy as np
from setup import load
from split_fit import Problem
from collision_caps import encoding
from certificate import read,dump,T
ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);ap.add_argument('fit',type=Path);ap.add_argument('out',type=Path);o=ap.parse_args()
z=np.load(o.fit/'best.npz');act=list(zip(z['permutation'].tolist(),z['sign'].tolist()));defs=json.loads(str(z['emb_defs']))
with tempfile.TemporaryDirectory() as temp:
    tmp=Path(temp)
    (tmp/'emb.json').write_text(json.dumps(defs))
    dump(tmp/'caps.json',dict(action=hashlib.sha256(encoding(act).encode()).hexdigest(),caps={encoding(a):T for a in defs if a['kind']=='reference'}))
    spec=z['specs'];p=Problem(float(spec[0,2]),int(spec[0,1]),int(spec[0,0]),52,True,[(int(i),int(c),a) for i,c,a in spec[1:]],True,
                              embeds=tmp/'emb.json',hole_seeds=z['extra_seeds'].tolist(),cap_table=tmp/'caps.json')
    assert np.array_equal(p.maps[0],z['permutation']) and np.array_equal(p.maps[1],z['sign'])
    for name in ['price.npz','plane_pool.npz']:
        f=o.fit/name
        if f.is_file():
            val=np.load(f)
            for a,b in zip(val['alice'],val['bob']):p.insert_cut(a,b)
    v=read(o.case/'final-vectors.json');d=float(v['denominator'])
    X=np.array(v['alice'],float)/d;Y=np.array(v['bob'],float)/d
    p.solve(X,Y)
    sel=[(ab,wt) for ab,wt in zip(p.keys,p.dual) if wt>1e-10]
    np.savez_compressed(o.out,alice=np.stack([ab[0] for ab,w in sel]),bob=np.stack([ab[1] for ab,w in sel]),weights=np.array([wt for ab,wt in sel]))
    print('Fixed final directions,',len(p.keys),'sign inequalities and',len(sel),'positive dual weights.',flush=True)
