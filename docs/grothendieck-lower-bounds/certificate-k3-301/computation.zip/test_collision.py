"""Exhaust small signed cyclic games to test the bound for merged settings."""
import itertools,random
from collision_caps import bound,sign_columns
from test_bands import canonical,score

rng=random.Random(26112711)
cases=improved=0
for n in (4,5,6,7):
    vals=[rng.randrange(-7,8) for j in range(n)]
    u=[rng.choice((-1,1)) for i in range(n)];v=[rng.choice((-1,1)) for i in range(n)]
    k=[[u[i]*v[j]*vals[(j-i)%n] for j in range(n)] for i in range(n)]
    ops=[]
    for g in range(n):
        p=[(j+g)%n for j in range(n)]
        ops.append((p,[u[i]*u[p[i]] for i in range(n)],p,[v[j]*v[p[j]] for j in range(n)]))
    signs=list(itertools.product((-1,1),repeat=n))
    rv={canonical(a,[(p,s) for p,s,_,_ in ops]):score(list(zip(*k)),a) for a in signs}
    old=max(rv.values())
    for cut in sorted(set(rv.values()))[:-1:2]:
        records=[m for m,s in rv.items() if s>cut];img=sign_columns(ops,records,n)
        for z in range(5):
            r=[rng.randrange(2*n) for i in range(n)];c=[rng.randrange(n) for j in range(n)]
            sr=[rng.choice((-1,1)) for i in range(n)];sc=[rng.choice((-1,1)) for j in range(n)]
            atom=dict(kind='reference',rows=r,columns=c,row_signs=sr,column_signs=sc)
            act=[(p+[n+i for i in p],s+s) for p,s,_,_ in ops]
            total=[[0]*n for _ in range(2*n)]
            for (p,s),(_,_,b,t) in zip(act,ops):
                for i in range(n):
                    for j in range(n):
                        total[p[r[i]]][b[c[j]]]+=s[r[i]]*t[c[j]]*sr[i]*sc[j]*k[i][j]
            mx=max(score(total,y) for y in signs)
            for limit in (1,4,256):
                cap=bound(k,ops,records,img,act,atom,cut,limit)
                assert mx<=n*cap<=n*old
                improved+=cap<old
                cases+=1
print('Exact small-game comparisons passed for',cases,'caps with truncated or complete tables.',improved,'improved on the source bound.')
