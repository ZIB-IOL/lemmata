"""Regenerate fixed groups of certified comparison games from a verified compact witness."""
import json
from pathlib import Path
def regenerate_groups(root,scheme):
    import sys
    sys.path.insert(0,str(root))
    from cover import matrix
    from band_certificate import second_endpoint
    from dictionary import item,embedded
    from games import changes
    root=Path(root);d=root/'second';w=json.loads((d/'witness.json').read_text())
    K,_,ops=second_endpoint(root,matrix(root/'base.txt'),matrix(root/'lifted_matrix.txt'),
        list(map(int,(root/'split_rows.txt').read_text().split())),matrix(root/'symmetry.txt'))
    base=matrix(root/'base.txt');n,m=len(K),len(K[0])
    assert scheme in ('blocks24',)
    records=json.loads((d/'extra_games.json').read_text())
    by_size=sorted(range(len(records)),key=lambda i:-records[i]['numerator']*records[i]['cap'])
    owners={}
    for pos,i in enumerate(by_size):owners[i]=pos if pos<22 else 22
    mats=[[[0]*m for _ in range(n)] for _ in range(23)];caps=[0]*23
    for i,r in enumerate(records):
        a=r['atom'];v=r['numerator'];u=r['cap']
        if a['kind']=='reference':
            A,_=embedded(K,ops,a,n,m,0)
        else:A,_=item(base,ops,a,n,m,K,w['reference_classical'])
        k=owners[i];caps[k]+=u*v
        for row,h in zip(mats[k],A):
            for j,x in enumerate(h):row[j]+=x*v
    H,C=changes(ops,json.loads((d/'games.json').read_text()),n,m)
    assert sum(caps)==w['dictionary_budget'] and C==w['small_game_budget']
    mats.append(H);caps.append(C)
    return mats,caps
