"""Restart rank-three alternating maximization on the fixed scaled matrix."""
import argparse,sys,json
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import quantum,norm
p=argparse.ArgumentParser();p.add_argument('candidate',type=Path);p.add_argument('out',type=Path);p.add_argument('--runs',type=int,default=24);q=p.parse_args();z=np.load(q.candidate);M=z['M'].astype(float)/int(z['scale_denominator']);A,B=z['A'],z['B'];rng=np.random.default_rng(2726);best=0;data=[]
for i in range(q.runs):
 sigma=[0,.05,.2,.6,1.0,1000000][i%6];X=norm(A+sigma*rng.normal(size=A.shape));Y=norm(B+sigma*rng.normal(size=B.shape));Q,aa,bb=quantum(M,X,Y,2500);data.append([sigma,Q]);best=max(best,Q)
q.out.write_text(json.dumps(data,indent=1)+'\n');print('restarts',len(data),'reference',data[0][1],'best',best,'range',min(x[1] for x in data),best,flush=True)
