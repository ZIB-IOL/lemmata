"""Change one entire row assignment while reoptimizing every column assignment at once."""
from pathlib import Path
import argparse,json
import numpy as np
from local_game_pricing import residual
def coordinate(M,G,I,S,rng,full=True,sweeps=4):
    I=I.copy();S=S.copy();n,m=M.shape;Y=M.T@(G[I]*S[:,None]);old=abs(Y).max(axis=1).sum();best=old;A=len(G);cols=np.arange(m)
    for it in range(sweeps):
        changed=False
        for u in rng.permutation(n):
            base=Y-M[u,:,None]*(S[u]*G[I[u]])[None,:]
            # Screen using the current optimum Bob choices, then evaluate the retained alternatives exactly.
            if full:choices=np.arange(A)
            else:
                J=abs(Y).argmax(axis=1);bs=np.where(Y[cols,J]>=0,1.,-1.);strength=abs((M[u]*bs)@G[:,J].T);h=min(14,A)
                choices=np.unique(np.r_[np.argpartition(-strength,h-1)[:h],I[u],rng.integers(A,size=3)])
            choice=I[u];sg=S[u];best=old
            for s in (-1,1):
                for part in np.array_split(choices,max(1,(len(choices)+11)//12)):
                    trial=base[None,:,:]+s*M[u,None,:,None]*G[part,None,:]
                    score=abs(trial).max(axis=2).sum(axis=1);pos=np.argmax(score)
                    if score[pos]>best+1e-10:
                        best=float(score[pos]);sg=s;choice=int(part[pos])
            if best>old+1e-10:
                I[u]=choice;S[u]=sg;Y=base+M[u,:,None]*(sg*G[choice])[None,:];old=best;changed=True
        if not changed:break
    J=abs(Y).argmax(axis=1);B=np.where(Y[cols,J]>=0,1,-1)
    return old,I,S,J,B
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('context',type=Path);p.add_argument('dictionary',type=Path);p.add_argument('out',type=Path);p.add_argument('--kind',choices=['small','reference','base'],required=True);p.add_argument('--seed',type=int,default=5382);p.add_argument('--starts',type=int,default=32);o=p.parse_args()
    R,w,K,ops=residual(o.search,o.context);rng=np.random.default_rng(o.seed);pool={};starts=[];data=json.loads(o.dictionary.read_text());kind=o.kind
    if kind=='small':
        for d in data:
            if d['kind']!='small':continue
            ent=d['entries'];rows=np.unique([e[0] for e in ent]);cols=np.unique([e[1] for e in ent]);M=np.zeros((len(rows),len(cols)),int)
            for i,j,v in ent:M[np.searchsorted(rows,i),np.searchsorted(cols,j)]+=v
            if min(M.shape)<3:continue
            den=d['classical'];v=(M*R[np.ix_(rows,cols)]).sum()/den
            starts.append((v,M,rows,np.ones(len(rows),int),den))
    else:
        M=K if kind=='reference' else np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt',int);den=320975646 if kind=='base' else 2*int(np.fromfile(o.context/'band.bin',dtype='<u4').reshape(-1,6)[:,0].max())
        for d in data:
            if d['kind']!=kind:continue
            ii=np.array(d['rows']);sa=np.array(d['row_signs']);v=abs(M.T@(sa[:,None]*R[ii])).max(axis=1).sum()/den;starts.append((v,M,ii,sa,den))
    starts.sort(key=lambda t:-t[0]);best=0
    for step in range(o.starts):
        val,M,ia,sa,den=starts[step%len(starts)]
        if step>=len(starts) or (step>12 and kind=='small' and step%3==1):
            ia=ia.copy();mutate=rng.choice(len(ia),min(len(ia),1+step%3),replace=False);ia[mutate]=rng.integers(0,len(R),size=len(mutate))
        v,ia,sa,j,b=coordinate(M.astype(float),R,ia,sa,rng,full=kind=='small',sweeps=5 if kind=='small' else 2);v/=den
        if kind=='small':
            E=M*sa[:,None]*b;J=np.unique(j);I=np.unique(ia);mm=np.zeros((len(I),len(J)),int);np.add.at(mm,(np.searchsorted(I,ia)[:,None],np.searchsorted(J,j)),E);cap=den
            small=mm.T if len(I)>len(J) else mm
            import itertools
            norms=np.asarray([(1,)+t for t in itertools.product((-1,1),repeat=len(small)-1)])@small;cap=int(abs(norms).sum(axis=1).max())
            if not cap:continue
            v=(mm*R[np.ix_(I,J)]).sum()/cap
            ent=[[int(I[r]),int(J[c]),int(mm[r,c])] for r,c in zip(*np.nonzero(mm))];item=dict(entries=ent,classical=cap,price=float(v))
        else:item=dict(rows=ia.tolist(),row_signs=sa.tolist(),columns=j.tolist(),column_signs=b.tolist(),price=float(v))
        pool[round(float(v),12)]=item
        if v>best:best=v;print('exchange',kind,step,float(v),flush=True)
    o.out.write_text(json.dumps([pool[k] for k in sorted(pool,reverse=True)],separators=(',',':'))+'\n')
if __name__=='__main__':main()
