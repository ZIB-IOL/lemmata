"""Transport a tangent axis around one orbit of column directions."""
import numpy as np
def geometry(B,pb,sb,j,character,angle):
    from scipy.linalg import null_space
    J=np.unique(pb[:,j]);loc={x:h for h,x in enumerate(J)};R=[]
    for p,s in zip(pb,sb):
        u,_,v=np.linalg.svd(B.T@(B[p]*s[:,None]));R.append(u@v)
    R=np.array(R);axis=B[j]/np.linalg.norm(B[j]);tg=np.eye(3)-axis[:,None]*axis
    fix=np.flatnonzero(pb[:,j]==j);h=next((g for g in fix if not np.array_equal(pb[g],np.arange(len(B)))),None)
    if h is None:v=np.linalg.svd(tg)[0][:,0]
    else:
        u,ww,_=np.linalg.svd(tg@(np.eye(3)+character*sb[h,j]*R[h])/2@tg)
        assert ww[0]>.99;v=u[:,0]
    tangent=[]
    for c in J:
        g=np.flatnonzero(pb[:,j]==c)[0];t=v@R[g]*sb[g,j];t-=t.dot(B[c])*B[c];tangent.append(t/np.linalg.norm(t))
    T=np.array(tangent);perm=np.array([[loc[c] for c in p[J]] for p in pb]);dot=np.einsum('hgi,hgi->hg',np.array([T@r for r in R]),T[perm]);assert np.min(abs(dot))>.995,(np.min(abs(dot)),j,character)
    se=np.where(dot>=0,1,-1);bnew=np.vstack((B,np.cos(angle)*B[J]-np.sin(angle)*T));bnew[J]=np.cos(angle)*B[J]+np.sin(angle)*T
    return J,perm,se,bnew
def lift(M,H,J):
    K=np.c_[2*M,M[:,J]-H];K[:,J]=M[:,J]+H;return K
def effective(B,J,m):
    bz=B[:m].copy();bz[J]=(B[J]+B[m:])/2
    return np.vstack((bz,(B[J]-B[m:])/2))
def classical(fields,J,m):
    y=fields[:,:m];ee=fields[:,m:];b=np.where(y>=0,1.,-1.)
    active=abs(ee)>abs(y[:,J]);b[:,J]*=~active;bs=np.c_[b,np.where(active,np.where(ee>=0,1.,-1.),0.)]
    values=abs(y).sum(axis=1)+np.maximum(0,abs(ee)-abs(y[:,J])).sum(axis=1)
    return values,bs
