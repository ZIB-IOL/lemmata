"""Use the intersection of three classical supporting planes to remove scale-grid error."""
from fractions import Fraction
from pathlib import Path
import argparse,json,math,sys
import numpy as np
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'));from search import quantum
def run(model,approx,dual,out):
    z=np.load(approx);K=np.load(model/'candidate.npz')['M'];R=np.loadtxt(prior.parent/'base.txt',dtype=int);I=np.loadtxt(model/'split_rows.txt',dtype=int);n=len(R);D=K[I]-R[I];h=len(I)//2
    pts=[]
    for p in json.loads(dual.read_text())['planes']:
        a=np.array(p['alice']);b=np.array(p['bob']);signed=(a[I]-a[n:])//2;x=a[:n].copy();x[I]=(a[I]+a[n:])//2
        ds=signed*(D@b);pts.append([int((x@R)@b),int(ds[:h].sum()),int(ds[h:].sum())])
    eq=np.array(pts[1:],dtype=object)-np.array(pts[0],dtype=object);c,x,y=eq[0];d,u,v=eq[1];det=x*v-y*u
    ss=[Fraction(y*d-c*v,det),Fraction(u*c-x*d,det)];assert all(0<s<1 for s in ss)
    den=math.lcm(*(v.denominator for v in ss));ps=[int(v*den) for v in ss];gcd=math.gcd(den,math.gcd(*ps));ps=[v//gcd for v in ps];den//=gcd
    print('exact scales',ss,'common denominator',den,flush=True)
    M0=np.vstack((2*R,R[I]));M0[I]=R[I];d=np.vstack((D[:h].astype(object)*ps[0],D[h:].astype(object)*ps[1]));mat=M0.astype(object)*den;mat[I]+=d;mat[n:]-=d
    largest=max(abs(v) for v in mat.flat);assert largest<2**63;mat=mat.astype(np.int64)
    Q,A,B=quantum(mat.astype(float)/den,z['A'],z['B'],1600);np.savez_compressed(out,M=mat,A=A,B=B,quantum=float(Q)*den,scale_numerators=np.array(ps),scale_denominator=den)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('approx',type=Path);p.add_argument('dual',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.model,a.approx,a.dual,a.out)
