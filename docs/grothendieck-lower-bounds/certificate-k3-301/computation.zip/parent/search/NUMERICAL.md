# Numerical search

The final fit uses the stored classical sign list to maximize a rank-three objective with semidefinite bounds on the remaining signings. It alternates matrix fitting and block-coordinate updates of the vector directions. The search uses Python 3.12.14 and the following library versions.

```text
numpy==2.5.5 scipy==1.18.1 cvxpy==1.9.3 clarabel==0.11.1
```

From the directory containing the main README, this command reruns the last numerical fit.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 search/sdp_dictionary.py numerical-output --extra search/extra_dictionary.json --games search/chsh_dictionary.json --moves search/transport_moves.json --warm search/warm_planes.npz --band second/band.bin --previous search/final_fit_start.npz --rounds 16 --restarts 3 --safety 2.0 --fine
```

Solver versions can change the last numerical digits. The independent integer verifier operates directly on the archived witness. The complete computation archive contains earlier fits, candidate comparisons, original source trees and large intermediate enumerations.

To convert the archived numerical winner to its integer matrix and witness, run the following from the same directory.

```sh
g++ -O3 -std=c++17 score_band.cpp -o score_band
OPENBLAS_NUM_THREADS=1 python3 search/make_band_product.py search/numerical_result.npz second/band.bin preliminary
python3 search/tighten_vectors.py preliminary regenerated
```
