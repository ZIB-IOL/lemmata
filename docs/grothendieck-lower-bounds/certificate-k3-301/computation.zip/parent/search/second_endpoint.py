"""Round a new endpoint on the jointly fitted displacement ray."""
from pathlib import Path
import numpy as np, json
from fractions import Fraction as F
R=np.loadtxt('package/base.txt',dtype=int);I=np.loadtxt('raymax/split_rows.txt',dtype=int)
K=np.loadtxt('raymax/lifted_matrix.txt',dtype=int);D=K[I]-R[I];H=np.loadtxt('high_shape/direction.txt',dtype=int)
w=np.load('extended_free/best.npz');p=w['parameters'];q=int(w['scale_denominator']);s=len(I)//2
assert p[:4].tolist()==[q]*4 and p[6]==0
num=np.r_[p[4]*D[:s],p[5]*D[s:]]+p[7]*H
# An odd rounding map preserves a possible sign reversal of an entire split pair.
up,down=103,100
def rounded(z,q):return np.sign(z)*((abs(z)+q//2)//q)
d=rounded(up*num,down*q);mat=np.vstack((2*R,R[I]-d));mat[I]=R[I]+d
path=Path('second_endpoint');path.mkdir(exist_ok=True);np.savetxt(path/'lifted_matrix.txt',mat,fmt='%d')
np.savetxt(path/'displacements.txt',d,fmt='%d');np.savetxt(path/'split_rows.txt',I,fmt='%d')
np.savez_compressed(path/'candidate.npz',M=mat,A=w['A'],B=w['B'])
(path/'recipe.json').write_text(json.dumps(dict(previous_weights=p.tolist(),denominator=q,multiplier_numerator=up,multiplier_denominator=down),indent=1)+'\n')
