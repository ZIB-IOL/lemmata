"""Fit a symmetry-invariant Bell matrix under a spectral bound on its change."""
import argparse,json,math,sys
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize._highspy import _core as native
from column_search import initial_records,signings,model
from facet import maps_for
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import orbit_basis,quantum
C=641951292
def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--band',type=Path);p.add_argument('--rounds',type=int,default=145);p.add_argument('--budget',type=int,default=418000);p.add_argument('--width',type=float,default=350);p.add_argument('--previous',type=Path);p.add_argument('--start',type=float,nargs=2,default=[.97,.97]);o=p.parse_args();o.out.mkdir(exist_ok=True,parents=True)
    z=np.load(Path(__file__).resolve().parent/'second_seed.npz');K=z['M'];A=z['A'];B=z['B'];I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);R=np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt',int);n,m=K.shape
    if o.previous:
        prev=np.load(o.previous);A,B=prev['A'],prev['B']
    maps=maps_for(K,I);idx,sg,bad=orbit_basis(*maps);nv=idx.max()+1;flat=idx.flatten();sign=sg.flatten();unit=100.;step=.01;initial=np.array(o.start)
    K0=model(K,R,I,initial);dif=np.array([model(K,R,I,np.eye(2)[i])-model(K,R,I,np.zeros(2)) for i in range(2)])
    aggregate=lambda v:np.bincount(flat,weights=v.ravel()*sign,minlength=nv)
    a=signings(o.band) if o.band else initial_records();a=a.astype(float);y0=a@K0;v0=abs(y0).sum(axis=1);sel=v0>v0.max()-850000;a=a[sel];y0=y0[sel];v0=v0[sel];ed=np.stack([a@d for d in dif]);gram=A@B.T
    H=native._Highs()
    for key,val in [('threads',1),('output_flag',False),('solver','simplex'),('primal_feasibility_tolerance',1e-7)]:H.setOptionValue(key,val)
    lb=np.r_[np.full(nv,-o.width/unit),(.88-initial)/step];ub=np.r_[np.full(nv,o.width/unit),(1-initial)/step];lb[bad]=0;ub[bad]=0
    obj=np.r_[aggregate(gram),step/unit*(dif*gram).sum(axis=(1,2))];nv2=nv+2
    H.addCols(nv2,-obj,lb,ub,0,np.zeros(nv2+1,dtype=np.int32),np.empty(0,dtype=np.int32),np.empty(0))
    seen=set();counts=[0,0];best=0.;rf=math.sqrt(n*m)
    def constraints(rows,rhs,kind):
        if not rows:return
        t=csr_matrix(np.asarray(rows,dtype=float));H.addRows(len(rows),np.full(len(rows),-native.kHighsInf),np.asarray(rhs),t.nnz,t.indptr.astype(np.int32),t.indices.astype(np.int32),t.data);counts[kind]+=len(rows)
    def classical(selected,bs):
        rows=[];rhs=[]
        for i,b in zip(selected,bs):
            fields=aggregate(a[i,:,None]*b);slopes=ed[:,i]@b;key=fields.astype(np.int16).tobytes()
            if key in seen:continue
            seen.add(key);rows.append(np.r_[fields,step/unit*slopes]);rhs.append((C-y0[i]@b)/unit)
        constraints(rows,rhs,0)
    order=np.argsort(v0)[-min(len(a),500):];classical(order,np.where(y0[order]>=0,1.,-1.))
    for it in range(o.rounds):
        H.run();assert H.getModelStatus()==native.HighsModelStatus.kOptimal
        x=np.array(H.getSolution().col_value);s=initial+step*x[-2:];d=x[:-2][idx]*sg*unit
        U,sv,V=np.linalg.svd(d,full_matrices=False);lim=o.budget*s.min()/rf
        badsv=np.flatnonzero(sv>lim*(1+2e-5));rows=[];bounds=[]
        for j in badsv[:24]:
            cp=aggregate(U[:,j,None]*V[j])
            for l in (0,1):
                ext=np.zeros(2);ext[l]=-o.budget*step/(unit*rf)
                rows.append(np.r_[cp,ext]);bounds.append(o.budget*initial[l]/(unit*rf))
        constraints(rows,bounds,1)
        ys=y0+np.tensordot(s-initial,ed,axes=1)+a@d;val=abs(ys).sum(axis=1);order=np.argsort(val)[::-1]
        excess=val[order[0]]-C;sel=order[val[order]>C+.02][:85];classical(sel,np.where(ys[sel]>=0,1.,-1.))
        shrink=min(1.,lim/(max(1.,sv[0])*1.0004));ds=d*shrink
        qs=np.rint(s*1000000).astype(int);dd=np.rint(ds*100).astype(np.int64)
        base=model(K,R,I,qs/1e6);actual=base+dd/100.;Q=float((gram*actual).sum())
        full=abs(a@actual).sum(axis=1);top=full.max()
        norm=np.linalg.svd(dd,compute_uv=False)[0]*rf/100.*1.00005
        outside=C-432000+norm/min(qs/1e6);den=max(top,outside);rr=Q/den
        if rr>best:
            best=rr;Q,aa,bb=quantum(actual,A,B,500)
            np.savez_compressed(o.out/'best.npz',scales=qs,scale_denominator=1000000,delta=dd,delta_denominator=100,A=aa,B=bb,quantum=Q,sample_classical=top,rough_outside=outside,budget=o.budget,iteration=it)
            print('improved',it,'ratio',Q/den,'candidate classical',top,'outside',outside,'scales',s.tolist(),'norm',norm,flush=True)
        if it%10==0:print('separation',it,'classical violation',round(excess,2),'singular ratio',round(sv[0]/lim,5),'constraints',counts,flush=True)
        if excess<.04 and not len(badsv):break
if __name__=='__main__':main()
