"""Price signed row and column relabelings of the certified 81 by 321 base game."""
import argparse,json
from pathlib import Path
import numpy as np
from local_game_pricing import residual
from scipy.spatial.transform import Rotation
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('wit',type=Path);p.add_argument('out',type=Path);p.add_argument('--reference',action='store_true');p.add_argument('--seed',type=int,default=7711);p.add_argument('--trials',type=int,default=200);a=p.parse_args()
    G,total,K,ops=residual(a.search,a.wit);R=np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt');z=np.load(a.search/'best.npz');X=z['A'];Y=z['B'];orig=np.load(Path(__file__).resolve().parent/'second_seed.npz')['A'][:81];I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);orig=orig.copy();P=I
    full=np.load(Path(__file__).resolve().parent/'second_seed.npz')['A'];orig[I]+=full[81:];orig/=np.linalg.norm(orig,axis=1)[:,None]
    rng=np.random.default_rng(a.seed);best=0;pool={};C=320975646
    if a.reference:
        R=K.astype(float);orig=z['A'];records=np.fromfile(a.wit/'band.bin',dtype='<u4').reshape(-1,6);C=2*int(records[:,0].max())

    for it in range(a.trials):
        rot=Rotation.random(random_state=rng).as_matrix() if it else np.eye(3);maps=orig@rot@X.T
        maps+=rng.normal(scale=[0.,.015,.12,.6][it%4],size=maps.shape) if it else 0
        ia=abs(maps).argmax(axis=1);sa=np.where(maps[np.arange(len(R)),ia]>=0,1,-1);last=0
        for _ in range(40):
            vals=R.T@(G[ia]*sa[:,None]);ib=abs(vals).argmax(axis=1);sb=np.where(vals[np.arange(R.shape[1]),ib]>=0,1,-1)
            nodes=(R*sb)@G[:,ib].T;ia=abs(nodes).argmax(axis=1);sa=np.where(nodes[np.arange(len(R)),ia]>=0,1,-1)
            val=abs(nodes).max(axis=1).sum()/C
            if abs(val-last)<1e-11:break
            last=val
        if len(pool)<45 or val>min(pool):
            pool[round(val,11)]=dict(rows=ia.tolist(),row_signs=sa.tolist(),columns=ib.tolist(),column_signs=sb.tolist(),price=val)
            if len(pool)>45:del pool[min(pool)]
        if val>best:
            best=val;print('base embedding',it,'price',val,'scalar',np.sum(K*G)/641519292,flush=True)
    a.out.write_text(json.dumps([pool[k] for k in sorted(pool,reverse=True)],separators=(',',':'))+'\n')
if __name__=='__main__':main()
