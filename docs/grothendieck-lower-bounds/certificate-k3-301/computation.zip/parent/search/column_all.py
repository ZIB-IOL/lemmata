"""Fit a column split supported on the protected rows against symmetry images of near Alice signings."""
import argparse,json,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import quantum
C=320975646
def initial_records():
    files=['raymax/sample_screen.bin','raymax/shallow_physical.bin','shape_audit/supplement.bin','raymax/active_better.bin']
    rec=np.unique(np.concatenate([np.fromfile(f,dtype='<u4').reshape(-1,6) for f in files]),axis=0)
    n=81;I=np.loadtxt('raymax/split_rows.txt',int)
    a=1-2*np.unpackbits(np.ascontiguousarray(rec[:,1:]).view(np.uint8),bitorder='little',axis=1)[:,:141].astype(np.int64)
    nr=np.memmap('near7200.bin',dtype='<u4',offset=28).reshape(-1,4)
    base=np.asarray(nr[nr[:,0]>C-240000]);orig=1-2*np.unpackbits(np.ascontiguousarray(base[:,1:]).view(np.uint8),bitorder='little',axis=1)[:,:n].astype(np.int64)
    return np.unique(np.vstack((a,np.c_[orig,orig[:,I]])),axis=0)
def signings(path):
    rec=np.fromfile(path,dtype='<u4').reshape(-1,6)
    return np.unique(1-2*np.unpackbits(np.ascontiguousarray(rec[:,1:]).view(np.uint8),bitorder='little',axis=1)[:,:141].astype(np.int64),axis=0)
def get_maps():
    s=Path('package/symmetry.txt').read_text().splitlines()
    return tuple(np.array([np.fromstring(z,sep=' ',dtype=int) for z in s[o::4]]) for o in (2,3,4,5))
def model(K,R,I,t):
    n=len(R);hd=len(I)//2;E=K[I]-R[I];d=np.vstack((t[0]*E[:hd],t[1]*E[hd:]));M=np.vstack((2.*R,R[I]-d));M[I]=R[I]+d;return M
def best_fit(P,U,vec,budget):
    # 21 signed coefficients and absolute values, all in units of 1000.
    n=len(vec);cut=np.empty((0,n));bound=[];seen=set();eye=np.eye(n);v=np.zeros(n)
    for it in range(65):
        AA=np.vstack([np.c_[eye,-eye],np.c_[-eye,-eye],np.c_[np.zeros((1,n)),np.ones((1,n))],np.c_[cut,np.zeros_like(cut)]])
        bb=np.r_[np.zeros(2*n),budget/1000.,bound]
        sol=linprog(np.r_[-vec,np.zeros(n)],A_ub=AA,b_ub=bb,bounds=[(None,None)]*n+[(0,None)]*n,method='highs');assert sol.success,sol.message
        v=sol.x[:n];y=P@v;diff=abs(y)-U
        if diff.max(initial=0)<1e-6:break
        ix=np.argpartition(diff,-min(80,len(diff)))[-min(80,len(diff)):]
        rows=[]
        for i in ix[np.argsort(diff[ix])[::-1]]:
            if diff[i]<1e-7:break
            row=P[i]*np.sign(y[i]);key=(row.tobytes(),round(U[i],8))
            if key in seen:continue
            seen.add(key);rows.append(row);bound.append(U[i])
        if not rows:break
        cut=np.vstack((cut,rows))
    return np.rint(v*1000).astype(int)
def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--band',type=Path);p.add_argument('--scales',type=float,nargs=2,default=[.97,.97]);p.add_argument('--budget',type=int,default=430000);p.add_argument('--all',action='store_true');q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
    z=np.load(Path(__file__).resolve().parent/'second_seed.npz');I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);R=np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt',int);K=z['M'];M=model(K,R,I,q.scales)
    a=signings(q.band) if q.band else initial_records();A=z['A'];B=z['B'];Q,A,B=quantum(M,A,B,2000)
    from facet import maps_for
    pa,sa,pb,sb=maps_for(K,I);Y=a@M;vals=abs(Y).sum(axis=1);H=max(2*C,vals.max());pick=vals>=H-q.budget-6000;a=a[pick];Y=Y[pick];vals=vals[pick]
    dirs=A;best=0;print('sampled Alice',len(a),'classical',H,'raw ratio',Q/H,'budget',q.budget,flush=True)
    for j in [0,1,2,4,6,7,8,9,10,42]:
        pre=np.argwhere(pb==j)[:,1];U=(H-vals[None,:]+np.abs(Y[:,pre]).T)/1000.
        mask=U<q.budget/1000.+.01;rows=[];rhs=[]
        for g in range(60):
            ix=mask[g]
            if not ix.any():continue
            sign=np.empty((ix.sum(),len(M)),dtype=np.int8);sign[:,pa[g]]=a[ix]*sa[g];rows.append(sign);rhs.append(U[g,ix])
        P=np.concatenate(rows);limits=np.concatenate(rhs);P*=P[:,0,None]
        _,positions,inv=np.unique(P,axis=0,return_index=True,return_inverse=True)
        smallest=np.full(len(positions),np.inf);np.minimum.at(smallest,inv,limits);P=np.ascontiguousarray(P[positions],dtype=float);limits=smallest
        along=M[:,j]@A;axis=along/np.linalg.norm(along);u,s,v=np.linalg.svd(axis[None,:],full_matrices=True)
        ux,vx=v[1:];winner=0
        for alpha in np.linspace(0,np.pi,4,endpoint=False):
            tangent=ux*np.cos(alpha)+vx*np.sin(alpha)
            h=best_fit(P,limits,dirs@tangent,q.budget)
            if abs(h).sum()>q.budget:h=np.trunc(h*(q.budget/abs(h).sum())).astype(int)
            dz=h@dirs;gain=(np.linalg.norm(along+dz)+np.linalg.norm(along-dz))/2-np.linalg.norm(along)
            if gain>winner:winner=gain;save=h
        print('column',j,'facets',len(P),'fixed-direction gain',winner,'ratio increment',winner/H,flush=True)
        if winner>best:
            best=winner;Hcol=save;N=np.c_[2*M,M[:,j]-Hcol];N[:,j]=M[:,j]+Hcol
            Qn,aa,bb=quantum(N,A,np.vstack((B,B[j])),1200)
            np.savez_compressed(q.out/'best.npz',column=j,displacement=save,scales=q.scales,A=aa,B=bb,quantum=Qn,verified_budget=abs(save).sum(),base_signed_max=H)
            print('best split-column sampled candidate',Qn/(2*H),'column',j,flush=True)
if __name__=='__main__':main()
