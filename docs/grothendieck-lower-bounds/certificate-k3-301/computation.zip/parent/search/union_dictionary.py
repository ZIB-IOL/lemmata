import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--dict',type=Path,nargs='+',required=True);p.add_argument('--small',type=Path,nargs='*',default=[]);p.add_argument('--base',type=Path,nargs='*',default=[]);p.add_argument('--ref',type=Path,nargs='*',default=[]);p.add_argument('--limit',type=int,default=50);a=p.parse_args()
out=[];seen=set()
def add(v):
    key=json.dumps(v,sort_keys=True)
    if key not in seen:seen.add(key);out.append(v)
for f in a.dict:
    for v in json.loads(f.read_text()):add(v)
for k,files in [('small',a.small),('base',a.base),('reference',a.ref)]:
    for f in files:
        for v in json.loads(f.read_text())[:a.limit]:add({**{s:t for s,t in v.items() if s!='price'},'kind':k})
a.out.write_text(json.dumps(out,separators=(',',':'))+'\n');print('unique assets',len(out))
