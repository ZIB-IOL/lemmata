"""Generate or update the witness and run its mathematically required second search."""
import argparse,json,struct,subprocess,sys,shutil
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
import numpy as np
sys.path[:0]=[str(Path('package').resolve()),'/workspace/k3_nov26'];from prepare_proof import unit_ball
from residual import norm_bound
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('candidate',type=Path);p.add_argument('direction',type=Path);p.add_argument('sdp',type=Path);p.add_argument('out',type=Path);p.add_argument('samples',nargs='+',type=Path);p.add_argument('--threads',type=int,default=2);p.add_argument('--reuse',action='store_true');q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 z=np.load(q.candidate);M=z['M'];den=int(z['scale_denominator']);nums=z['parameters'].tolist();p=[F(v,den) for v in nums];H=np.loadtxt(q.direction,dtype=int);U=norm_bound(H.tolist(),json.loads(q.sdp.read_text()));K=np.load(q.model/'candidate.npz')['M'];I=np.loadtxt(q.model/'split_rows.txt',dtype=int)
 sym=Path('/workspace/k3_nov26/package/symmetry.txt').read_text().splitlines();pa=np.array([np.fromstring(s,sep=' ',dtype=int) for s in sym[2::4]]);groups=[np.unique(pa[:,i]).tolist() for i in [0,6,I[0],I[len(I)//2]]];cap=min((1-abs(p[6])/p[2])/p[4]-1,1/p[5]-1);E=abs(p[7])*U/min(p[4:6]);C=320975646
 def scores(files):
    rec=np.unique(np.concatenate([np.fromfile(f,dtype='<u4').reshape(-1,6) for f in files]),axis=0);signs=1-2*np.unpackbits(np.ascontiguousarray(rec[:,1:]).view(np.uint8),bitorder='little',axis=1)[:,:len(M)].astype(np.int64)
    # Scores are below 10^18 for the chosen common grid; each column sum is smaller.
    assert int(abs(M.astype(object)).sum())<2**63
    values=np.concatenate([abs(group@M).sum(axis=1) for group in np.array_split(signs,max(1,len(signs)//450))]);i=values.argmax();return int(values[i]),signs[i].tolist()
 CL,a=scores(q.samples);meta=q.out/'screen.json';saved=q.out/'supplement.bin'
 if q.reuse:
    sd=json.loads(meta.read_text());floor=sd['comparison_floor'];T=sd['shallow_cutoff'];assert floor<=CL or saved.exists()
 else:
    floor=CL;h=F(floor,2*den);need=h-max(0,(C-h+E)/cap);T=need.numerator//need.denominator;meta.write_text(json.dumps(dict(comparison_floor=floor,shallow_cutoff=T))+'\n')
    print('signed norm',U,'attenuation',float(cap),'error',float(E),'shallow radius',C-T,'threshold',T,flush=True)
    source='near6414880.bin' if T>=314560766 else 'near7200.bin'
    assert T>=313775646,'required enumeration is deeper than the certified input'
    scale=3;sur=(scale*M+den//2)//den;err=int(abs(scale*M-den*sur).sum());gate=(scale*floor-err)//den-1-1000*scale
    path=q.out/'surrogate.txt';np.savetxt(path,sur,fmt='%d')
    subprocess.run([str(Path('shallow_fast').resolve()),'/workspace/k3_nov26/package/base.txt',str(q.model/'split_rows.txt'),source,str(T),str(q.threads),str(saved),str(path),str(gate)],check=True)
    rec=np.unique(np.fromfile(saved,dtype='<u4').reshape(-1,6),axis=0);rec.tofile(saved)
 CL,a=scores([*q.samples,saved]);D=10**15;X=unit_ball(z['A'],D);Y=unit_ball(z['B'],D);N=int(((M.astype(object)@Y)*X).sum());ratio=F(N,D**2*CL);floor14=ratio.numerator*10**14//ratio.denominator;strict=f'{floor14//10**14}.{floor14%10**14:014d}'
 w=dict(weights=nums,denominator=den,comparison_floor=floor,shallow_cutoff=T,classical=CL,alice_signs=a,quantum_numerator=N,vector_denominator=D,alice_numerators=X.tolist(),bob_numerators=Y.tolist(),base_orbits=groups,strict_lower_bound=strict)
 (q.out/'witness.json').write_text(json.dumps(w,indent=1)+'\n');np.savetxt(q.out/'matrix.txt',M,fmt='%d')
 with localcontext() as ctx:ctx.prec=48;print('ratio against supplied and supplemented strategies',Decimal(ratio.numerator)/Decimal(ratio.denominator),'classical',CL,'reference floor',floor,'supplement',saved.stat().st_size//24,flush=True)
if __name__=='__main__':main()
