"""Produce exact integer data for the second endpoint perturbation and the spectral estimate."""
import argparse,json,math,shutil,subprocess,sys
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));from band_certificate import norm
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from prepare_proof import unit_ball
def dumps(f,x):f.write_text(json.dumps(x,separators=(',',':'))+'\n')
def factor_candidate(d,z,dden,S,padding):
    # Choose positive integer reciprocal weights. A Cholesky proposal is
    # converted to integers and all of its errors are added back explicitly.
    A=z['row_diagonal'];b=z['column_diagonal']
    v=np.maximum(1,np.rint(S/np.maximum(b,1e-8))).astype(np.int64);dd=d.astype(float);G=(dd*v)@dd.T
    sd=dden**2*S;diag=np.maximum(.01,A)*sd;Y=G/np.sqrt(diag[:,None]*diag);ev=max(1.,np.linalg.eigvalsh(Y)[-1])*(1+padding)
    ai=[max(1,int(math.ceil(float(a)*ev))) for a in diag];L=np.linalg.cholesky(np.diag(np.array(ai,float))-G);factor=[list(map(int,np.rint(row[:i+1]))) for i,row in enumerate(L)]
    dl=d.tolist();vl=v.tolist();wd=[[x*y for x,y in zip(row,vl)] for row in dl];error=0
    for i,fr in enumerate(factor):
        for j in range(i+1):
            g=sum(t*x for t,x in zip(wd[i],dl[j]));h=sum(t*x for t,x in zip(fr,factor[j]))
            error+=(1 if i==j else 2)*abs((ai[i] if i==j else 0)-g-h)
    square=(sum(ai)+error)*sum(F(1,y) for y in vl);ub=math.isqrt(square.numerator//square.denominator)+1
    cert=dict(reciprocals=vl,diagonal=ai,lower_triangular=factor,error=error,upper=ub)
    return cert
def factor_certificate(d,z,dden):
    # Tighter reciprocal approximations and a smaller Cholesky margin reduce
    # the outward error. Compare every proposal using its proved integer upper.
    best=factor_candidate(d,z,dden,10**8,2e-6)
    for scale in (10**8,10**10,10**12):
        try:
            candidate=factor_candidate(d,z,dden,scale,2e-10)
        except np.linalg.LinAlgError:
            continue
        if candidate['upper']<best['upper']:
            best=candidate
    assert norm(d.tolist(),best)==best['upper']
    return best
def main():
    p=argparse.ArgumentParser();p.add_argument('approx',type=Path);p.add_argument('records',type=Path);p.add_argument('out',type=Path);o=p.parse_args();o.out.mkdir(exist_ok=True,parents=True)
    z=np.load(o.approx);dd=z['delta'];dden=int(z['delta_denominator']);q=int(z['scale_denominator']);ps=z['scales'].tolist();t=int(z['base_numerator']) if 'base_numerator' in z else q
    R=np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt',int);K=np.loadtxt(Path(__file__).resolve().parents[1]/'second/endpoint.txt',int);I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);n=len(R);k=len(I);dif=K[I]-R[I];D=10**15
    assert q%dden==0 and all(0<p<=t for p in ps)
    e=np.vstack((ps[0]*dif[:k//2],ps[1]*dif[k//2:]));M=np.vstack((2*t*R,t*R[I]-e));M[I]=t*R[I]+e;M+=dd*(q//dden)
    transport='transport' in z
    if transport:
        W=z['transport'];M=K@W+dd*(q//dden);mass=int(abs(W).sum(axis=1).max())
        np.savetxt(o.out/'transport.txt',W,fmt='%d')
    game_budget=0;terms=[]
    if 'games' in z:
        from games import changes
        from facet import maps_for
        pa,sa,pb,sb=maps_for(K,I);perms=list(zip(pa.tolist(),sa.tolist(),pb.tolist(),sb.tolist()))
        for g,val in zip(z['games'].tolist(),z['game_numerators'].tolist()):
            i,h,j,l,s1,s2=g
            if val:
                entries=[[i,j,s1],[h,j,s1],[i,l,s2],[h,l,-s2]]
                terms.append(dict(numerator=int(val),entries=entries,classical=2))
        add,game_budget=changes(perms,terms,len(K),K.shape[1]);M+=np.array(add,dtype=np.int64)
        dumps(o.out/'games.json',terms)
    dictionary_budget=0;emb=[];ref_cap=2*int(np.fromfile(o.records,dtype='<u4').reshape(-1,6)[:,0].max())
    if 'extra_dictionary' in z:
        from dictionary import item
        pa,sa,pb,sb=maps_for(K,I);perms=list(zip(pa.tolist(),sa.tolist(),pb.tolist(),sb.tolist()))
        for desc,value in zip(json.loads(str(z['extra_dictionary'])),z['extra_numerators'].tolist()):
            if not value:continue
            part,cc=item(R.tolist(),perms,desc,len(K),K.shape[1],K.tolist(),ref_cap);M+=int(value)*np.asarray(part,dtype=np.int64);dictionary_budget+=int(value)*cc
            emb.append(dict(atom=desc,numerator=int(value),cap=cc))
        dumps(o.out/'extra_games.json',emb)
    np.savetxt(o.out/'matrix.txt',M,fmt='%d');np.savetxt(o.out/'delta.txt',dd,fmt='%d')
    for f,v in [('recipe.json',Path(__file__).resolve().parents[1]/'second/recipe.json'),('endpoint.txt',Path(__file__).resolve().parents[1]/'second/endpoint.txt')]:shutil.copyfile(v,o.out/f)
    cert=factor_certificate(dd,z,dden);dumps(o.out/'norm.json',cert)
    raw=np.unique(np.fromfile(o.records,dtype='<u4').reshape(-1,6),axis=0);raw.tofile(o.out/'band.bin')
    rep=json.loads(subprocess.check_output([str(Path('score_band').resolve()),str(o.out/'matrix.txt'),str(o.out/'band.bin'),str(o.out/'endpoint.txt'),str(320975646-216000)],text=True))
    att=rep['maximum'];win=[1-2*((rep['mask'][i//32]>>(i%32))&1) for i in range(len(M))]
    outside=2*t*(320975646-216000)+F(cert['upper']*q*t,dden*min(ps));outside=2*mass*(320975646-216000)+F(cert['upper']*q,dden) if transport else outside;outside+=game_budget+dictionary_budget;cl=max(F(att),outside)
    X=unit_ball(z['A'],D);Y=unit_ball(z['B'],D);N=int(((M.astype(object)@Y)*X).sum());rate=F(N,D*D)/cl;v=rate.numerator*10**14//rate.denominator
    w=dict(scale_denominator=q,base_numerator=t,scale_numerators=ps,delta_denominator=dden,reference_margin=216000,records=len(raw),outside_numerator=outside.numerator,outside_denominator=outside.denominator,classical_upper_numerator=cl.numerator,classical_upper_denominator=cl.denominator,attained=att,classical_alice_signs=win,vector_denominator=D,alice_numerators=X.tolist(),bob_numerators=Y.tolist(),quantum_numerator=N,strict_lower_bound=f'{v//10**14}.{v%10**14:014d}')
    if transport:w.update(comparison='column contractions',transport_mass=mass)
    if emb:w.update(dictionary_budget=dictionary_budget,reference_classical=ref_cap)
    if terms:w.update(small_game_budget=game_budget)
    dumps(o.out/'witness.json',w)
    with localcontext() as c:c.prec=48;print('ratio',Decimal(rate.numerator)/Decimal(rate.denominator),'upper',cl,'attained',att,'outside minus attained (normalized)',float((outside-att)/q),'residual norm',cert['upper']/dden,'patterns',len(raw),flush=True)
if __name__=='__main__':main()
