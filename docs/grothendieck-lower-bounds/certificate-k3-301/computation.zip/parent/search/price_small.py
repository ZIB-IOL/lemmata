"""Search short, exactly solvable coefficient matrices against a residual correlation table."""
from pathlib import Path
import argparse,json,itertools,sys
import numpy as np
from scipy.sparse import csr_matrix,hstack,identity,coo_matrix
from scipy.optimize import linprog
from local_game_pricing import residual,price
def lp_shapes(k,h):
    S=np.array([(1,)+t for t in itertools.product((-1,1),repeat=k-1)],dtype=int);m0=len(S)*h
    eq=np.arange(m0);rows=np.repeat(eq,k);col=(np.tile(np.arange(k),m0)*h+np.repeat(np.tile(np.arange(h),len(S)),k));val=np.repeat(S,h,axis=0).ravel()
    P=coo_matrix((val,(rows,col)),shape=(m0,k*h)).tocsr();t=identity(m0,format='csr');zero=csr_matrix((len(S),k*h));mass=coo_matrix((np.ones(m0),(np.repeat(np.arange(len(S)),h),np.arange(m0))),shape=(len(S),m0)).tocsr()
    from scipy.sparse import vstack
    U=vstack((hstack((P,-t)),hstack((-P,-t)),hstack((zero,mass)))).tocsr();rhs=np.r_[np.zeros(2*m0),np.ones(len(S))]
    bounds=[(None,None)]*(k*h)+[(0,None)]*m0
    return S,U,rhs,bounds
def reduce(R,I,J,E):
    for it in range(10):
        prod=E.T@R[I];idx=np.argmax(abs(prod),axis=1);sg=np.where(prod[np.arange(len(idx)),idx]>=0,1,-1);J=idx;E=E*sg
        pp=R[:,J]@E.T;ii=np.argmax(abs(pp),axis=0);ss=np.where(pp[ii,np.arange(len(ii))]>=0,1,-1);I=ii;E=E*ss[:,None]
    return I,J,E
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('witness',type=Path);p.add_argument('out',type=Path);p.add_argument('--steps',type=int,default=55);p.add_argument('--k',type=int,default=5);p.add_argument('--h',type=int,default=10);p.add_argument('--seed',type=int,default=771);o=p.parse_args();G,total,K,ops=residual(o.search,o.witness);rng=np.random.default_rng(o.seed);k,h=o.k,o.h;S,P,rhs,bounds=lp_shapes(k,h);rank=price(G);store={};best=0
    for z in range(o.steps):
        start=rank[rng.integers(min(600,len(rank)))][1];i,j,x,y,_,_=start;I=np.array([i,j]+rng.choice(len(G),k-2,replace=False).tolist())
        trial=S@G[I];idx=np.argmax(abs(trial),axis=1);J=list(dict.fromkeys([x,y,*idx.tolist()]))
        rng.shuffle(J);J=J[:h];J=np.array(J+rng.choice(G.shape[1],h-len(J),replace=False).tolist())
        res=linprog(np.r_[-G[np.ix_(I,J)].ravel(),np.zeros(len(S)*h)],A_ub=P,b_ub=rhs,bounds=bounds,method='highs')
        if not res.success:continue
        E=res.x[:k*h].reshape(k,h);I,J,E=reduce(G,I,J,E);E=np.rint(E*1200).astype(int)
        rr=sorted(set(I));cc=sorted(set(J));mat=np.zeros((len(rr),len(cc)),int)
        for i,row in zip(I,E):
            for j,v in zip(J,row):mat[rr.index(i),cc.index(j)]+=v
        div=np.gcd.reduce(abs(mat.ravel()));mat//=max(1,div);use=np.where(np.any(mat,axis=1))[0];usej=np.where(np.any(mat,axis=0))[0];M=mat[np.ix_(use,usej)];ii=np.array(rr)[use];jj=np.array(cc)[usej]
        if min(M.shape)<=1:continue
        cs=max(abs(np.asarray(s)@M).sum() for s in itertools.product((-1,1),repeat=len(ii)));val=float((M*G[np.ix_(ii,jj)]).sum()/cs)
        entries=sorted([int(i),int(j),int(M[a,b])] for a,i in enumerate(ii) for b,j in enumerate(jj) if M[a,b])
        if min(M.shape)>=4:store[tuple(map(tuple,entries))]=dict(entries=entries,classical=int(cs),price=val)
        if val>best:best=val;print('small',z,'price',val,'CHSH',rank[0][0],'active shape',M.shape,'classical',cs,flush=True)
    result=sorted(store.values(),key=lambda d:-d['price']);o.out.write_text(json.dumps(result,separators=(',',':'))+'\n');print('multirow atoms',len(result),'best',result[0]['price'] if result else None,flush=True)
if __name__=='__main__':main()
