"""Jointly vary the four original row orbits, the two displacements, and the invariant shear."""
import argparse,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from rectangle import fields
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'));from search import quantum
def setup(model,hitfile,extra=None):
 z=np.load(model/'candidate.npz');K=z['M'];R=np.loadtxt(prior.parent/'base.txt',dtype=int);I=np.loadtxt(model/'split_rows.txt',dtype=int);n=len(R);k=len(I);h=k//2;D=K[I]-R[I]
 sy=(prior.parent/'symmetry.txt').read_text().splitlines();pa=np.array([np.fromstring(s,sep=' ',dtype=int) for s in sy[2::4]])
 group=[np.unique(pa[:,i]) for i in [0,6,I[0],I[h]]];assert sorted(np.concatenate(group))==list(range(n))
 mats=[]
 for J in group:
    base=np.zeros_like(R);base[J]=R[J];M=np.vstack((2*base,base[I]));M[I]=base[I];mats.append(M)
 for comp in [np.vstack((D[:h],np.zeros_like(D[h:]))),np.vstack((np.zeros_like(D[:h]),D[h:])),np.vstack((R[I[:h]],np.zeros_like(D[h:])))]:
    M=np.vstack((np.zeros_like(R),-comp));M[I]=comp;mats.append(M)
 mats=np.array(mats);hits=np.unique(np.fromfile(hitfile,dtype='<u4').reshape(-1,6),axis=0);hits=hits[hits[:,0]>320975646];
 if extra is not None:hits=np.concatenate((hits,np.fromfile(extra,dtype='<u4').reshape(-1,6)))
 a=np.unique(fields(R,I,D,hits)[0].astype(np.int8),axis=0).astype(np.int64)
 # The support at every corner must cover all untwisted shear directions.
 from facet import maps_for
 P,S,_,_=maps_for(K,I);assert np.all(P[:,I[:h]]<n)
 return z,mats,a,group
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('out',type=Path);p.add_argument('--grid',type=int,default=100000000);p.add_argument('--supplement',type=Path);p.add_argument('--physical',action='store_true');q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 z,mats,a,group=setup(q.model,q.hits,q.supplement);F=np.asarray([a@m for m in mats]);C=641951292;K=z['M'];bounds=[(.97,1)]*4+[(0,1),(0,1),(-.97,.97)]
 def score(t):
    y=np.tensordot(t,F,axes=1);v=abs(y).sum(axis=1);i=v.argmax();b=np.where(y[i]>=0,1,-1);g=F[:,i]@b;return (v[i] if q.physical else max(C,v[i])),g
 cs={};best=0
 for start in [[1,1,1,1,.94,.94,0],[.999,.999,1,1,.95,.98,.02],[1,1,.9998,1,.95,.95,-.01]]:
    t=np.array(start);A,B=z['A'],z['B']
    for i in range(30):
      M=np.tensordot(t,mats,axes=1);Q,A,B=quantum(M,A,B,600);grad=(mats*(A@B.T)).sum(axis=(1,2));val,cut=score(t);rr=Q/val;old=t.copy()
      for _ in range(130):
        cs[tuple(cut.tolist())]=cut
        P=[[*list(g/1e6),-1] for g in cs.values()];P.extend([[0]*7+[-1],[0,0,0,0,.97,0,1,0],[0,0,0,0,.97,0,-1,0]])
        rhs=[0]*len(cs)+[-C/1e6,.97,.97];
        if q.physical:del P[len(cs)];del rhs[len(cs)]
        sol=linprog(np.r_[-grad/1e6,rr],A_ub=P,b_ub=rhs,bounds=bounds+[(0,None)],method='highs');assert sol.success
        t=sol.x[:-1];val,cut=score(t);rr2=t@grad/val
        if val-sol.x[-1]*1e6<.0007 and abs(rr2-rr)<1e-12:break
        rr=rr2
      if q.physical:t=t/max(max(t[:4]),t[5],t[4]+abs(t[6])/.97)
      t=np.rint(t*q.grid)/q.grid
      if abs(t-old).max()<2e-8:break
    Q,A,B=quantum(np.tensordot(t,mats,axes=1),A,B,1400);den,gg=score(t);ratio=Q/den;print('weights',t.tolist(),'ratio',ratio,'classical upper',den,'sampled attained',gg@t,flush=True)
    if ratio>best:
       best=ratio;ps=np.rint(t*q.grid).astype(int);M=np.tensordot(ps,mats,axes=1);np.savez_compressed(q.out/'best.npz',M=M,A=A,B=B,quantum=Q*q.grid,parameters=ps,scale_denominator=q.grid)
if __name__=='__main__':main()
