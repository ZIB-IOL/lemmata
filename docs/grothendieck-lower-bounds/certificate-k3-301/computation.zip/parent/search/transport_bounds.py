from pathlib import Path
import numpy as np,json,sys
from facet import maps_for
def gradient(path,wit):
    z=np.load(path/'dual_numpy.npz');w=json.loads((wit/'witness.json').read_text());K=np.loadtxt(wit/'endpoint.txt',int);I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);pa,sa,pb,sb=maps_for(K,I)
    X=np.array(w['alice_numerators'])/w['vector_denominator'];Y=np.array(w['bob_numerators'])/w['vector_denominator']
    G=X@Y.T-z['alice'].T.astype(float)@(z['weights'][:,None]*z['bob']);W=K.T@G;ave=np.zeros_like(W)
    for p,s in zip(pb,sb):ave[np.ix_(p,p)]+=W*s[:,None]*s
    return ave/len(pb),sum(z['weights']),pb,sb
if __name__=='__main__':
    A,total,pb,sb=gradient(Path('anchor_guided'),Path('guided_test'));print('current scalar',np.trace(A)/641519292,'signed transport',abs(A).max(axis=1).sum()/641519292,'result retained',total+abs(A).max(axis=1).sum()/641519292)
    for j in [0,1,2,4,6,7,8,9,10,42]:print(j,'diagonal',round(A[j,j]),'largest',round(abs(A[j]).max()),'destination',abs(A[j]).argmax())
