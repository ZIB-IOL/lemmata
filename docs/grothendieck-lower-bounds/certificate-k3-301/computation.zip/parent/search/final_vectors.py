"""Test independent rank-three vector starts on the chosen integer matrix."""
import argparse,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import norm
def solve(M,A,B,steps):
    # Optimize at the original objective scale so the stopping rule covers
    # changes of about two machine ulps at a score of order one.
    old=-1.
    for i in range(steps):
        B=norm(M.T@A);A=norm(M@B)
        if i%12==11:
            value=np.einsum('ij,ij->',A,M@B)
            if abs(value-old)<2e-15:break
            old=value
    return np.einsum('ij,ij->',A,M@B),A,B,i+1
def main():
    p=argparse.ArgumentParser();p.add_argument('matrix',type=Path);p.add_argument('out',type=Path);p.add_argument('--starts',type=int,default=36);a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True)
    w=json.loads((a.matrix/'witness.json').read_text());M=np.loadtxt(a.matrix/'matrix.txt');C=w['classical_upper_numerator']/w['classical_upper_denominator'];M/=C
    X=np.array(w['alice_numerators'],float)/w['vector_denominator'];Y=np.array(w['bob_numerators'],float)/w['vector_denominator'];rng=np.random.default_rng(26112731);results=[];best=0.
    for j in range(a.starts):
        if j==0:A=X;B=Y
        elif j%4==0:A=norm(X+rng.normal(size=X.shape)*[.12,.45,1.2][(j//4)%3]);B=Y
        else:A=norm(rng.normal(size=X.shape));B=norm(rng.normal(size=Y.shape))
        q,A,B,steps=solve(M,A,B,2000);results.append((j,float(q),steps))
        if q>best:best=q;np.savez_compressed(a.out/'best.npz',A=A,B=B)
    (a.out/'restarts.json').write_text(json.dumps(results)+'\n');print('stored start',results[0][1],'best',best,'worst',min(r[1] for r in results),'starts',len(results),'iterations',min(r[2] for r in results),max(r[2] for r in results),flush=True)
if __name__=='__main__':main()
