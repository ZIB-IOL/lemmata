"""Recover a rational vertex, and certify the fixed-vector optimization by nonnegative linear combinations."""
import argparse,json,math,sys
from decimal import Decimal,localcontext
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from reweight import setup
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'));from search import quantum
from prepare_proof import unit_ball
C=641951292
def rsolve(aa,bb):
 n=len(bb);A=[[F(int(t)) for t in row]+[F(y)] for row,y in zip(aa,bb)]
 for i in range(n):
    k=next((k for k in range(i,n) if A[k][i]),None)
    if k is None:return None
    A[i],A[k]=A[k],A[i];piv=A[i][i];A[i]=[v/piv for v in A[i]]
    for k in range(n):
        if k!=i and A[k][i]:
           piv=A[k][i];A[k]=[u-piv*v for u,v in zip(A[k],A[i])]
 return [r[-1] for r in A]
def domain():
 # Inequalities written g0+g*theta >= 0, with integral coefficients.
 E=np.eye(7,dtype=int);out=[]
 for j in range(4):out.extend([[-97,*list(100*E[j])],[1,*list(-E[j])]])
 for j in [4,5]:out.extend([[0,*list(E[j])],[1,*list(-E[j])]])
 out.extend([[97,*list(-97*E[4]+100*E[6])],[97,*list(-97*E[4]-100*E[6])]])
 return [list(map(int,row)) for row in out]
def normals(a,mats,t,extra=()):
 # Include exact classical affine lower planes from signs at the trial point and its neighbours.
 forms=np.stack([a@M for M in mats]);points=[t]
 for it in range(7):
    for eps in [-1e-5,1e-5]:s=t.copy();s[it]+=eps;points.append(s)
 pool={}
 for s in points:
    y=np.tensordot(s,forms,axes=1);vals=abs(y).sum(axis=1);sel=np.argsort(vals)[-min(len(a),100):];bs=np.where(y[sel]>=0,1,-1)
    h=np.stack([(v[sel]*bs).sum(axis=1) for v in forms],axis=1)
    for co,i,b in zip(h,sel,bs):pool.setdefault(tuple(map(int,co)),(a[i].tolist(),b.tolist()))
 return pool,forms
def dual(v,planes,allow_constant,dom):
 # Match the affine form, using actual signed payoffs, an optional certified
 # ceiling on the complementary strategies, and negative domain slack functions.
 entries=[([0,*p],1,'sign',p) for p in planes]
 if allow_constant:entries.append(([C,0,0,0,0,0,0,0],1,'floor',None))
 entries.extend([([-x for x in row],0,'domain',row) for row in dom])
 aa=np.array([e[0] for e in entries],dtype=float).T;cc=np.array([e[1] for e in entries],dtype=float);v=np.array(v,dtype=object)
 # Rescale each column to make physical sign payoffs and unit box facets comparable.
 fac=np.array([1. if e[1] else 1e7 for e in entries]);A=aa*fac
 rownorm=np.maximum(1,abs(A).max(axis=1));res=linprog(cc*fac,A_eq=A/rownorm[:,None],b_eq=np.asarray(v,dtype=float)/1e30/rownorm,bounds=(0,None),method='highs');assert res.success,res.message
 indices=np.where(res.x>1e-10)[0].tolist()
 if len(indices)>8 or not indices:return None
 cols=[[entries[j][0][i] for j in indices] for i in range(8)];use=[]
 for i in range(8):
    mat=np.array([cols[j] for j in use+[i]],dtype=float)
    mat=mat/np.maximum(abs(mat).max(axis=1,keepdims=True),1)
    if np.linalg.matrix_rank(mat,tol=1e-12)>len(use):use.append(i)
 if len(use)!=len(indices):return None
 w=rsolve([cols[i] for i in use],[v[i] for i in use])
 if w is None or min(w)<0 or any(sum(F(t)*s for t,s in zip(row,w))!=y for row,y in zip(cols,v)):return None
 U=sum(e*entries[j][1] for j,e in zip(indices,w))/10**30
 parts=[]
 for j,s in zip(indices,w):
    _,_,typ,data=entries[j];t={'kind':typ,'weight_numerator':s.numerator,'weight_denominator':s.denominator}
    if typ=='sign':t['alice'],t['bob']=planes[data]
    elif typ=='domain':t['affine_slack']=data
    parts.append(t)
 return {'numerator':U.numerator,'denominator':U.denominator,'terms':parts}
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('approx',type=Path);p.add_argument('out',type=Path);p.add_argument('--physical',action='store_true');p.add_argument('--supplement',type=Path);p.add_argument('--shallow-cut',type=int,default=320525646);q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 z,mats,a,groups=setup(q.model,q.hits,q.supplement);r=np.load(q.approx);t=r['parameters']/int(r['scale_denominator']);n=len(z['M']);dom=domain()
 # Include the known matched baseline strategy, which can give a physical guard on the whole family.
 orig=np.loadtxt(Path(__file__).resolve().parent/'base_attaining_signs.txt',dtype=int);I=np.loadtxt(q.model/'split_rows.txt',dtype=int);anchor=np.r_[orig,orig[I]];a=np.vstack((a,anchor));planes,forms=normals(a,mats,t);T=abs(np.tensordot(t,forms,axes=1)).sum(axis=1).max();T=T if q.physical else max(T,C);cp=[]
 # Equations in theta_1,...,theta_7,T. Residuals are measured at the numerical vertex.
 if not q.physical:cp.append((abs(T-C),[0]*7+[1],C))
 for row in dom:
    dz=abs(row[0]+np.array(row[1:])@t);cp.append((dz*1e6,row[1:]+[0],-row[0]))
 for u in planes:cp.append((abs(np.array(u,dtype=float)@t-T),list(u)+[-1],0))
 eq=[];rhs=[]
 for diff,row,b in sorted(cp,key=lambda r:r[0]):
    v=np.array(eq+[row],dtype=float);v=v/np.maximum(abs(v).max(axis=1,keepdims=True),1)
    if np.linalg.matrix_rank(v,tol=1e-12)>len(eq):eq.append(row);rhs.append(b)
    if len(eq)==8:break
 assert len(eq)==8;out=rsolve(eq,rhs);tt=out[:7];assert max(abs(float(a)-b) for a,b in zip(tt,t))<1e-5,(tt,t)
 assert all(row[0]+sum(x*y for x,y in zip(row[1:],tt))>=0 for row in dom)
 den=math.lcm(*(x.denominator for x in tt));ps=[int(x*den) for x in tt]
 ob=[np.asarray(f,dtype=object) for f in forms];ef=sum(x*f for x,f in zip(ps,ob));scores=abs(ef).sum(axis=1);imax=scores.argmax();CL=int(scores[imax]);CS=CL if q.physical else max(C*den,CL)
 assert CS==CL and CS==out[-1]*den,(CL,CS,out[-1])
 fm=np.tensordot(np.asarray(ps,dtype=object),mats.astype(object),axes=1)
 M=np.tensordot(np.array(list(map(float,tt))),mats,axes=1);Q,A,B=quantum(M,r['A'],r['B'],1600);X=unit_ball(A,10**15);Y=unit_ball(B,10**15)
 v=[0]+[int(((m.astype(object)@Y)*X).sum()) for m in mats];N=sum(int(x)*y for x,y in zip(ps,v[1:]));ratio=F(N,10**30*CS)
 result={'weights':ps,'denominator':den,'vector_denominator':10**15,'quantum_numerator':N,'classical':CS,'alice_signs':a[imax].tolist(),'alice_numerators':X.tolist(),'bob_numerators':Y.tolist(),'base_orbits':[g.tolist() for g in groups]}
 if q.physical:
    kap=min((1-abs(tt[6])/tt[2])/tt[4]-1,1/tt[5]-1);assert kap>0
    H=F(CS,2*den);required=H-(C/2-H)/kap if H<C//2 else H
    required=H-(F(C,2)-H)/kap if H<F(C,2) else H
    assert required>=q.shallow_cut,(float(required),q.shallow_cut)
    result.update(shallow_cutoff=q.shallow_cut,kappa_numerator=kap.numerator,kappa_denominator=kap.denominator)
    print('shallow mass factor',float(kap),'required lower residual norm',float(required),'shallow proof cutoff',q.shallow_cut,flush=True)
 (q.out/'result.json').write_text(json.dumps(result,indent=1)+'\n');np.savetxt(q.out/'final_matrix.txt',fm,fmt='%s')
 for flag,name in ([(False,'physical_dual')] if q.physical else [(True,'certificate_dual'),(False,'physical_dual')]):
    cert=dual(v,planes,flag,dom)
    if cert:
       (q.out/(name+'.json')).write_text(json.dumps(cert,indent=1)+'\n');up=F(cert['numerator'],cert['denominator']);print(name,'gap',float(up-ratio),'bound',float(up),flush=True)
 with localcontext() as ctx:
    ctx.prec=53;print('exact verified against supplied list',Decimal(ratio.numerator)/Decimal(ratio.denominator),'q',den,'p',ps,'classical',CS,'N',N,'active',len(a)-1,flush=True)
if __name__=='__main__':main()
