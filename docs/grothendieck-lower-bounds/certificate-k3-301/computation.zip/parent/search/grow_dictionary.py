"""Extend the finite comparison library using full-game row and column relabelings."""
import argparse,json,os,subprocess,sys
from pathlib import Path
import numpy as np
from local_game_pricing import residual,price
from game_atoms import atom_key
from facet import orbit_basis
from pricing_context import create
def run(cmd,log):
    with open(log,'w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('--prev',type=Path,default=Path('dict2'));p.add_argument('--extra',type=Path,default=Path('extra_dict2.json'));p.add_argument('--games',type=Path,default=Path('dict2_games.json'));p.add_argument('--label',default='grow');p.add_argument('--times',type=int,default=9);p.add_argument('--seed',type=int,default=873);p.add_argument('--batch',type=int,default=24);p.add_argument('--samples',type=int,default=400);p.add_argument('--first-base',type=Path);p.add_argument('--first-ref',type=Path);p.add_argument('--safety',type=float,default=25.);q=p.parse_args()
    prev=q.prev;gp=q.games;xp=q.extra;last_ratio=0;slow=0
    for it in range(1,q.times+1):
        name=f'{q.label}{it}';out=Path(name);c=Path(name+'_input')
        band=Path('second_endpoint/band_unique.bin');band=band if band.exists() else Path('second_endpoint/guidance.bin')
        create(prev,band,c);G,ws,K,ops=residual(prev,c);ranked=price(G);z=abs(K.T@G).max(axis=1).sum()/641519292
        files=[]
        for kind,provided in [('base',q.first_base),('reference',q.first_ref)]:
            f=provided if it==1 and provided is not None else Path(name+'_'+kind+'_pricing.json')
            if f!=provided or it!=1:
                args=[sys.executable,'price_base.py',str(prev),str(c),str(f),'--trials',str(q.samples),'--seed',str(q.seed+it*811+(kind=='reference'))]
                if kind=='reference':args+=['--reference']
                run(args,name+'_'+kind+'_pricing.log')
            files.append(f)
        ext=json.loads(xp.read_text());seen={json.dumps(v,sort_keys=True) for v in ext};newcount=0;high=z
        for kind,f in zip(('base','reference'),files):
            source=json.loads(f.read_text());high=max(high,source[0]['price'])
            for entry in source[:q.batch]:
                if entry['price']<z+.000005:break
                item={**{k:v for k,v in entry.items() if k!='price'},'kind':kind};key=json.dumps(item,sort_keys=True)
                if key not in seen:seen.add(key);ext.append(item);newcount+=1
        games=json.loads(gp.read_text());grid,sign,bad=orbit_basis(*ops);forbid=set(bad);used={atom_key(g,grid,sign,forbid) for g in games};nc=0
        for price0,g in ranked:
            if price0<=z+.000005:break
            key=atom_key(g,grid,sign,forbid)
            if key and key not in used:
                games.append(g);used.add(key);nc+=1
                if nc>=100:break
        zz=np.load(prev/'best.npz');rr=float(zz['quantum']/zz['sample_classical']) if zz['quantum'].ndim==0 else max(float(l.split('ratio ')[1].split()[0]) for l in Path(str(prev)+'.log').read_text().splitlines() if l.startswith('solve '));gain=rr-last_ratio if last_ratio else 1.;slow=slow+1 if gain>=-1e-8 and gain<5e-8 else 0
        print('round',it,'previous',prev,'observed',rr,'change',gain,'prices compared with',z,'CHSH excess',ranked[0][0]-z,'full-game excess',high-z,'new games',nc,newcount,'pool',len(ext),band.name,flush=True)
        if (not nc and not newcount) or (slow>=2 and band.name=='band_unique.bin' and max(high,ranked[0][0])-z<.00015):break
        xp=Path(name+'_dictionary.json');gp=Path(name+'_chsh.json');xp.write_text(json.dumps(ext,separators=(',',':'))+'\n');gp.write_text(json.dumps(games,separators=(',',':'))+'\n')
        run(['/workspace/k3_sdp_env/bin/python','-u','sdp_dictionary.py',name,'--extra',str(xp),'--games',str(gp),'--warm',str(prev/'plane_pool.npz'),'--band',str(band),'--previous',str(prev/'best.npz'),'--rounds','16','--restarts','3','--safety',str(q.safety),'--fine'],name+'.log')
        last_ratio=rr;prev=out
    print('latest',prev,xp,gp,flush=True)
if __name__=='__main__':main()
