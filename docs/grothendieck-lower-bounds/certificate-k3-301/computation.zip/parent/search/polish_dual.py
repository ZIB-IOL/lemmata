"""Prove a global upper for the ratio of the fixed vector directions under all two-scale variations."""
from fractions import Fraction
from itertools import combinations
import numpy as np
from scipy.optimize import linprog

def solve(A,b):
    a=[[Fraction(t) for t in row]+[Fraction(y)] for row,y in zip(A,b)]
    for i in range(3):
        k=next((j for j in range(i,3) if a[j][i]),None)
        if k is None:return
        a[i],a[k]=a[k],a[i];f=a[i][i];a[i]=[v/f for v in a[i]]
        for j in range(3):
            if j!=i:
                f=a[j][i];a[j]=[v-f*w for v,w in zip(a[j],a[i])]
    return [row[-1] for row in a]
def calculate(R,I,E,signs,anchor,X,Y,den,ps,q):
    n,m=R.shape;h=len(I)//2;X=np.asarray(X,dtype=object);Y=np.asarray(Y,dtype=object)
    zero=np.vstack((2*R,R[I]));zero[I]=R[I];Z=[]
    for g in range(2):
        d=np.zeros_like(E);d[h*g:h*(g+1)]=E[h*g:h*(g+1)];z=np.vstack((np.zeros_like(R),-d));z[I]=d;Z.append(z)
    mats=[zero,*Z];v=[int(((M.astype(object)@Y)*X).sum()) for M in mats]
    a=np.unique(np.vstack((signs,anchor)),axis=0).astype(np.int64);s=np.asarray(ps)/q;f=[a@M for M in mats];y=f[0]+s[0]*f[1]+s[1]*f[2];values=abs(y).sum(axis=1);top=values.max()
    pool={};focus=np.argsort(values)[-min(len(a),90):]
    for ds in ([0,0],[1e-5,0],[-1e-5,0],[0,1e-5],[0,-1e-5],[.0005,.0005],[-.0005,-.0005]):
        b=np.where(f[0][focus]+(s[0]+ds[0])*f[1][focus]+(s[1]+ds[1])*f[2][focus]>=0,1,-1)
        coeff=np.column_stack([(z[focus]*b).sum(axis=1) for z in f])
        for row,i,bits in zip(coeff,focus,b):pool.setdefault(tuple(map(int,row)),(a[i].tolist(),bits.tolist()))
    P=list(pool);arr=np.array(P).T.astype(float);v0=np.asarray(v,dtype=float)/den**2
    scales=np.maximum(abs(arr).max(axis=1),1)
    # Positive signed planes majorize the fixed vector form for the complete two-parameter family.
    res=linprog(np.ones(len(P)),A_eq=arr/scales[:,None],b_eq=v0/scales,bounds=(0,None),method='highs')
    if not res.success:return None
    basis=np.where(res.x>1e-9)[0].tolist()
    if len(basis)<3:basis+=list(set(range(len(P)))-set(basis))[:8]
    for inds in combinations(basis,3):
        coeff=[[P[j][i] for j in inds] for i in range(3)];w=solve(coeff,v)
        if w is None or min(w)<0:continue
        upper=sum(w)/den**2
        return dict(upper_numerator=upper.numerator,upper_denominator=upper.denominator,
                    planes=[dict(alice=pool[P[j]][0],bob=pool[P[j]][1],weight_numerator=z.numerator,weight_denominator=z.denominator) for j,z in zip(inds,w)])
