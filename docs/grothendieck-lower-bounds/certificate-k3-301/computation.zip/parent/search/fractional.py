"""Choose an icosahedral fractional covering block using finite sign payoffs, then check it exactly."""
import argparse,json,math,subprocess
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
C=320975646;prior=Path('/workspace/k3_nov26')
def sgn(x):return np.where(x>=0,1.,-1.)
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('out',type=Path);p.add_argument('--t',type=int,default=16);p.add_argument('--counts',type=int,nargs='+',default=[1,3,7,7]);p.add_argument('--iter',type=int,default=55);p.add_argument('--seed',type=int,default=4113);q=p.parse_args();q.out.mkdir(parents=True,exist_ok=True)
 R=np.loadtxt(prior/'package/base.txt',dtype=int);I=np.loadtxt(q.model/'split_rows.txt',dtype=int,ndmin=1);K=np.loadtxt(q.model/'lifted_matrix.txt',dtype=int);D=np.zeros_like(R);D[I]=K[I]-R[I];s=np.load(prior/'package/construction/search_inputs.npz');lines=(prior/'package/symmetry.txt').read_text().splitlines();pa=np.stack([np.fromstring(l,sep=' ',dtype=int) for l in lines[2::4]]);groups=[np.unique(pa[:,i]) for i in range(81)];groups=[g for g in groups if g[0] not in set()] # retain one copy per orbit
 groups=list({tuple(g):g for g in groups}.values());groups.sort(key=lambda g:g[0]);R=R.astype(float)/1e6;D=D.astype(float)*q.t/1e6;rng=np.random.default_rng(q.seed)
 base=sgn(rng.normal(size=(550,3))@s['B'].T);G=np.zeros((4,81))
 for k,g in enumerate(groups):G[k,g]=1
 sizes=G.sum(axis=1);m=R.shape[1];cols=np.arange(m)
 def payoff(b):return np.maximum(abs(b@R.T),abs(b@D.T))
 def oracle(J,w,starts):
    b=starts;rr=R[J];dd=D[J];W=w[None,:]
    for step in range(12):
        u=b@rr.T;v=b@dd.T;alt=abs(u)<abs(v);y=(W*np.where(alt,0,np.sign(u)))@rr+(W*np.where(alt,np.sign(v),0))@dd;b=sgn(y)
        if step in (1,4,8):b=np.unique(b,axis=0)
    pp=payoff(b);val=pp[:,J]@w;sel=np.argsort(val)[-30:];return val[sel[-1]],b[sel],pp[sel]
 pool=payoff(base);best=1e10;bestJ=None
 for ii in range(q.iter):
    if ii==0 or ii%10==0:J=np.concatenate([rng.choice(g,count,replace=False) for g,count in zip(groups,q.counts)])
    else:
      J=bestJ.copy()
      for _ in range(1+int(ii%7==0)):
        use=rng.integers(4);g=groups[use];l=np.flatnonzero(np.isin(J,g));J[rng.choice(l)]=rng.choice(np.setdiff1d(g,J))
    E=G[:,J];l=pool[:,J];points=base
    for z in range(18):
      res=linprog(np.r_[np.zeros(len(J)),1],A_ub=np.column_stack((l,-np.ones(len(l)))),b_ub=np.zeros(len(l)),A_eq=np.column_stack((E,np.zeros(4))),b_eq=sizes,bounds=[(0,None)]*len(J)+[(0,None)],method='highs');assert res.success
      weights=res.x[:-1];val,bs,pay=oracle(J,weights,points);l=np.vstack((l,pay[:,J]));points=np.vstack((base,bs))
      if val-res.x[-1]<.08:break
    if val<best:
      best=val;bestJ=J.copy();pool=np.vstack((pool,pay));print('new',ii,'heuristic block upper candidate',round(val*1e6),'radius',round((val*1e6-C)/(q.t-1)),flush=True)
      # Rational weights rounded to millionths then made to sum exactly on each orbit.
      w=np.rint(weights*1000000).astype(int)
      for k,g in enumerate(groups):
        poss=np.flatnonzero(E[k]);pos=poss[np.argmax(w[poss])];w[pos]+=int(sizes[k])*1000000-w[poss].sum()
      saved=dict(multiplier=q.t,indices=J.tolist(),weight_numerators=w.tolist(),denominator=1000000,heuristic_value=val)
      (q.out/'block.json').write_text(json.dumps(saved,indent=1)+'\n')
if __name__=='__main__':main()
