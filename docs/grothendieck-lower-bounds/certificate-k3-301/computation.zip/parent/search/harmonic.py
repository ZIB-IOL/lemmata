"""Find a separating inequality using rotationally averaged odd sign correlations on the two-sphere."""
import argparse,json,sys,math,time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
from facet import maps_for
def collect(K,A,I):
 P,S,_,_=maps_for(K,I);g,n=P.shape;seen=set();orbits=[];angles=[];corr=A@A.T
 for i in range(n):
    for j in range(i+1,n):
      if (i,j) in seen:continue
      t=1 if corr[i,j]>=0 else -1
      signed={(min(int(p[i]),int(p[j])),max(int(p[i]),int(p[j])),int(t*s[i]*s[j])) for p,s in zip(P,S)}
      seen.update((h,l) for h,l,v in signed)
      if len({(h,l) for h,l,v in signed})!=len(signed):continue
      o=np.asarray(sorted(signed));rho=np.mean(o[:,2]*corr[o[:,0],o[:,1]]);dr=np.ptp(o[:,2]*corr[o[:,0],o[:,1]])
      if rho<.0000001 or dr>.001:continue
      orbits.append(o);angles.append(rho)
 return orbits,np.array(angles)
def features(a,orbits):
 ans=np.empty((len(a),len(orbits)))
 for h,o in enumerate(orbits):
    i,j,s=o.T;ans[:,h]=(a[:,i]*a[:,j])@s/len(o)
 return ans
def main():
 p=argparse.ArgumentParser();p.add_argument('center',type=Path);p.add_argument('out',type=Path);p.add_argument('--pool',type=Path);p.add_argument('--degree',type=int,default=1501);p.add_argument('--limit',type=int,default=1000000);p.add_argument('--budget',type=int,default=1400000);p.add_argument('--chain',action='store_true');p.add_argument('--center-scores',type=Path)
 q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True);z=np.load(q.center/'candidate.npz');K=z['M'];A=z['A'];I=np.loadtxt(q.center/'split_rows.txt',dtype=int,ndmin=1)
 C=641951292 if len(K)>100 else 0
 o,rho=collect(K,A,I);v0=2*np.fromfile(q.pool or q.center/'near_lift.bin',dtype='<u4').reshape(-1,6)[:,0].astype(np.int64)
 hit=np.unique(np.fromfile(q.pool or q.center/'near_lift.bin',dtype='<u4').reshape(-1,6),axis=0);a=1.-2*np.unpackbits(np.ascontiguousarray(hit[:,1:]).view(np.uint8),axis=1,bitorder='little')[:,:len(A)];v=2*hit[:,0].astype(np.int64)
 H=features(a,o);Q=float(z['quantum']);u=len(o);r=len(a);print('orbits',u,'strategies',r,'max angle mismatch checked at certificate time',flush=True)
 den=100000.;F=(v-C)/den;rad=q.limit/den;maxnorm=q.budget/den
 P0=np.ones(u);P1=rho.copy();harm=[]
 for l in range(1,q.degree+1):
    if l%2 and l>=3:harm.append(P1.copy())
    P0,P1=P1,((2*l+1)*rho*P1-l*P0)/(l+1)
 harm=np.asarray(harm);tail=np.minimum(1,np.sqrt(2/((q.degree+1)*(1-rho*rho))))
 # Variables are positive and negative parts of t, B=max(F-Ht), Z=harmonic upper,
 # and nonnegative optional chain multipliers on expected sign disagreements.
 # Average h(rho) <= 1-2/k, by a k-edge chain between antipodes.
 k=np.ceil(np.pi/np.arccos(rho)+.000001).astype(int)+1;ch=1-2/k
 hcols=3*u if q.chain else 2*u; cols=hcols+2
 def nearrow(h):return np.c_[-h,h,-h] if q.chain else np.c_[-h,h]
 def harms(mat):return np.c_[mat,-mat,np.zeros_like(mat)] if q.chain else np.c_[mat,-mat]
 def rest(x,b,z):return np.column_stack((x,np.full(len(x),b),np.full(len(x),z)))
 G=np.vstack((harm,.75*rho+.25*harm))
 grid=[rest(harms(G),0,-1)]
 def row(pos,neg,chv,b,zz):return np.r_[pos,neg,chv if q.chain else [],b,zz]
 grid.append(np.vstack([row(tail,tail,np.zeros(u),0,-1),row(.75*rho+.25*tail,-.75*rho+.25*tail,np.zeros(u),0,-1),row(np.ones(u),np.ones(u),np.ones(u),-1,0),row(np.ones(u),np.ones(u),np.ones(u),0,0)]))
 grid=np.vstack(grid);rhs=np.r_[np.zeros(len(G)+2),rad,maxnorm]
 chosen=np.argsort(v)[-200:];cost=row(np.zeros(u),np.zeros(u),ch,1,1);bounds=[(0,None)]*hcols+[(None,None)]*2
 for it in range(60):
    mat=np.vstack((grid,rest(nearrow(H[chosen]),-1,0)));b=np.r_[rhs,-F[chosen]]
    res=linprog(cost,A_ub=csr_matrix(mat),b_ub=b,bounds=bounds,method='highs');assert res.success,res.message
    x=res.x;t=x[:u]-x[u:2*u];lam=x[2*u:3*u] if q.chain else np.zeros(u);far=abs(t).sum()+lam.sum()-rad;vals=F-H@(t+lam);mx=max(vals.max(),far);gap=mx-x[-2]
    U=C+den*(mx+x[-1]+lam@ch);print(it,'effective classical',round(U,3),'ratio',Q/U,'gap',round(gap,7),'active',sum(abs(t)>1e-8),'chain',sum(lam>1e-8),flush=True)
    if gap<1e-7:break
    add=np.argsort(vals)[-50:];chosen=np.unique(np.r_[chosen,add])
 weights=np.rint(den*t).astype(int);chain=np.rint(den*lam).astype(int)
 dat={'degree':q.degree,'near_cutoff':int(C-q.limit),'base_max':int(C),'orbits':[{'pairs':v.tolist(),'weight':int(w),'chain_weight':int(c),'chain_length':int(kk),'rho':float(ro)} for v,w,c,kk,ro in zip(o,weights,chain,k,rho) if w or c]};(q.out/'dual.json').write_text(json.dumps(dat,indent=1)+'\n')
if __name__=='__main__':main()
