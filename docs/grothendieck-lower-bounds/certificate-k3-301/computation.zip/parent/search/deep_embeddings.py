"""Iterated local search for reassignments of an already certified Bell matrix."""
import argparse,json
from pathlib import Path
import numpy as np
from local_game_pricing import residual
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('context',type=Path);p.add_argument('sources',type=Path);p.add_argument('out',type=Path);p.add_argument('--reference',action='store_true');p.add_argument('--trials',type=int,default=900);p.add_argument('--seed',type=int,default=4317);a=p.parse_args()
    G,weight,K,_=residual(a.search,a.context);rng=np.random.default_rng(a.seed);kind='reference' if a.reference else 'base'
    R=K.astype(float) if a.reference else np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt');cap=2*int(np.fromfile(a.context/'band.bin',dtype='<u4').reshape(-1,6)[:,0].max()) if a.reference else 320975646
    seeds=[x for x in json.loads(a.sources.read_text()) if x['kind']==kind];n,m=R.shape
    globalbest=0;pool={};N=len(G)
    def optimize(ia,sa,ib=None,sb=None):
        last=0
        for _ in range(32):
            if ib is None:
                c=R.T@(G[ia]*sa[:,None]);ib=abs(c).argmax(axis=1);sb=np.where(c[np.arange(m),ib]>=0,1,-1)
            f=(R*sb)@G[:,ib].T;ia=abs(f).argmax(axis=1);sa=np.where(f[np.arange(n),ia]>=0,1,-1);val=abs(f).max(axis=1).sum()/cap
            if val<=last+2e-12:break
            last=val;ib=None
        if ib is None:
            c=R.T@(G[ia]*sa[:,None]);ib=abs(c).argmax(axis=1);sb=np.where(c[np.arange(m),ib]>=0,1,-1);val=abs(c).max(axis=1).sum()/cap
        return val,ia,sa,ib,sb
    for it in range(a.trials+len(seeds)):
        if it<len(seeds):dd=seeds[it];ia=np.asarray(dd['rows']);sa=np.asarray(dd['row_signs']);ib=sb=None
        else:
            ranked=sorted(pool,reverse=True);par=pool[ranked[min(len(ranked)-1,int(rng.exponential(20)))]]
            ia,sa,ib,sb=[v.copy() for v in par]
            row=(it%2==0);matrix=(R*sb)@G[:,ib].T if row else R.T@(G[ia]*sa[:,None]);l=matrix.shape[0]
            amount=min(l,max(1,int(rng.uniform(.015,.18)*l)));ix=rng.choice(l,amount,replace=False);D=matrix[ix];k=int(rng.integers(3,16));cand=np.argpartition(-abs(D),k-1,axis=1)[:,:k];choices=cand[np.arange(amount),rng.integers(0,k,amount)]
            if row:
                ia[ix]=choices;sa[ix]=np.where(D[np.arange(amount),choices]>=0,1,-1);ib=sb=None
            else:ib[ix]=choices;sb[ix]=np.where(D[np.arange(amount),choices]>=0,1,-1)
        v,ia,sa,ib,sb=optimize(ia,sa,ib,sb);key=round(float(v),11)
        if len(pool)<110 or key>min(pool):
            pool[key]=(ia,sa,ib,sb)
            if len(pool)>110:del pool[min(pool)]
        if key>globalbest:
            globalbest=key;print('local search',kind,it,key,flush=True)
    results=[]
    for key in sorted(pool,reverse=True):
        ia,sa,ib,sb=pool[key];results.append(dict(rows=ia.tolist(),row_signs=sa.tolist(),columns=ib.tolist(),column_signs=sb.tolist(),price=key))
    a.out.write_text(json.dumps(results,separators=(',',':'))+'\n')
if __name__=='__main__':main()
