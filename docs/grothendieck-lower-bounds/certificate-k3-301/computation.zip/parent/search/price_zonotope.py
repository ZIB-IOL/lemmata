"""Price exact small-row games against every available opposite setting using a zonotope."""
from pathlib import Path
import argparse,itertools,json,math
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from local_game_pricing import residual,price
def fan(k):
    S=np.array([(1,)+s for s in itertools.product((-1,1),repeat=k-1)],int);indices=iter(itertools.combinations(range(len(S)),k-1));result=set()
    while True:
        v=list(itertools.islice(indices,4000))
        if not v:break
        H=S[np.array(v)];u=np.stack([(-1)**i*np.rint(np.linalg.det(np.delete(H,i,axis=2))).astype(int) for i in range(k)],axis=1)
        div=np.gcd.reduce(abs(u),axis=1);u=u[div>0]//div[div>0,None];sign=u[np.arange(len(u)),(u!=0).argmax(axis=1)];u*=np.sign(sign[:,None]);result.update(map(tuple,np.unique(u,axis=0).tolist()))
    U=np.asarray(sorted(result));return S,U,np.abs(U@S.T).astype(float)
def extreme(G,I,S,U,planes):
    T=U@G[I];cols=np.argmax(abs(T),axis=1);v=T[np.arange(len(T)),cols];sol=linprog(np.ones(len(S)),A_ub=-planes,b_ub=-abs(v),bounds=(0,None),method='highs');assert sol.success
    lam=-sol.ineqlin.marginals;use=np.where(lam>1e-7)[0];w=[F(float(lam[t])).limit_denominator(200000) for t in use];scale=math.lcm(*(x.denominator for x in w))
    scale=min(scale,1000000);cols0=np.unique(cols[use]);E=np.zeros((len(I),len(cols0)),dtype=int)
    for h,row in enumerate(use):
        j=np.searchsorted(cols0,cols[row]);E[:,j]+=int(round(float(w[h])*scale))*(1 if v[row]>=0 else -1)*U[row]
    return E,cols0,float(sol.fun)
def reduce(E,I,J):
    rr=np.unique(I);cc=np.unique(J);K=np.zeros((len(rr),len(cc)),int)
    np.add.at(K,(np.searchsorted(rr,I)[:,None],np.searchsorted(cc,J)),E);rows=np.where(np.any(K,axis=1))[0];cols=np.where(np.any(K,axis=0))[0];K=K[np.ix_(rows,cols)]
    if K.size:K//=np.gcd.reduce(abs(K).ravel())
    return K,rr[rows],cc[cols]
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('witness',type=Path);p.add_argument('out',type=Path);p.add_argument('--k',type=int,default=5);p.add_argument('--trials',type=int,default=200);p.add_argument('--seed',type=int,default=77107);o=p.parse_args()
    G,w,K,ops=residual(o.search,o.witness);rng=np.random.default_rng(o.seed);S,U,planes=fan(o.k);rank=[price(G),price(G.T)];pool={};best=0;print('zonotope sign generators',len(S),'facet normal directions',len(U),flush=True)
    for it in range(o.trials):
        h=it%2;R=G.T if h else G;i,j,x,y,s,t=rank[h][rng.integers(0, min(4500,len(rank[h])))][1]
        I=list(dict.fromkeys([i,j]));I+=rng.choice([l for l in range(len(R)) if l not in I],o.k-len(I),replace=False).tolist();I=np.array(I)
        for lp in range(7):
            E,J,upper=extreme(R,I,S,U,planes);val0=0
            for _ in range(14):
                g=E.T@R[I];J=abs(g).argmax(axis=1);E*=np.where(g[np.arange(len(J)),J]>=0,1,-1)
                g=R[:,J]@E.T;II=abs(g).argmax(axis=0);E*=np.where(g[II,np.arange(len(II))]>=0,1,-1)[:,None];v=abs(g).max(axis=0).sum();I=II
                if abs(v-val0)<1e-9:break
                val0=v
            M,ia,ib=reduce(E,I,J)
            if min(M.shape)<2:break
            ss=np.array([(1,)+sg for sg in itertools.product((-1,1),repeat=len(ia)-1)]);cap=int(abs(ss@M).sum(axis=1).max());value=float((M*R[np.ix_(ia,ib)]).sum()/cap)
            if h:M=M.T;ia,ib=ib,ia
            if min(M.shape)>=4:
                entries=[[int(ia[a]),int(ib[b]),int(M[a,b])] for a,b in zip(*np.nonzero(M))];pool[round(value,12)]=dict(entries=entries,classical=cap,price=value)
            if value>best:
                best=value;print('best',it,'price',value,'rows',M.shape[0],'columns',M.shape[1],flush=True)
            if value<upper+4e-7 or len(np.unique(I))<o.k:break
    rr=[pool[k] for k in sorted(pool,reverse=True)];o.out.write_text(json.dumps(rr,separators=(',',':'))+'\n');print('multirow games',len(rr),'top',rr[0]['price'] if rr else None,flush=True)
if __name__=='__main__':main()
