"""Compare genuine sign strategies on whole-orbit candidates at several search amplitudes."""
import argparse,itertools,json,sys
from pathlib import Path
import numpy as np
prior=Path('/workspace/k3_nov26');sys.path.insert(0,str(prior))
from search import quantum
C=320975646
def sgn(x):return np.where(x>=0,1.,-1.)
def main():
 p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--amps',type=int,nargs='+',default=[6000000,10000000,20000000,50000000,100000000]);p.add_argument('--scales',nargs='+',type=float,default=[1]);opt=p.parse_args()
 z=np.load(prior/'package/construction/search_inputs.npz');R,A,B=z['M'],z['A'],z['B'];active=np.load('active_plus.npz');X=active['X'];J=active['indices'];order=np.array(json.loads(Path('/workspace/matrix_improvement/orbit89/preproc_provenance.json').read_text())['ordered_to_original']);J=np.where(J==99,81,order[np.minimum(J,80)])
 rng=np.random.default_rng(638);base=sgn(z['near_a']@R);base=np.unique(np.vstack((base,sgn(rng.normal(size=(1400,3))@B.T))),axis=0)
 records=[];pool=base;Ds={}
 for i,c in [(1,1),(4,-1),(4,1)]:
    for amp in opt.amps:
        f=Path(f'orbits/r{i}_c{c}_a{amp}.npz')
        if f.exists():
            vv=np.load(f);Ds[i,c,amp]=(vv['I'],vv['D'])
 for scale in opt.scales:
  for a1,a4,c4 in itertools.product([0]+opt.amps,[0]+opt.amps,[-1,1]):
    if not a1 and not a4 or (not a4 and c4>0):continue
    if (a1 and (1,1,a1) not in Ds) or (a4 and (4,c4,a4) not in Ds):continue
    D=np.zeros((82,321),dtype=int);L=[]
    for i,c,k in [(1,1,a1),(4,c4,a4)]:
        if k:
            j,d=Ds[i,c,k];D[j]=np.rint(scale*d).astype(int);L.extend(j)
    L=np.array(L);K=np.vstack((2*R,R[L]-D[L]));K[L]=R[L]+D[L];M=K.astype(float)
    q,aa,bb=quantum(M,np.vstack((A,A[L])),B,200)
    both=(np.isin(J[:,0],L))&(np.isin(J[:,1],np.r_[L,81]))
    start=[pool]
    for s,t in itertools.product([1,-1],repeat=2):
        V=X[both]+s*D[J[both,0]]+t*D[J[both,1]];pick=np.argsort(abs(V).sum(axis=1))[-160:];start.append(sgn(V[pick]))
    b=np.concatenate(start);best=C;winning=None
    for step in range(12):
        a=sgn(b@M.T);scores=np.sum(abs(a@M),axis=1)/2
        w=np.argmax(scores);new=int(scores[w])
        if new>=best:best=new;winning=sgn(a[w]@M)
        if step in [0,3,7]:
            idx=np.argsort(scores)[-800:];b=np.unique(sgn(a[idx]@M),axis=0)
        else:b=sgn(a@M)
    ratio=q/(2*best);records.append([ratio,a1,a4,c4,scale,best,q/(2*C)])
    print(f'{ratio:.12f} amp={a1},{a4} character={c4} scale={scale:.4f} attained={best} optimistic={q/(2*C):.12f}',flush=True)
    if winning is not None:pool=np.vstack((base,winning,sgn(a[np.argsort(scores)[-50:]]@M)))
 opt.out.write_text(json.dumps(sorted(records,reverse=True),indent=1)+'\n')
if __name__=='__main__':main()
