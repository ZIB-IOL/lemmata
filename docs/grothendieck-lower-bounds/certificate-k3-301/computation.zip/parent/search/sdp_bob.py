"""Optimize the signed-norm semidefinite certificate on the icosahedral representation blocks."""
import argparse,sys,os
from pathlib import Path
import numpy as np
from column_search import initial_records,signings,model
from facet import maps_for
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import orbit_basis,quantum
C=641951292;UNIT=100.;STEP=.01
def decompose(maps,idx,sg,ids,cache):
    pa,sa,pb,sb=maps;n=len(pa[0]);m=len(pb[0]);rng=np.random.default_rng(77051);mix=rng.normal(size=len(pa));fids=idx.ravel();fs=sg.ravel()
    def spaces(ps,ss):
        d=len(ps[0]);f=np.zeros((d,d))
        for g,(p,s) in enumerate(zip(ps,ss)):f[p,np.arange(d)]+=s*mix[g]
        values,vectors=np.linalg.eigh(f+f.T);parts=np.split(np.arange(d),np.where(np.diff(values)>1e-6)[0]+1)
        return [(values[h].mean(),vectors[:,h]) for h in parts]
    u=spaces(pa,sa);v=spaces(pb,sb);xi=np.zeros(idx.max()+1);xi[ids]=rng.normal(size=len(ids));dm=xi[idx]*sg;selected=[];finger=[]
    for key,P in u:
        s,Q=min(v,key=lambda z:abs(z[0]-key))
        if abs(s-key)>1e-7:continue
        sample=np.linalg.svd(P.T@dm@Q,compute_uv=False)
        if any(len(w)==len(sample) and np.allclose(sample,w,atol=1e-6) for w in finger):continue
        finger.append(sample);selected.append((P,Q))
    aggregate=lambda arr:np.bincount(fids,weights=arr.ravel()*fs,minlength=idx.max()+1)[ids]
    transforms=np.stack([aggregate(P[:,i,None]*Q[:,j]) for P,Q in selected for i in range(P.shape[1]) for j in range(Q.shape[1])])
    assert transforms.shape==(len(ids),len(ids)),(transforms.shape,len(ids))
    inverse=np.linalg.inv(transforms)
    x=np.array([p for a,b in selected for p in (a.T@dm@b).ravel()]);assert np.max(abs(inverse@x-xi[ids]))<1e-7
    return selected,inverse,aggregate
def all_orbits(p):
    completed=set();out=[]
    for j in range(len(p[0])):
        if j in completed:continue
        v=np.unique(p[:,j]);out.append(v);completed.update(v.tolist())
    return out
def main():
    import cvxpy as cp
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--band',type=Path);p.add_argument('--previous',type=Path);p.add_argument('--budget',type=float,default=422000.);p.add_argument('--rounds',type=int,default=30);p.add_argument('--column',type=int,default=1);p.add_argument('--character',type=int,default=1);p.add_argument('--angle',type=float,default=.06);p.add_argument('--rho',type=float,default=1.0);p.add_argument('--safety',type=float,default=400.);p.add_argument('--threshold',type=float,default=C);p.add_argument('--scales',type=float,nargs=2,default=[1.,1.]);p.add_argument('--restarts',type=int,default=2);o=p.parse_args();o.out.mkdir(exist_ok=True,parents=True)
    data=np.load(Path(__file__).resolve().parent/'second_seed.npz');K=data['M'];A=data['A'];B=data['B']
    if o.previous:
        z=np.load(o.previous);A=z['A'];B=z['B']
    R=np.loadtxt(Path(__file__).resolve().parents[1]/'base.txt',int);I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);maps=maps_for(K,I);m0=K.shape[1]
    from bob_orbit import geometry,lift,effective,classical
    J,extra_perm,extra_sign,Bb=geometry(B[:m0],maps[2],maps[3],o.column,o.character,o.angle)
    if len(B)==m0:B=Bb
    maps=(maps[0],maps[1],np.column_stack((maps[2],m0+extra_perm)),np.column_stack((maps[3],extra_sign)))
    idx,sg,bad=orbit_basis(*maps);ids=np.array(sorted(set(range(idx.max()+1))-set(bad)),dtype=int)
    selected,inverse,aggregate=decompose(maps,idx,sg,ids,None);groups=all_orbits(maps[0]);cols=all_orbits(maps[2]);n,m=idx.shape;t0=np.array(o.scales)
    print('independent invariant coefficients',len(ids),'representation block sizes',[(u.shape[1],v.shape[1]) for u,v in selected],flush=True)
    a=signings(o.band) if o.band else initial_records();a=a.astype(float);K0=model(K,R,I,t0);dif=np.array([model(K,R,I,v)-model(K,R,I,[0,0]) for v in np.eye(2)]);K0=np.c_[K0,np.zeros((n,len(J)))];dif=np.concatenate((dif,np.zeros((2,n,len(J)))),axis=2);y0=a@K0;ed=np.array([a@m0 for m0 in dif])
    rm=cp.Variable(len(groups));cm=cp.Variable(len(cols));shift=cp.Variable(2);anchor=cp.Variable();time_step=.0001;t=1+time_step*anchor;objz=[];constraints=[rm>=.01,cm>=.01,t>=0,shift>=(o.rho-t0)*t/STEP,shift<=(1-t0)*t/STEP]
    mass=rm@np.array(list(map(len,groups)))+cm@np.array(list(map(len,cols)))
    constraints.append(mass <= 2*o.rho/UNIT*(o.threshold-(C-432000)*t-o.safety))
    zs=[]
    for P,Q in selected:
        nx,ny=P.shape[1],Q.shape[1];z=cp.Variable((nx,ny));zs.append(z);objz.append(cp.reshape(z,(nx*ny,),order='C'))
        aa=sum(rm[i]*(P[J].T@P[J]) for i,J in enumerate(groups));bb=sum(cm[i]*(Q[J].T@Q[J]) for i,J in enumerate(cols))
        constraints.append(cp.bmat([[aa,z],[z.T,bb]])>>0)
    v=cp.hstack(objz);w=cp.hstack([v,shift,anchor])
    seen=set();rows=[];bounds=[];pairs=[]
    def add(inds,bmat):
        for i,b in zip(inds,bmat):
            c=aggregate(a[i,:,None]*b);key=c.astype(np.int16).tobytes()
            if key in seen:continue
            seen.add(key);pairs.append((a[i].astype(np.int8),b.astype(np.int8)));rows.append(np.r_[c@inverse,STEP/UNIT*(ed[:,i]@b),time_step/UNIT*(y0[i]@b)]);bounds.append((o.threshold-y0[i]@b)/UNIT)
    initial=np.argsort(abs(y0).sum(axis=1))[-min(len(a),550):];add(initial,classical(y0[initial],J,m0)[1])
    best=0
    for outer in range(o.restarts):
        vec=A@effective(B,J,m0).T;grad=np.r_[aggregate(vec)@inverse,STEP/UNIT*(dif*vec).sum(axis=(1,2)),time_step/UNIT*(K0*vec).sum()]
        for j in range(o.rounds):
            prob=cp.Problem(cp.Maximize(grad@w),constraints+[np.stack(rows)@w<=np.array(bounds)])
            try:prob.solve(solver='CLARABEL',max_threads=1,max_iter=160,tol_gap_rel=2e-8,tol_gap_abs=2e-7,tol_feas=2e-8)
            except Exception:prob.solve(solver='SCS',eps=2e-5,max_iters=10000)
            assert w.value is not None,prob.status
            xi=np.zeros(idx.max()+1);xi[ids]=inverse@w.value[:-3]*UNIT;dd=np.rint(xi[idx]*sg*1000).astype(np.int64);tt=int(np.rint((1+time_step*w.value[-1])*1e8));s=t0*(tt/1e8)+STEP*w.value[-3:-1];qs=np.minimum(tt,np.rint(s*1e8).astype(int));s=qs/tt
            actual=np.c_[(tt/1e8)*model(K,R,I,s),np.zeros((n,len(J)))]+dd/1000.;y=a@actual;scores,bbits=classical(y,J,m0);sel=np.argsort(scores)[::-1];den=scores[sel[0]];gap=den-o.threshold;rr=(vec*actual).sum()/den
            aweight=np.empty(n);bweight=np.empty(m)
            for u,h in zip(groups,rm.value):aweight[u]=h*UNIT
            for u,h in zip(cols,cm.value):bweight[u]=h*UNIT
            rough=(sum(aweight)+sum(bweight))/2
            print('solve',outer,j,prob.status,'sign cuts',len(rows),'violation',round(gap,2),'ratio',rr,'norm proposal',round(rough),'scales',s.tolist(),'anchor',tt/1e8,flush=True)
            if rr>best:
                best=rr;Q,aa,bb=quantum(lift(actual[:,:m0],actual[:,m0:],J),A,B,1000);Q/=2
                # Save the actual cut weights and reduced positive-semidefinite dual blocks.
                weights=np.maximum(0,np.asarray(prob.constraints[-1].dual_value));select=weights>1e-12
                archive={'weights':weights[select],'alice':np.stack([a for a,b in pairs])[select],'bob':np.stack([b for a,b in pairs])[select]}
                for bi,((P,Qblock),cone) in enumerate(zip(selected,constraints[-len(selected):])):
                    archive['p'+str(bi)]=P;archive['q'+str(bi)]=Qblock;archive['y'+str(bi)]=cone.dual_value
                np.savez_compressed(o.out/'dual_numpy.npz',**archive)
                np.savez_compressed(o.out/'best.npz',scales=qs,base_numerator=tt,scale_denominator=100000000,delta=dd,delta_denominator=1000,bob_indices=J,bob_perms=extra_perm,bob_signs=extra_sign,A=aa,B=bb,quantum=Q,sample_classical=den,row_diagonal=aweight,column_diagonal=bweight,iteration=j,round=outer)
            if gap<=3:break
            count=len(rows);take=sel[scores[sel]>o.threshold+1][:100];add(take,bbits[take])
            if len(rows)==count:break
        z=np.load(o.out/'best.npz');A=z['A'];B=z['B']
if __name__=='__main__':main()
