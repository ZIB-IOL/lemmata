"""Run the focused supplemental proof for a fixed rational result and check every returned score."""
import argparse,json,struct,sys
from fractions import Fraction
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path('package').resolve()));from supplement import parameters
import subprocess
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('result',type=Path);p.add_argument('out',type=Path);p.add_argument('--threads',type=int,default=1);q=p.parse_args();q.out.mkdir(parents=True,exist_ok=True)
 w=json.loads((q.result/'result.json').read_text());M=[[int(s) for s in line.split()] for line in (q.result/'final_matrix.txt').read_text().splitlines()]
 # Use the sharpest integer cutoff allowed by the proof.
 H=Fraction(w['classical'],2*w['denominator']);kap=Fraction(w['kappa_numerator'],w['kappa_denominator']);cut=H-(320975646-H)/kap if H<320975646 else H
 w['shallow_cutoff']=cut.numerator//cut.denominator;(q.result/'result.json').write_text(json.dumps(w,indent=1)+'\n');threshold,surrogate,gate=parameters(w,M,320975646)
 path=q.out/'surrogate.txt';path.write_text(''.join(' '.join(map(str,row))+'\n' for row in surrogate));out=q.out/'supplement.bin'
 subprocess.run([str(Path('shallow_screen').resolve()),'/workspace/k3_nov26/package/base.txt',str(q.model/'split_rows.txt'),'near6414880.bin',str(threshold),str(q.threads),str(out),str(path),str(gate)],check=True)
 rec=np.unique(np.fromfile(out,dtype='<u4').reshape(-1,6),axis=0);rec.tofile(out)
 signs=1-2*np.unpackbits(np.ascontiguousarray(rec[:,1:]).view(np.uint8),axis=1,bitorder='little')[:,:len(M)].astype(np.int64)
 vals=abs(signs.astype(object)@np.asarray(M,dtype=object)).sum(axis=1);top=int(vals.max(initial=0))
 print('supplementary signings',len(rec),'excess over proposed maximum',top-w['classical'],'threshold',threshold,flush=True)
 if top>w['classical']:sys.exit(3)
if __name__=='__main__':main()
