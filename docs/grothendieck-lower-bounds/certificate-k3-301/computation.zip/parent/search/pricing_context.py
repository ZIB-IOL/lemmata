from pathlib import Path
import json,shutil
import numpy as np
def create(model,band,out):
    z=np.load(model/'best.npz');out.mkdir(parents=True,exist_ok=True);d=10**14
    w={'vector_denominator':d,'alice_numerators':np.rint(z['A']*d).astype(np.int64).tolist(),'bob_numerators':np.rint(z['B']*d).astype(np.int64).tolist()}
    (out/'witness.json').write_text(json.dumps(w,separators=(',',':'))+'\n')
    for name,source in [('endpoint.txt',Path(Path(__file__).resolve().parents[1]/'second/endpoint.txt')),('band.bin',band)]:
        shutil.copyfile(source,out/name)
if __name__=='__main__':
    import sys
    create(*[Path(s) for s in sys.argv[1:]])
