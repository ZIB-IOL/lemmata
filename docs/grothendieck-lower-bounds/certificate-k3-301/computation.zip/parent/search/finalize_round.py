"""Package the nested bounds and the files required for exact replay."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import json,shutil,sys,hashlib
root=Path('package')
sys.path.insert(0,str(root.resolve()))
from cover import matrix
from all_parameters import bound

def read(path): return json.loads(path.read_text())
def write(path,value): path.write_text(json.dumps(value,indent=1)+'\n')
def dec(x,n=34):
    with localcontext() as ctx:
        ctx.prec=n
        return str(Decimal(x.numerator)/Decimal(x.denominator))
def strict(x):
    n=x.numerator*10**14//x.denominator
    return f'{n//10**14}.{n%10**14:014d}'
def manifest():
    for path in list(root.rglob('__pycache__')):shutil.rmtree(path)
    files=sorted(f for f in root.rglob('*') if f.is_file() and f.name!='SHA256SUMS.json')
    write(root/'SHA256SUMS.json',{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files})
def prepare():
    if not (root/'two_scale_witness.json').exists():
        for src,dest in [('witness.json','two_scale_witness.json'),('final_matrix.txt','two_scale_matrix.txt')]:
            shutil.copyfile(root/src,root/dest)
    w=read(Path('physical_final_exact/result.json'))
    phys=read(Path('physical_final_exact/physical_dual.json'))
    L=F(w['quantum_numerator'],w['vector_denominator']**2*w['classical'])
    V=F(phys['numerator'],phys['denominator']);assert V==L
    U=bound(root,w,matrix(root/'base.txt'),matrix(root/'lifted_matrix.txt'),list(map(int,(root/'split_rows.txt').read_text().split())),matrix(root/'symmetry.txt'),V,320975646)
    w.update(strict_lower_bound=strict(L),individual_upper_numerator=U.numerator,individual_upper_denominator=U.denominator)
    write(root/'witness.json',w)
    for src,dst in [('physical_final_exact/final_matrix.txt','final_matrix.txt'),('physical_final_exact/physical_dual.json','physical_dual.json'),('physical_final_audit/supplement.bin','supplement.bin')]:
        shutil.copyfile(src,root/dst)
    print('Seven-parameter exact ratio',dec(L,46),'independent gap',dec(U-L,12),flush=True)
def extension(out):
    for src,dst in [(out/'witness.json','extra_witness.json'),(out/'matrix.txt','extra_matrix.txt'),(out/'supplement.bin','extra_supplement.bin'),(Path('high_shape/direction.txt'),'extra_direction.txt'),(Path('residual/sdp.json'),'residual_norm.json')]:
        shutil.copyfile(src,root/dst)
def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--extend',type=Path);p.add_argument('--manifest',action='store_true');a=p.parse_args()
    prepare()
    if a.extend:extension(a.extend)
    if a.manifest:manifest()
if __name__=='__main__':main()
