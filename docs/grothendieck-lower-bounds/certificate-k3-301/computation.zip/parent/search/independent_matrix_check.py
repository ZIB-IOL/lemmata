"""Audit the both-player bound with direct big-integer matrix products."""
import json
from pathlib import Path
from fractions import Fraction
import numpy as np


def read_json(path):
    return json.loads(path.read_text())


def main():
    directory = Path(__file__).resolve().parents[1] / "second"
    witness = read_json(directory / "witness.json")
    cert = read_json(directory / "matrix_upper.json")
    matrix = np.array([list(map(int, row.split())) for row in
                       (directory / "matrix.txt").read_text().splitlines()], dtype=object)
    X = np.asarray(witness["alice_numerators"], dtype=object)
    Y = np.asarray(witness["bob_numerators"], dtype=object)
    scale = witness["vector_denominator"]
    classical = witness["attained"]
    assert max((X*X).sum(axis=1)) <= scale**2 and max((Y*Y).sum(axis=1)) <= scale**2
    vector_score = int((matrix*(X@Y.T)).sum())
    assert vector_score == witness["quantum_numerator"]
    ratio = Fraction(vector_score, scale**2*classical)
    weights = np.asarray(cert["reciprocals"], dtype=object)
    diagonal = np.asarray(cert["diagonal"], dtype=object)
    assert min(weights) > 0 and min(diagonal) > 0
    factor = np.zeros((len(X), len(X)), dtype=object)
    for i, row in enumerate(cert["lower_triangular"]):
        factor[i,:i+1] = row
    residual = np.diag(diagonal) - ((matrix*weights)@matrix.T + factor@factor.T)
    error = int(abs(residual).sum())
    assert error == cert["error"]
    upper_squared = ((int(diagonal.sum())+error)*sum(Fraction(1,w) for w in weights)
                     / classical**2)
    upper = Fraction(cert["vector_upper_numerator"], cert["precision"]*classical)
    assert ratio**2 <= upper_squared < upper**2
    assert upper < ratio + Fraction(731,10**37)
    print("Direct integer matrix products verify the vector score and the upper in every dimension.")
    print("Exact comparison gives an all-dimension gap strictly below 7.31e-35.")


if __name__ == "__main__":
    main()
