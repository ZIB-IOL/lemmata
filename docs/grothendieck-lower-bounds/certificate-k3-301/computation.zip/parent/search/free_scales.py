"""Independently tune all 60 pair displacements, expanding every retained sign pattern by symmetry."""
import argparse,sys,time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from facet import maps_for
from rectangle import fields
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'));from search import quantum
C=320975646
def images(a,maps):
    ps,ss,_,_=maps;xs=[]
    for p,s in zip(ps,ss):
        out=np.empty_like(a);out[:,p]=a*s;xs.append(out*out[:,:1])
    return np.unique(np.vstack(xs),axis=0)
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('out',type=Path);p.add_argument('--starts',type=int,default=14);p.add_argument('--grid',type=int,default=1000000);p.add_argument('--seed',type=int,default=46);p.add_argument('--two',type=Path);q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 data=np.load(q.model/'candidate.npz');K=data['M'];R=np.loadtxt(prior.parent/'base.txt',dtype=int);n=len(R);I=np.loadtxt(q.model/'split_rows.txt',dtype=int);k=len(I);D=K[I]-R[I];rec=np.unique(np.fromfile(q.hits,dtype='<u4').reshape(-1,6),axis=0);rec=rec[rec[:,0]>C]
 a=fields(R,I,D,rec)[0].astype(np.int8);a=images(a,maps_for(K,I));a0=a[:,:n].copy();W=(a0[:,I]-a[:,n:])*.5;a0[:,I]=np.rint((a0[:,I]+a[:,n:])*.5).astype(np.int8);X=a0.astype(float)@R;dd=D.astype(float)
 rng=np.random.default_rng(q.seed);start=time.monotonic();print('exact projected constraints available for',len(a),'symmetry images',flush=True);constraints={};best=0.
 def evaluate(s,cut=False):
    yy=X+(W*s)@dd;vv=abs(yy).sum(axis=1);C1=max(C,vv.max(initial=0))
    if cut:
       for j in np.argsort(vv)[-28:][::-1]:
          if vv[j]<C1-8000:break
          b=np.where(yy[j]>=0,1.,-1.);g=(dd@b*W[j]).astype(np.int64);base=int(X[j]@b)
          constraints[g.tobytes()]=(g,base)
    return C1
 def form(s):
    d=s[:,None]*dd;M=np.vstack((2.*R,R[I]-d));M[I]=R[I]+d;return M
 def polish(s,A,B):
    nonlocal best
    for it in range(16):
       M=form(s);Q,A,B=quantum(M,A,B,350);val=evaluate(s,True);ratio=Q/(2*val)
       if ratio>best+5e-12:
          ps=np.rint(s*q.grid).astype(int);si=ps/q.grid;val=evaluate(si);Q,aa,bb=quantum(form(si),A,B,700);current=Q/(2*val)
          if current>best+2e-13:
            best=current;d=ps[:,None]*D;Mfit=np.vstack((2*q.grid*R,q.grid*R[I]-d));Mfit[I]=q.grid*R[I]+d
            np.savez_compressed(q.out/'best.npz',M=Mfit,A=aa,B=bb,quantum=Q*q.grid,scale_numerators=ps,scale_denominator=q.grid,observed_classical=val)
            print('best',best,'scale range',s.min(),s.max(),'classical',val,'sec',round(time.monotonic()-start,1),flush=True)
       grad=((dd@B)*((A[I]-A[n:])/2)).sum(axis=1);off=Q/2-grad@s;old=s.copy();rr=ratio
       for step in range(90):
          arr=np.zeros((1+len(constraints),k+1));arr[:,-1]=-1;rhs=[-C/1e6]
          for idx,(g,base) in enumerate(constraints.values(),1):arr[idx,:k]=g/1e6;rhs.append(-base/1e6)
          res=linprog(np.r_[-grad/1e6,rr],A_ub=arr,b_ub=rhs,bounds=[(0,1)]*k+[(0,None)],method='highs');assert res.success
          s=res.x[:k];newval=evaluate(s,True);now=(off+grad@s)/newval
          if newval-res.x[-1]*1e6<.1 and abs(rr-now)<1e-10:break
          rr=now
       if abs(old-s).max()<2e-6:break
    return s
 seeds=[np.full(k,.94)]
 if q.two:
    z=np.load(q.two);s=z['scale_numerators']/int(z['scale_denominator']);seeds=[np.repeat(s,k//2)]
 for i in range(q.starts):
    if i==0:s=seeds[0]
    elif i%3==1:s=np.clip(seeds[-1]+rng.normal(0,.13,k),0,1)
    elif i%3==2:s=np.where(rng.uniform(size=k)<.5,1.,rng.uniform(.55,.88,k))
    else:s=rng.uniform(.78,1,k)
    z=polish(s,data['A'],data['B']);seeds.append(z);print('start finished',i,'best',best,'constraints',len(constraints),flush=True)
if __name__=='__main__':main()
