from pathlib import Path
import json,sys,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));from dictionary import item
def prep(dictionary,base,ops,idx,sg,ids,reference=None,cap=None):
    n,m=idx.shape;maps=[tuple(v.tolist() for v in g) for g in zip(*ops)];row=[];caps=[]
    _,represent=np.unique(idx,return_index=True);represent=represent[ids]
    for atom in dictionary:
        if atom['kind'] in ('base','reference'):
            R,den=(base,320975646) if atom['kind']=='base' else (reference,cap)
            ia=np.asarray(atom['rows']);ib=np.asarray(atom['columns']);sa=np.asarray(atom['row_signs']);sb=np.asarray(atom['column_signs']);raw=np.zeros((n,m),dtype=np.int64);np.add.at(raw,(ia[:,None],ib[None,:]),R*sa[:,None]*sb)
            accum=np.zeros_like(raw)
            for pa,rs,pb,cs in zip(*ops):accum[np.ix_(pa,pb)]+=raw*rs[:,None]*cs
            ng=len(ops[0]);x=np.sign(accum)*((abs(accum)+ng//2)//ng);c=den+(int(abs(accum-ng*x).sum())+ng-1)//ng
        else:
            M,c=item(base.tolist(),maps,atom,n,m,reference.tolist() if reference is not None else None,cap);x=np.asarray(M)
        v=(x*sg).ravel()[represent];rep=np.zeros(idx.max()+1,dtype=int);rep[ids]=v;assert np.array_equal(rep[idx]*sg,x);row.append(v);caps.append(c)
    return np.array(row),np.array(caps)
if __name__=='__main__':
    base=json.loads(Path('base_prices.json').read_text());small=json.loads(Path('small_pricing.json').read_text())
    d=[{**{k:v for k,v in x.items() if k!='price'},'kind':'base'} for x in base[:10]]+[{**{k:v for k,v in x.items() if k!='price'},'kind':'small'} for x in small[:12]]
    Path('extra_dictionary.json').write_text(json.dumps(d,separators=(',',':'))+'\n')
