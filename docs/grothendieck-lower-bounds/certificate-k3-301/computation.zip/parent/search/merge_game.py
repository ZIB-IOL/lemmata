"""Optimize a mixture of symmetry orbits of single signed setting identifications."""
import argparse,json,math,sys,time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from facet import maps_for
C=641951292.
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('out',type=Path);p.add_argument('--pool',type=Path);p.add_argument('--limit',type=int,default=1000000);p.add_argument('--corr',type=float,default=.865);p.add_argument('--steps',type=int,default=12);p.add_argument('--anchor',type=float,default=.05);args=p.parse_args();args.out.mkdir(exist_ok=True,parents=True);z=np.load(args.model/'candidate.npz');K=z['M'];A=z['A'];B=z['B'];I=np.loadtxt(args.model/'split_rows.txt',dtype=int,ndmin=1);P,S,pb,sb=maps_for(K,I);n,m=K.shape;g=len(P)
 hit=np.unique(np.fromfile(args.pool or args.model/'near_lift.bin',dtype='<u4').reshape(-1,6),axis=0);a=(1.-2*np.unpackbits(np.ascontiguousarray(hit[:,1:]).view(np.uint8),axis=1,bitorder='little')[:,:n]);a=np.ascontiguousarray(a);v=2*hit[:,0].astype(np.int64);assert v.max()==C
 rows=[];covered=set();corr=A@A.T;U=K.T@A
 for i in range(n):
    for j in range(n):
        if i==j or abs(corr[i,j])<args.corr or (i,j) in covered:continue
        sj=1 if corr[i,j]>0 else -1
        oo=sorted({(int(P[k,i]),int(P[k,j]),int(sj*S[k,i]*S[k,j])) for k in range(g)})
        covered.update((h,l) for h,l,t in oo);q=np.linalg.norm(U+K[i,:,None]*(sj*A[j]-A[i]),axis=1).sum();rows.append((oo,q))
 scores=np.zeros((len(a),len(rows)),dtype=np.float64);kf=K.astype(float);start=time.monotonic();Q0=np.linalg.norm(U,axis=1).sum()
 for st in range(0,len(a),600):
    sub=a[st:st+600];y=sub@kf;old=abs(y).sum(axis=1);assert np.array_equal(old,v[st:st+600]);loss=np.empty((len(sub),n))
    for i in range(n):loss[:,i]=old-abs(y-2*sub[:,i,None]*kf[i]).sum(axis=1)
    for h,(orb,q) in enumerate(rows):
        ii,jj,ss=np.array(orb).T
        scores[st:st+len(sub),h]=((sub[:,ii]*sub[:,jj]!=ss)*loss[:,ii]).sum(axis=1)/len(orb)
 qloss=np.array([Q0-q for _,q in rows]);print('strategies',len(a),'merge orbit count',len(rows),'precomputed in',round(time.monotonic()-start,1),flush=True)
 # Maximize Q-r*C for a mixture of the anchor and all selected orbits. Excluded
 # signs lose at least anchor_weight*limit. All other terms are individually <= C.
 ratio=Q0/C;chosen=np.argsort(v)[-180:]
 for it in range(args.steps):
    for _ in range(35):
      # d = C - upper on mixed classical value, w masses on replacement orbits.
      A1=np.column_stack((-scores[chosen]/1e5,np.ones(len(chosen))));b1=(C-v[chosen])/1e5
      ineq=np.vstack((A1,np.r_[np.ones(len(rows))*args.limit/1e5,1],np.r_[np.ones(len(rows)),0]));rhs=np.r_[b1,args.limit/1e5,1-args.anchor]
      obj=np.r_[qloss/1e5,-ratio];res=linprog(obj,A_ub=ineq,b_ub=rhs,bounds=[(0,None)]*len(rows)+[(None,None)],method='highs');assert res.success
      w=res.x[:-1];pred=C-res.x[-1]*1e5;values=v-scores@w;actual=max(values.max(),C-(1-w.sum())*args.limit);gap=actual-pred
      if gap<.01:break
      add=np.argsort(values)[-40:];chosen=np.unique(np.r_[chosen,add])
    ratio=(Q0-w@qloss)/actual;print('round',it,'ratio',ratio,'class bound',actual,'anchor',1-w.sum(),'nonzero',sum(w>1e-9),'gap',gap,flush=True)
    if it>=1 and abs(ratio-previous)<1e-12:break
    previous=ratio
 result={'anchor_mass':1-w.sum(),'orbits':[{'moves':o,'mass':float(weight)} for (o,q),weight in zip(rows,w) if weight>1e-10],'predicted_ratio':ratio,'limit':args.limit}
 (args.out/'mixture.json').write_text(json.dumps(result,indent=1)+'\n')
if __name__=='__main__':main()
