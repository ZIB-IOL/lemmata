"""Add violated four-entry games and reoptimize using the existing classical cuts."""
import argparse,json,sys,os,subprocess
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from local_game_pricing import residual,price
from game_atoms import atom_key
from facet import orbit_basis
def run(cmd,log):
    with open(log,'w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('--start',default='games_trial');p.add_argument('--current',type=Path,default=Path('games1.json'));p.add_argument('--base',type=Path,default=Path('second_endpoint/guidance.bin'));p.add_argument('--count',type=int,default=7);p.add_argument('--label',default='aug');p.add_argument('--threshold',type=float,default=6e-6);p.add_argument('--batch',type=int,default=115);p.add_argument('--moves',default='transport_moves.json');opt=p.parse_args()
    prev=Path(opt.start);games=json.loads(opt.current.read_text());py=sys.executable;cp='/workspace/k3_sdp_env/bin/python';prior=None
    for it in range(opt.count):
        prod=Path(str(prev)+'_product');run([py,'-u','make_band_product.py',str(prev/'best.npz'),str(opt.base),str(prod)],str(prod)+'.log')
        G,total,K,ops=residual(prev,prod);gr,sg,bd=orbit_basis(*ops);forbidden=set(bd);seen={atom_key(g,gr,sg,forbidden) for g in games}
        ranked=price(G);ref=abs(K.T@G).max(axis=1).sum()/641519292;z=json.loads((prod/'witness.json').read_text());lo=float(F(z['quantum_numerator']*z['classical_upper_denominator'],10**30*z['classical_upper_numerator']))
        high=ranked[0][0];zz=max(ref,lo-total);gap=max(ref,high)+total-lo
        print('priced',prev,'ratio',lo,'largest CHSH',high,'comparison',ref,'excess',high-zz,'total headroom on pricing',gap,'dictionary',len(games),flush=True)
        if high<=zz+opt.threshold and it>0:break
        added=0
        for v,g in ranked:
            if v<=zz+opt.threshold/2:break
            key=atom_key(g,gr,sg,forbidden)
            if key and key not in seen:
                games.append(g);seen.add(key);added+=1
                if added>=opt.batch:break
        if not added:break
        nxt=Path(f'{opt.label}_{it+1}');gp=Path(str(nxt)+'_games.json');gp.write_text(json.dumps(games,separators=(',',':'))+'\n')
        run([cp,'-u','sdp_games.py',str(nxt),'--games',str(gp),'--moves',opt.moves,'--warm',str(prev/'plane_pool.npz'),'--band',str(opt.base),'--previous',str(prev/'best.npz'),'--rounds','14','--restarts','2'],str(nxt)+'.log')
        prev=nxt
    print('latest',prev,flush=True)
if __name__=='__main__':main()
