from pathlib import Path
import numpy as np
p=Path('partial4200.bin');v=np.memmap(p,dtype='<u4',offset=36+60*8).reshape(-1,6);C=320975646
rows=[]
for st in range(0,len(v),500000):
 z=v[st:st+500000];keep=z[:,5]>C-1400000;rows.append(np.array(z[keep]))
rec=np.concatenate(rows);ids=np.arange(21,81)
for j,i in enumerate(ids):
 er=(rec[:,3+j//32]>>np.uint32(j%32))&np.uint32(1);rec[:,i//32]&=~(er<<np.uint32(i%32))
rec=np.unique(rec,axis=0);rec.tofile('small_partials.bin')
print('partial states',len(rec),'depths',np.bincount(np.bitwise_count(rec[:,3:5]).sum(axis=1).astype(int)),flush=True)
