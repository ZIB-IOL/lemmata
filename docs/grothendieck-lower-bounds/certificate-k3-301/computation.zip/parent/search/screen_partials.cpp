// Counterexample search on a selected set of original partial strategies. No completeness claim.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using Row=std::vector<int>;using Mat=std::vector<Row>;
Mat matrix(std::string p){std::ifstream in(p);std::string line;Mat t;while(std::getline(in,line)){std::istringstream s(line);Row row;int v;while(s>>v)row.push_back(v);if(row.size())t.push_back(row);}return t;}
int main(int argc,char**argv){
 Mat R=matrix(argv[1]);int n=R.size(),m=R[0].size();std::ifstream in(argv[2],std::ios::binary);
 std::vector<Mat> D;std::vector<Row> I,inv;std::vector<std::ofstream> out;std::vector<std::string> name;
 for(int u=3;u<argc;u++){std::string p=argv[u];name.push_back(p);auto K=matrix(p+"/lifted_matrix.txt");std::ifstream fi(p+"/split_rows.txt");int i;Row ix,iv(n,-1);Mat d;while(fi>>i){iv[i]=ix.size();ix.push_back(i);Row z(m);for(int j=0;j<m;j++)z[j]=K[i][j]-R[i][j];d.push_back(z);}
 D.push_back(d);I.push_back(ix);inv.push_back(iv);out.emplace_back(p+"/screen.bin",std::ios::binary);}
 Row x(m),a(n),S(60),orient(m),err(m),winner(D.size());std::vector<std::uint64_t> hits(D.size());std::array<unsigned,6> rec;int C=320975646;std::uint64_t total=0;
 Mat work(61,Row(m));Row ts(60);
 while(in.read(reinterpret_cast<char*>(rec.data()),24)){
  ++total;int k=0;std::fill(x.begin(),x.end(),0);
  for(int i=0;i<n;i++){a[i]=((rec[i/32]>>(i%32))&1u)?-1:1;if(i>=21&&((rec[3+(i-21)/32]>>((i-21)%32))&1u)){S[k++]=i;continue;}for(int j=0;j<m;j++)x[j]+=a[i]*R[i][j];}
  int base=0;for(int j=0;j<m;j++){orient[j]=x[j]>=0?1:-1;base+=std::abs(x[j]);}if(base!=int(rec[5]))return 3;
  for(int u=0;u<int(D.size());u++){
   std::fill(err.begin(),err.end(),0);int gain=0;
   for(int z=0;z<k;z++){const Row& d=D[u][inv[u][S[z]]];int dot=0;
    #pragma omp simd reduction(+:dot)
    for(int j=0;j<m;j++){dot+=orient[j]*d[j];err[j]+=std::abs(d[j]);}gain+=std::abs(dot);}
   int flip=0;for(int j=0;j<m;j++)flip+=std::max(0,err[j]-std::abs(x[j]));
   if(base+gain+2*flip<=C)continue;
   work[0]=x;auto visit=[&](auto&& self,int l,int score)->void{
    if(l==k){
     if(score>C){std::array<std::uint32_t,6> hit{};hit[0]=score;Row signs=a;for(int i:I[u])signs.push_back(a[i]);for(int z=0;z<k;z++){int i=S[z];signs[i]=ts[z];signs[n+inv[u][i]]=-ts[z];}
      for(int i=0;i<int(signs.size());i++)if(signs[i]<0)hit[1+i/32]|=1u<<(i%32);
      out[u].write(reinterpret_cast<char*>(hit.data()),24);hits[u]++;winner[u]=std::max(winner[u],score);}
     return;
    }
    auto& nx=work[l+1];const auto& old=work[l];const auto& d=D[u][inv[u][S[l]]];
    for(int s:{1,-1}){ts[l]=s;int val=0;
      #pragma omp simd reduction(+:val)
      for(int j=0;j<m;j++){nx[j]=old[j]+s*d[j];val+=std::abs(nx[j]);}self(self,l+1,val);}
   };visit(visit,0,base);
  }
 }
 for(int u=0;u<int(D.size());u++)std::cout<<name[u]<<" hits "<<hits[u]<<" attained "<<std::max(C,winner[u])<<" partials "<<total<<"\n";
}
