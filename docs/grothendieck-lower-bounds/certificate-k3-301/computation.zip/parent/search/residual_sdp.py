"""Diagonal semidefinite upper for the signed residual norm, with a small integer certificate."""
import argparse,json,math
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('out',type=Path);a=p.parse_args();H=np.loadtxt(a.source,dtype=np.int64);n,m=H.shape;sym=Path('/workspace/k3_nov26/package/symmetry.txt').read_text().splitlines()
 pb=np.stack([np.fromstring(x,sep=' ',dtype=int) for x in sym[4::4]]);co=list({tuple(np.unique(pb[:,j])):np.unique(pb[:,j]) for j in range(m)}.values());ro=[np.arange(n//2),np.arange(n//2,n)]
 # Independent signs do not affect the bound, so row norms and column norms may be
 # reweighted even when the displacements transform with a twisted sign.
 rid=np.zeros(n,dtype=int);cid=np.zeros(m,dtype=int)
 for i,g in enumerate(ro):rid[g]=i
 for i,g in enumerate(co):cid[g]=i
 def get(x):
    r=np.exp(x[:len(ro)])[rid];w=np.exp(x[len(ro):])[cid];r/=r.sum();w/=w.sum();return r,w
 def fun(x):
    r,w=get(x);Y=H/np.sqrt(r[:,None]*w);G=Y@Y.T;v,Q=np.linalg.eigh(G);v=np.maximum(v,1);u=np.log(v);alpha=65.;vmax=max(u);t=np.exp(alpha*(u-vmax));t/=t.sum()
    a2=(Q*Q)@t;b2=(((Y.T@Q)**2)/v)@t
    dr=np.bincount(rid,weights=r-a2);dw=np.bincount(cid,weights=w-b2)
    return vmax+np.log(np.exp(alpha*(u-vmax)).sum())/alpha,np.r_[dr,dw]
 x=np.zeros(len(ro)+len(co));res=minimize(fun,x,jac=True,method='L-BFGS-B',bounds=[(-4,4)]*len(x),options={'maxiter':300,'ftol':1e-15,'gtol':1e-9});r,w=get(res.x)
 A=np.maximum(1,np.rint(r*10000000)).astype(np.int64);v=np.maximum(1,np.rint(100/w)).astype(np.int64);G=(H.astype(float)*v)@H.astype(float).T;top=np.linalg.eigvalsh(G/np.sqrt(A[:,None]*A[None,:]))[-1];L=math.ceil(top*1.00003)+1
 upper2=F(int(L)*int(A.sum()))*sum(F(1,int(vv)) for vv in v);ub=math.isqrt(upper2.numerator//upper2.denominator)+1
 a.out.write_text(json.dumps(dict(row_weights=A.tolist(),column_reciprocals=v.tolist(),multiplier=L,norm_upper=ub),indent=1)+'\n');print('rigorous proposal',ub,'weighted lambda',L,'iteration',res.nit,flush=True)
if __name__=='__main__':main()
