"""Look for four-entry Bell matrices that improve the current complementary bound."""
import numpy as np,json,sys
from pathlib import Path
from facet import maps_for
def residual(search,wit):
    z=np.load(search/'dual_numpy.npz');w=json.loads((wit/'witness.json').read_text());K=np.loadtxt(wit/'endpoint.txt',int);I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);pa,sa,pb,sb=maps_for(K,I)
    X=np.array(w['alice_numerators'])/w['vector_denominator'];Y=np.array(w['bob_numerators'])/w['vector_denominator'];G=X@Y.T-z['alice'].T.astype(float)@(z['weights'][:,None]*z['bob']);avg=np.zeros_like(G)
    for a,s,b,u in zip(pa,sa,pb,sb):avg[np.ix_(a,b)]+=G*s[:,None]*u
    return avg/len(pa),sum(z['weights']),K,(pa,sa,pb,sb)
def price(G):
    n,m=G.shape;choices=[]
    for i in range(n):
        P=G[i]+G[i:];M=G[i]-G[i:];hp=np.argmax(abs(P),axis=1);hm=np.argmax(abs(M),axis=1)
        for l,j in enumerate(range(i,n)):
            x=int(hp[l]);y=int(hm[l]);s=1 if P[l,x]>=0 else -1;t=1 if M[l,y]>=0 else -1
            choices.append(((abs(P[l,x])+abs(M[l,y]))/2,[i,j,x,y,s,t]))
    return sorted(choices,reverse=True)
if __name__=='__main__':
    G,w,K,ops=residual(Path(sys.argv[1]),Path(sys.argv[2]));v=price(G);print('residual peak',abs(G).max(),'CHSH max',v[0],'scalar',np.sum(K*G)/641519292,'transport',abs(K.T@G).max(axis=1).sum()/641519292,'weight sum',w)
