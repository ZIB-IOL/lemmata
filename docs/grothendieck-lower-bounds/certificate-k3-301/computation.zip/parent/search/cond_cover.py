"""Average exact conditional block maxima for each protected sign prefix."""
import argparse,json,subprocess
from pathlib import Path
import numpy as np
root=Path('/workspace/k3_nov26/package')
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('cover',type=Path);p.add_argument('out',type=Path);p.add_argument('--threads',type=int,default=1);args=p.parse_args();args.out.mkdir(exist_ok=True,parents=True)
 R=np.loadtxt(root/'base.txt',dtype=int);I=np.loadtxt(args.model/'split_rows.txt',dtype=int,ndmin=1);K=np.loadtxt(args.model/'lifted_matrix.txt',dtype=int);D=np.zeros_like(R);D[I]=K[I]-R[I];s=json.loads(args.cover.read_text());J=np.array(s['indices']);w=np.array(s['weight_numerators']);den=s['denominator'];t=s['multiplier'];f=4
 J,w=J[w>0],w[w>0];raw=np.column_stack((R[J],D[J]*t))*w[:,None];rr=(raw+f*den//2)//(f*den)
 m=R.shape[1];err=np.maximum(abs(raw[:,:m]-f*den*rr[:,:m]).sum(axis=1),abs(raw[:,m:]-f*den*rr[:,m:]).sum(axis=1)).sum()
 fixed=np.where(J<21)[0];vary=np.where(J>=21)[0];strength=np.maximum(abs(rr[:,:m]).sum(axis=1),abs(rr[:,m:]).sum(axis=1));order=np.r_[fixed,vary[np.argsort(strength[vary])[::-1]]];P0=J[fixed];path=args.out/'block.txt';np.savetxt(path,rr[order],fmt='%d')
 vals=np.array(subprocess.check_output([str(Path('conditional_block').resolve()),str(path),str(len(fixed)),str(args.threads)],text=True).split(),dtype=np.int64)
 lines=(root/'symmetry.txt').read_text().splitlines();reps=np.fromstring(lines[1],dtype=np.int64,sep=' ');signs=np.column_stack((np.ones(len(reps),dtype=int),1-2*((reps[:,None]>>np.arange(20))&1)))
 total=np.zeros(len(reps),dtype=np.int64);cover=np.zeros(len(R),dtype=np.int64)
 for j in range(2,len(lines),4):
    pa,sa=[np.fromstring(l,sep=' ',dtype=int) for l in lines[j:j+2]];np.add.at(cover,pa[J],w)
    u=signs[:,pa[P0]]*sa[P0];ids=((u[:,1:]*u[:,:1]<0).astype(np.int64)@(1<<np.arange(len(P0)-1)));total+=vals[ids]
 g=(len(lines)-2)//4;assert np.all(cover==den*g);ub=(total*f*den+g*err+den*g-1)//(den*g);rad=np.maximum(0,(ub-320975646+t-2)//(t-1))
 np.savetxt(args.out/'caps.txt',np.column_stack((reps,rad)),fmt='%d');print('multiplier',t,'radii',np.percentile(rad,[0,50,95,100]),'table',vals.min(),vals.max(),flush=True)
 v=np.memmap('near7200.bin',offset=28,dtype='<u4').reshape(-1,4);caps=np.zeros(1<<20,dtype=int);caps[reps]=rad;cr=caps[(v[:,1]>>1)&((1<<20)-1)];sel=v[:,0].astype(np.int64)+cr>320975646
 print('active roots',sel.sum(),'active maximum cap',cr[sel].max(),'max required among present prefixes',cr.max(),flush=True)
if __name__=='__main__':main()
