"""Turn floating semidefinite dual factors into an exact upper for the fixed vectors."""
from pathlib import Path
import argparse,sys,json,math
from fractions import Fraction as F
import numpy as np
sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parent/'support')];from model_dual import bound
from facet import maps_for
from finalize_round import dec
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('result',type=Path);p.add_argument('--gram',type=Path);o=p.parse_args()
    d=np.load(o.search/'dual_numpy.npz');K=np.loadtxt(o.result/'endpoint.txt',int);I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);pa,sa,pb,sb=maps_for(K,I);n,m=K.shape;full=np.zeros((n+m,n+m))
    for k in range(5):
        P=d['p'+str(k)];Q=d['q'+str(k)];Y=d['y'+str(k)];nr=P.shape[1]
        full[:n,:n]+=P@Y[:nr,:nr]@P.T;full[n:,n:]+=Q@Y[nr:,nr:]@Q.T;full[:n,n:]-=P@Y[:nr,nr:]@Q.T
    full[n:,:n]=full[:n,n:].T;av=np.zeros_like(full);perms=[]
    for p,a,q,b in zip(pa,sa,pb,sb):
        perm=np.r_[p,n+q];sg=np.r_[a,b];av[np.ix_(perm,perm)]+=full*sg[:,None]*sg;perms.append((p.tolist(),a.tolist(),q.tolist(),b.tolist()))
    av*=2/len(pa)
    if o.gram:av=np.load(o.gram)
    eig,V=np.linalg.eigh((av+av.T)/2);use=eig>4e-12;fd=10**10
    h=np.rint((V[:,use]*np.sqrt(eig[use]))*fd).astype(np.int64);wd=10**13;weights=np.maximum(0,np.rint(d['weights']*wd)).astype(np.int64)
    # Preserve the row (or column) Gram proposed by the dual and refactor the
    # *actual* stored vector form. A small ridge controls nearly null directions.
    w=json.loads((o.result/'witness.json').read_text());X=np.asarray(w['alice_numerators'],dtype=float)/float(w['vector_denominator']);Y=np.asarray(w['bob_numerators'],dtype=float)/float(w['vector_denominator'])
    target=X@Y.T-d['alice'].T.astype(float)@((weights/wd)[:,None]*d['bob'])
    averaged=np.zeros_like(target)
    for ra,rs,cb,cs in zip(pa,sa,pb,sb):
        averaged[np.ix_(ra,cb)]+=target*rs[:,None]*cs
    averaged/=len(pa)
    best=np.inf
    for transpose in (False,True):
        gram=av[n:,n:] if transpose else av[:n,:n];T=averaged.T if transpose else averaged
        eigen,vec=np.linalg.eigh(gram);eigen=np.maximum(eigen,0);right=T.T@vec
        for ridge in np.logspace(-15,-4,45):
            v=np.sqrt(eigen+ridge);left=vec*v;rightfactor=right/v
            score=np.sqrt((left*left).sum(axis=1).max()*(rightfactor*rightfactor).sum(axis=1).max())
            if score<best:
                best=score;scale=((rightfactor*rightfactor).sum(axis=1).max()/(left*left).sum(axis=1).max())**.25
                l=left*scale;r=rightfactor/scale;factor=np.vstack((r,l)) if transpose else np.vstack((l,r))
    h=np.rint(factor*fd).astype(np.int64)
    cert=dict(weight_denominator=wd,factor_denominator=fd,weights=weights.tolist(),alice=d['alice'].tolist(),bob=d['bob'].tolist(),factor=h.tolist())
    w=json.loads((o.result/'witness.json').read_text());cert['comparison']=w.get('comparison','scalar')
    if 'dictionary_budget' in w:
        cert['dictionary_arrays']=list(json.loads(str(np.load(o.search/'best.npz')['extra_dictionary'])))

    if 'small_game_budget' in w:cert['chsh_dictionary']=np.load(o.search/'best.npz')['games'].tolist()
    u,err=bound(w,K.tolist(),perms,cert);cert.update(upper_numerator=u.numerator,upper_denominator=u.denominator)
    if 'small_game_budget' in w:
        local,_=bound(w,K.tolist(),perms,cert,False);cert.update(listed_upper_numerator=local.numerator,listed_upper_denominator=local.denominator)
        print('Fixed-vector upper with the explicit dictionary',dec(local,27),flush=True)
    (o.result/'model_dual.json').write_text(json.dumps(cert,separators=(',',':'))+'\n');r=F(w['quantum_numerator']*w['classical_upper_denominator'],w['vector_denominator']**2*w['classical_upper_numerator'])
    print('fixed-vector full matrix certificate upper',dec(u,27),'gap',dec(u-r,10),'max averaged factor residual',dec(err,7),'factor dimension',h.shape[1],flush=True)
if __name__=='__main__':main()
