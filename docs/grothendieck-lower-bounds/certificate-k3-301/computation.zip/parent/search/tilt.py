"""Tune two displacement magnitudes and a shear by the original row in the untwisted orbit."""
import argparse,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from rectangle import fields
prior=Path('/workspace/k3_nov26');sys.path.insert(0,str(prior));from search import quantum
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('out',type=Path);p.add_argument('--grid',type=int,default=10000000);q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 z=np.load(q.model/'candidate.npz');K=z['M'];R=np.loadtxt(prior/'package/base.txt',dtype=int);I=np.loadtxt(q.model/'split_rows.txt',dtype=int);n=len(R);k=len(I);h=k//2;D=K[I]-R[I];C=320975646
 hits=np.unique(np.fromfile(q.hits,dtype='<u4').reshape(-1,6),axis=0);hits=hits[hits[:,0]>C];a,x,e,f=fields(R,I,D,hits);w=(a[:,I[:h]]-a[:,n:n+h])/2;g=w@R[I[:h]]
 def score(theta):
    v=x+theta[0]*e+theta[1]*f+theta[2]*g;s=abs(v).sum(axis=1);i=s.argmax()
    b=np.where(v[i]>=0,1.,-1.);return max(C,s[i]),[e[i]@b,f[i]@b,g[i]@b,x[i]@b]
 def form(s):
    d=np.vstack((s[0]*D[:h]+s[2]*R[I[:h]],s[1]*D[h:]));M=np.vstack((2.*R,R[I]-d));M[I]=R[I]+d;return M
 best=0
 for start in [[.94,.94,0],[.9,.95,.06],[.92,.92,-.04],[1,1,0]]:
    theta=np.array(start);A,B=z['A'],z['B'];rows=[[0,0,0,-1],[1,0,1,0],[1,0,-1,0]];rhs=[-C/1e6,1,1]
    for it in range(25):
      M=form(theta);Q,A,B=quantum(M,A,B,500);t=(A[I]-A[n:])/2;dB=D@B;rB=R[I[:h]]@B;grad=np.array([(dB[:h]*t[:h]).sum(),(dB[h:]*t[h:]).sum(),(rB*t[:h]).sum()]);off=Q/2-grad@theta;val,cut=score(theta);rr=Q/(2*val);old=theta.copy()
      for _ in range(120):
        if cut:
            rows.append([y/1e6 for y in cut[:3]]+[-1]);rhs.append(-cut[3]/1e6)
        res=linprog(np.r_[-grad/1e6,rr],A_ub=rows,b_ub=rhs,bounds=[(0,1),(0,1),(-1,1),(0,None)],method='highs');assert res.success
        theta=res.x[:3];val,cut=score(theta);new=(off+grad@theta)/val
        if val-res.x[-1]*1e6<.0003 and abs(rr-new)<1e-11:break
        rr=new
      theta=np.rint(theta*q.grid)/q.grid
      if max(abs(old-theta))<1e-7:break
    M=form(theta);Q,A,B=quantum(M,A,B,1200);val,_=score(theta);ratio=Q/(2*val);print('start',start,'factor and tilt',theta,'ratio',ratio,'classical',val,flush=True)
    if ratio>best:
      best=ratio;ps=np.rint(theta*q.grid).astype(int);d=np.vstack((ps[0]*D[:h]+ps[2]*R[I[:h]],ps[1]*D[h:]));M=np.vstack((2*q.grid*R,q.grid*R[I]-d));M[I]=q.grid*R[I]+d
      np.savez_compressed(q.out/'best.npz',M=M,A=A,B=B,quantum=Q*q.grid,scale_numerators=ps,scale_denominator=q.grid)
if __name__=='__main__':main()
