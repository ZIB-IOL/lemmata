"""Reduce the auxiliary correlation-factor upper using the five representation blocks."""
from pathlib import Path
import argparse,json,sys
import cvxpy as cp
import numpy as np
from facet import maps_for
from sdp_fit import all_orbits
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('witness',type=Path);p.add_argument('out',type=Path);q=p.parse_args();d=np.load(q.search/'dual_numpy.npz');w=json.loads((q.witness/'witness.json').read_text());K=np.loadtxt(q.witness/'endpoint.txt',int);n,m=K.shape;I=np.loadtxt(Path(__file__).resolve().parents[1]/'split_rows.txt',int);pa,sa,pb,sb=maps_for(K,I)
    X=np.asarray(w['alice_numerators'],dtype=float)/float(w['vector_denominator']);Y=np.asarray(w['bob_numerators'],dtype=float)/float(w['vector_denominator']);weights=np.rint(d['weights']*1e13)/1e13;res=X@Y.T-d['alice'].T.astype(float)@(weights[:,None]*d['bob']);R=np.zeros_like(K,dtype=float)
    for a,s,b,t in zip(pa,sa,pb,sb):R[np.ix_(a,b)]+=res*s[:,None]*t
    R/=len(pa);rg=all_orbits(pa);cg=all_orbits(pb);tr=[0]*len(rg);tc=[0]*len(cg);parts=[];cones=[];v=cp.Variable();rebuild=np.zeros_like(R)
    for k in range(5):
        P=d['p'+str(k)];Q=d['q'+str(k)];T=P.T@R@Q;probe=P@T@Q.T;avg=np.zeros_like(probe)
        for a,s,b,t in zip(pa,sa,pb,sb):avg[np.ix_(a,b)]+=probe*s[:,None]*t
        avg/=len(pa);small=P.T@avg@Q;order=round((T*T).sum()/((small*T).sum()));assert order in [1,3,4,5];rebuild+=order*avg
        A=cp.Variable((T.shape[0],T.shape[0]),symmetric=True);B=cp.Variable((T.shape[1],T.shape[1]),symmetric=True);cones.append(cp.bmat([[A,order*T],[order*T.T,B]])>>0)
        for i,J in enumerate(rg):tr[i]=tr[i]+cp.sum(cp.multiply(P[J].T@P[J],A))/len(J)
        for i,J in enumerate(cg):tc[i]=tc[i]+cp.sum(cp.multiply(Q[J].T@Q[J],B))/len(J)
        parts.append((P,Q,A,B))
    assert np.max(abs(rebuild-R))<1e-8
    prog=cp.Problem(cp.Minimize(v),cones+[x<=v for x in tr+tc]);prog.solve(solver='CLARABEL',max_threads=1,tol_gap_rel=2e-9,tol_gap_abs=2e-10,tol_feas=8e-10)
    assert v.value is not None;ra=sum(P@A.value@P.T for P,Q,A,B in parts);cb=sum(Q@B.value@Q.T for P,Q,A,B in parts);left=np.zeros_like(ra);right=np.zeros_like(cb)
    for a,s,b,t in zip(pa,sa,pb,sb):left[np.ix_(a,a)]+=ra*s[:,None]*s;right[np.ix_(b,b)]+=cb*t[:,None]*t
    av=np.block([[left/len(pa),R],[R.T,right/len(pa)]])
    np.save(q.out,av);print('numerical correlation factor',v.value,prog.status,flush=True)
if __name__=='__main__':main()
