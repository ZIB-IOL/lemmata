import numpy as np

def norm(x):
    return x / np.maximum(np.linalg.norm(x, axis=1)[:,None], 1e-80)

def orbit_basis(pa, sa, pb, sb):
    grid = np.full((pa.shape[1],pb.shape[1]), -1, dtype=int)
    signs = np.ones_like(grid)
    forced = []
    n = 0
    for i,j in zip(*np.indices(grid.shape).reshape(2,-1)):
        if grid[i,j] >= 0:
            continue
        ii,jj = pa[:,i],pb[:,j]
        ss = sa[:,i]*sb[:,j]
        grid[ii,jj], signs[ii,jj] = n, ss
        if np.any(signs[ii,jj] != ss):
            forced.append(n)
        n += 1
    return grid,signs,forced

def quantum(M,A,B,iters=150):
    old=0.
    for step in range(iters):
        Z=M.T@A; lengths=np.linalg.norm(Z,axis=1)
        B=np.where((lengths>0)[:,None],Z/np.maximum(lengths[:,None],1e-70),B)
        T=M@B; A=norm(T); q=np.linalg.norm(T,axis=1).sum()
        if step%10==9 and abs(q-old)<1e-7: break
        if step%10==9: old=q
    return q,A,B
