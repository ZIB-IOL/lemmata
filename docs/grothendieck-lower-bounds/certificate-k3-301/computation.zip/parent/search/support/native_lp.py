"""Persistent HiGHS LP using the native bindings bundled with SciPy 1.17."""
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize._highspy import _core as native

class PersistentLP:
    def __init__(self,bounds,normal):
        self.n=len(bounds);self.normal=normal;self.rows=set()
        self.solver=native._Highs()
        for k,v in [('threads',1),('output_flag',False),('solver','simplex'),('primal_feasibility_tolerance',1e-8),('dual_feasibility_tolerance',1e-9)]:
            assert self.solver.setOptionValue(k,v)==native.HighsStatus.kOk
        lo=np.array([p[0] for p in bounds],float);hi=np.array([p[1] for p in bounds],float)
        z=np.array([],dtype=np.int32);d=np.array([],dtype=float)
        status=self.solver.addCols(self.n,np.zeros(self.n),lo,hi,0,np.zeros(self.n+1,dtype=np.int32),z,d)
        assert status==native.HighsStatus.kOk
    def solve(self,H,q):
        added=[]
        for row in H:
            key=np.ascontiguousarray(row,dtype=np.int16).tobytes()
            if key not in self.rows:self.rows.add(key);added.append(row)
        if added:
            a=csr_matrix(np.array(added,dtype=float)*self.normal)
            status=self.solver.addRows(a.shape[0],np.full(a.shape[0],-native.kHighsInf),np.ones(a.shape[0]),a.nnz,a.indptr.astype(np.int32),a.indices.astype(np.int32),a.data)
            assert status==native.HighsStatus.kOk
        status=self.solver.changeColsCost(self.n,np.arange(self.n,dtype=np.int32),-np.asarray(q,dtype=float))
        assert status==native.HighsStatus.kOk
        status=self.solver.run()
        if status!=native.HighsStatus.kOk or self.solver.getModelStatus()!=native.HighsModelStatus.kOptimal:
            raise RuntimeError(str(self.solver.getModelStatus()))
        return np.asarray(self.solver.getSolution().col_value),self.solver.getInfo().simplex_iteration_count

if __name__=='__main__':
    from scipy.optimize import linprog
    rng=np.random.default_rng(19);H=rng.integers(-5,6,size=(90,12),dtype=np.int16);q=rng.normal(size=12)
    bounds=[(-.3,.3)]*12;p=PersistentLP(bounds,1.)
    for n in [30,50,90]:
        x,_=p.solve(H[:n],q)
        z=linprog(-q,A_ub=H[:n],b_ub=np.ones(n),bounds=bounds,method='highs',options={'threads':1})
        assert z.success and abs(q@x+z.fun)<1e-8 and np.max(H[:n]@x)<=1+1e-8
    print('Native warm-start LP agrees with SciPy on three incremental cut sets.')
