import numpy as np

def unit_ball(x,D):
    nums=np.trunc(x*D).astype(np.int64).astype(object)
    for v in nums:
        while sum(k*k for k in v)>D*D:
            i=np.argmax(np.abs(v));v[i]-=int(np.sign(v[i]))
    return nums
