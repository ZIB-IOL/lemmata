"""Generate signed, equivariant transfers between Bob columns."""
import numpy as np,json
from pathlib import Path
from transport_bounds import gradient
def matrices(pb,sb,moves):
    n=pb.shape[1];ans=[]
    for i,j,s in moves:
        L=np.zeros((n,n));rows=pb[:,i];cols=pb[:,j];weights=s*sb[:,i]*sb[:,j]
        np.add.at(L,(rows,rows),-1);np.add.at(L,(rows,cols),weights);L/=len(rows)//len(set(rows));ans.append(L)
    return np.stack(ans)
def select(p,w,out):
    A,total,pb,sb=gradient(p,w);allmoves=[];old=set()
    for i in [0,1,2,4,6,7,8,9,10,42]:
        count=0
        for j in np.argsort(-abs(A[i])):
            if i==j:continue
            s=1 if A[i,j]>=0 else -1;equiv=tuple(sorted(set(zip(pb[:,i].tolist(),pb[:,j].tolist(),(s*sb[:,i]*sb[:,j]).tolist()))))
            if equiv in old:continue
            old.add(equiv);allmoves.append([i,int(j),s]);count+=1
            if count==3:break
    out.write_text(json.dumps(allmoves)+'\n')
if __name__=='__main__':select(Path('anchor_guided'),Path('guided_test'),Path('transport_moves.json'))
