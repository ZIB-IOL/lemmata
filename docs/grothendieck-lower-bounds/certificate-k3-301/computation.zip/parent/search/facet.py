"""Refine an equivariant split witness using its complete near-classical Alice strategies."""
import argparse,json,math,sys,time
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize._highspy import _core as native
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'))
from search import quantum,orbit_basis

def maps_for(K,I):
    base=np.loadtxt(prior.parent/'base.txt',dtype=int);n,m=base.shape;inds={v:h for h,v in enumerate(I)};D=K[I]-base[I]
    lines=(prior.parent/'symmetry.txt').read_text().splitlines()[2:];maps=[]
    for z in range(0,len(lines),4):
        pa,sa,pb,sb=[np.fromstring(v,sep=' ',dtype=int) for v in lines[z:z+4]]
        P=np.r_[pa,pa[I]].copy();S=np.r_[sa,sa[I]]
        for h,i in enumerate(I):
            j=pa[i];v=inds[j];w=D[v,pb];old=D[h]*sa[i]*sb
            if np.array_equal(w,old):P[i],P[n+h]=j,n+v
            else:
                assert np.array_equal(w,-old);P[i],P[n+h]=n+v,j
        assert np.array_equal(K[np.ix_(P,pb)],K*S[:,None]*sb)
        maps.append((P,S,pb,sb))
    return [np.stack(v) for v in zip(*maps)]
def spectral_bound(delta):
    n,m=delta.shape
    gram=delta@delta.T
    return min(int(abs(delta).sum()),math.isqrt(n*m*int(abs(gram).sum(axis=1).max()))+1)
def certified_delta_norm(delta,iterations=7):
    # Positive integer test vector for |Gram| improves the row-sum bound.
    n,m=delta.shape;G=abs(delta@delta.T);w=np.ones(n,dtype=np.int64)*1000000
    ans=spectral_bound(delta);save=w.copy()
    for _ in range(iterations+1):
        # use Python integers even when a candidate was proposed on a large trust region
        y=G.astype(object)@w.astype(object)
        upper=max((int(t)+int(s)-1)//int(s) for s,t in zip(w,y))
        val=math.isqrt(n*m*upper)+1
        if val<=ans:ans=val;save=w.copy()
        if not np.any(y):return 0,save
        top=max(y);w=np.array([max(1,int(v)*1000000//int(top)) for v in y],dtype=np.int64)
    return ans,save
def main():
    p=argparse.ArgumentParser();p.add_argument('center',type=Path);p.add_argument('out',type=Path);p.add_argument('--width',type=float,default=180);p.add_argument('--rounds',type=int,default=130);p.add_argument('--pool',type=Path);p.add_argument('--tolerance',type=int,default=1000000);p.add_argument('--previous',type=Path);opts=p.parse_args();opts.out.mkdir(exist_ok=True,parents=True)
    z=np.load(opts.center/'candidate.npz');K=z['M'];A,B=z['A'],z['B'];I=np.loadtxt(opts.center/'split_rows.txt',dtype=int);n,m=K.shape
    if opts.previous:
        prev=np.load(opts.previous);A,B=prev['A'],prev['B']
    C=641951292;limit=opts.tolerance
    maps=maps_for(K,I);grid,sign,forced=orbit_basis(*maps);idx=grid.ravel();sg=sign.ravel();nv=int(idx.max()+1)
    wbase=np.zeros(nv,dtype=int);wbase[idx]=K.ravel()*sg;assert np.array_equal(wbase[grid]*sign,K)
    hit=np.unique(np.fromfile(opts.pool or opts.center/'near_lift.bin',dtype='<u4').reshape(-1,6),axis=0);a=1.-2*np.unpackbits(np.ascontiguousarray(hit[:,1:]).view(np.uint8),axis=1,bitorder='little')[:,:n];a=np.ascontiguousarray(a);scores=hit[:,0].astype(np.int64)*2
    assert max(scores)==C and np.array_equal(scores,np.rint(abs(a@K.astype(float)).sum(axis=1)).astype(np.int64))
    kf=K.astype(float);best=0;start=time.monotonic();H=native._Highs()
    for key,val in [('threads',1),('output_flag',False),('solver','simplex'),('primal_feasibility_tolerance',1e-8)]:H.setOptionValue(key,val)
    W=opts.width;lo=np.full(nv+1,-1.);hi=np.ones(nv+1);lo[forced]=0;hi[forced]=0;lo[-1]=-15000;hi[-1]=15000
    idxs=np.arange(nv+1,dtype=np.int32);obj=np.r_[np.bincount(idx,weights=(A@B.T).ravel()*sg,minlength=nv),-z['quantum']/C]
    H.addCols(nv+1,-obj,lo,hi,0,np.zeros(nv+2,dtype=np.int32),np.empty(0,dtype=np.int32),np.empty(0))
    seen=set();counter=0
    def cuts(sel,bmat):
        nonlocal counter
        rows=[];rhs=[]
        for j,b in zip(sel,bmat):
            v=np.bincount(idx,weights=(a[j,:,None]*b).ravel()*sg,minlength=nv).astype(np.int16);key=v.tobytes()
            if key in seen:continue
            seen.add(key);rows.append(np.r_[v,-1]);rhs.append((C-int(v.astype(np.int64)@wbase))/W)
        if rows:
            t=csr_matrix(np.asarray(rows,dtype=float));H.addRows(len(rows),np.full(len(rows),-native.kHighsInf),np.array(rhs),t.nnz,t.indptr.astype(np.int32),t.indices.astype(np.int32),t.data)
            counter+=len(rows)
    ini=np.argsort(scores)[-min(480,len(scores)):];cuts(ini,np.where(a[ini]@kf>=0,1.,-1.))
    for it in range(opts.rounds):
        H.run();assert H.getModelStatus()==native.HighsModelStatus.kOptimal
        x=np.asarray(H.getSolution().col_value)*W;delta=np.rint(x[:-1]).astype(np.int64)[grid]*sign;d0,w=certified_delta_norm(delta,4)
        # Once outside this radius the complement of the enumeration could win.
        # Evaluate several scales inside and at the certificate boundary.
        scale=min(1.,(limit-1500)/max(d0-x[-1],1))
        trial=[min(1.,scale*s) for s in (.8,.96,1.,1.01)] if it%3==0 else [min(1.,scale*.995)]
        ci=np.asarray(A@B.T)
        for mix in sorted(set(trial)):
            dm=np.rint(mix*x[:-1]).astype(np.int64)[grid]*sign;norm,weights=certified_delta_norm(dm,5);M=K+dm
            # The infinity-to-one norm bound covers the entire excluded sign space.
            vals=np.rint(abs(a@M.astype(float)).sum(axis=1)).astype(np.int64);j=vals.argmax()
            outside=C-limit+norm;den=max(int(vals[j]),outside);q=float(np.einsum('ij,ij->',ci,M));ratio=q/den
            if ratio>best+2e-13:
                optQ,aa,bb=quantum(M.astype(float),A,B,150)
                np.savez_compressed(opts.out/'best.npz',M=M,A=aa,B=bb,quantum=optQ,lower=int(vals[j]),upper=den,sign=a[j].astype(int),weights=weights,delta_bound=norm,iteration=it,scale=mix)
                best=ratio;print('gain',it,'ratio',optQ/den,'classical',den,'attained',int(vals[j]),'norm',norm,'scale',round(mix,5),flush=True)
        raw=kf+x[:-1][grid]*sign;Y=a@raw;v=abs(Y).sum(axis=1);order=np.argsort(v)[::-1];excess=v[order[0]]-C-x[-1]
        print('lp',it,'constraints',counter,'violation',round(excess,2),'elapsed',round(time.monotonic()-start,1),flush=True)
        if excess<.3:break
        pos=order[v[order]>C+x[-1]+.03][:95];cuts(pos,np.where(Y[pos]>=0,1.,-1.))
if __name__=='__main__':main()
