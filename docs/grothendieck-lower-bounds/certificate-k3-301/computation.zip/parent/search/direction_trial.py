"""Screen changes in the displacement shape after projecting away the fitted scale direction."""
from pathlib import Path
import sys,json
import numpy as np
from reweight import setup
sys.path.insert(0,'/workspace/k3_nov26');from search import quantum
def run():
 p=Path('raymax');z,mats,a,groups=setup(p,p/'sample_screen.bin',p/'shallow_physical.bin');weights=np.load('physical2/best.npz') if Path('physical2/best.npz').exists() else np.load('physical_trial/best.npz');v=weights['parameters']/int(weights['scale_denominator'])
 M=np.tensordot(v,mats,axes=1);base=np.loadtxt('/workspace/k3_nov26/package/base.txt',dtype=int);I=np.loadtxt(p/'split_rows.txt',dtype=int);de=z['M'][I]-base[I]
 y=a@M;pr=np.load('physical_trial/best.npz');A=pr['A'];B=pr['B']
 for nm in ['high_shape','high50','high100','high_other']:
    hh=np.load(nm+'/candidate.npz')['M'][I]-base[I];pieces=[]
    for x,r in zip(np.array_split(hh,2),np.array_split(de,2)):
       if np.vdot(x@B,r@B)<0:x=-x
       # Integer row equivariance survives the componentwise symmetric rounding.
       gamma=np.vdot(x,r)/np.vdot(r,r);pieces.append(np.rint(x-gamma*r).astype(int))
    H=np.concatenate(pieces);S=np.vstack((np.zeros_like(base),-H));S[I]=H;Y=a@S;best=0
    for eta in [-.02,0,.005,.01,.02,.04,.08,.15,.3]:
       q,aa,bb=quantum(M+eta*S,A,B,150);val=abs(y+eta*Y).sum(axis=1).max();rr=q/val;best=max(best,rr)
       G=abs(H@H.T);e=np.sqrt(len(H)*H.shape[1]*G.sum(axis=1).max())
       print(nm,eta,rr,'classical',val,'error_bound',int(abs(eta)*e),flush=True)
    np.savetxt(f'{nm}/direction.txt',H,fmt='%d')
if __name__=='__main__':run()
