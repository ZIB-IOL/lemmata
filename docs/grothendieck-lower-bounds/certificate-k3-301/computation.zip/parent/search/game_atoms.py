"""Construct orbit averages of relabeled CHSH matrices and price their exact sign bound."""
from pathlib import Path
import argparse,json,numpy as np
from local_game_pricing import residual,price
from facet import orbit_basis
def atom_key(game,grid,sg,forced):
    i,k,j,l,s,t=game;acc={}
    for row,col,val in [(i,j,s),(k,j,s),(i,l,t),(k,l,-t)]:
        h=int(grid[row,col])
        if h not in forced:acc[h]=acc.get(h,0)+val*int(sg[row,col])
    return tuple(sorted((h,v) for h,v in acc.items() if v))
def coefficients(games,grid,sg,forced,ids,count=60):
    freq=np.bincount(grid.ravel());look={v:i for i,v in enumerate(ids)};out=np.zeros((len(games),len(ids)),dtype=np.int16)
    for g,game in enumerate(games):
        for h,v in atom_key(game,grid,sg,forced):
            a,b=divmod(count*v,int(freq[h]));assert b==0
            out[g,look[h]]=a
    return out
def main():
    p=argparse.ArgumentParser();p.add_argument('search',type=Path);p.add_argument('wit',type=Path);p.add_argument('out',type=Path);p.add_argument('--old',type=Path);p.add_argument('--batch',type=int,default=70);a=p.parse_args();G,w,K,ops=residual(a.search,a.wit);grid,sg,bad=orbit_basis(*ops);forbidden=set(bad);games=json.loads(a.old.read_text()) if a.old else [];seen={atom_key(g,grid,sg,forbidden) for g in games};extra=0;best=price(G)
    for val,g in best:
        k=atom_key(g,grid,sg,forbidden)
        if not k or k in seen:continue
        seen.add(k);games.append(g);extra+=1
        if extra>=a.batch:break
    a.out.write_text(json.dumps(games,separators=(',',':'))+'\n');print('priced CHSH',best[0][0],'added',extra,'total',len(games))
if __name__=='__main__':main()
