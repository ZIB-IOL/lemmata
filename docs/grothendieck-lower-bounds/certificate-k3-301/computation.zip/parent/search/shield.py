"""Upper-bound the amplified game by a sum of norms of blocks of rows."""
import argparse,json,subprocess,tempfile
from pathlib import Path
import numpy as np
here=Path(__file__).resolve().parent
prior=Path('/workspace/k3_nov26')
def partition(rows,A,rng,num):
    # Divide each variable orbit into balanced blocks of comparable size and angular spacing.
    if num==1:return [np.array(rows)]
    best=None;groups=None
    for _ in range(900):
        p=np.array_split(rng.permutation(rows),num)
        penalty=sum(np.linalg.norm(A[v].T@A[v]-len(v)*np.eye(3)/3)**2 for v in p)
        penalty+=sum(.4*np.sum((A[v]@A[v].T-np.eye(len(v)))**16) for v in p)
        if best is None or penalty<best:best=penalty;groups=p
    return groups

def main():
    p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('--mult',type=int,nargs='+',default=[4,6,8,10,12]);p.add_argument('--blocks',type=int,default=2);p.add_argument('--seed',type=int,default=34);p.add_argument('--out',type=Path,required=True);p.add_argument('--fixed-bound',type=int);a=p.parse_args()
    a.out.mkdir(exist_ok=True,parents=True);R=np.loadtxt(prior/'package/base.txt',dtype=int)
    K=np.loadtxt(a.model/'lifted_matrix.txt',dtype=int);I=np.atleast_1d(np.loadtxt(a.model/'split_rows.txt',dtype=int));D=np.zeros_like(R);D[I]=K[I]-R[I]
    s=np.load(prior/'package/construction/search_inputs.npz')
    order=np.array(json.loads(Path('/workspace/matrix_improvement/orbit89/preproc_provenance.json').read_text())['ordered_to_original'])
    A=s['A'][order];groupmap=np.stack([np.fromstring(l,sep=' ',dtype=int) for l in (prior/'package/symmetry.txt').read_text().splitlines()[2::4]])
    fixed=np.array(sorted(set(range(len(R)))-set(I)));parts=[fixed];rng=np.random.default_rng(a.seed)
    un=set(I)
    while un:
        i=min(un);J=np.sort(np.unique(groupmap[:,i]));assert set(J)<=un;un-=set(J);parts.extend(partition(J,A,rng,a.blocks))
    def compute(block,mult):
        path=a.out/'input.tmp';np.savetxt(path,np.column_stack((R[block],mult*D[block])),fmt='%d')
        return int(subprocess.check_output([str(here/'block_bound'),str(path)],text=True).split()[0])
    caps=[compute(fixed,1) if a.fixed_bound is None else a.fixed_bound]
    print('fixed',len(fixed),caps[0],flush=True)
    best=np.inf
    for mult in a.mult:
        bounds=caps+[compute(b,mult) for b in parts[1:]];total=sum(bounds)
        slope=(total-320975646)/(mult-1)
        print('multiplier',mult,'bounds',bounds,'total',total,'sufficient near radius',round(slope),flush=True)
        if slope<best:
            best=slope
            (a.out/'shield.json').write_text(json.dumps({'multiplier':mult,'blocks':[b.tolist() for b in parts],'upper_bounds':bounds},indent=1)+'\n')
if __name__=='__main__':main()
