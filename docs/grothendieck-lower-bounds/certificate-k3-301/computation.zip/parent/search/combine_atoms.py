from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--previous',type=Path);p.add_argument('--base',type=Path);p.add_argument('--reference',type=Path);p.add_argument('--small',type=Path);p.add_argument('--limit',type=int,default=16);a=p.parse_args();data=json.loads(a.previous.read_text()) if a.previous else [];seen={json.dumps(q,sort_keys=True) for q in data}
for kind,path in [('base',a.base),('reference',a.reference),('small',a.small)]:
    if path is None:continue
    vals=json.loads(path.read_text())
    for x in vals[:a.limit]:
        q={**{k:v for k,v in x.items() if k!='price'},'kind':kind};key=json.dumps(q,sort_keys=True)
        if key not in seen:data.append(q);seen.add(key)
a.out.write_text(json.dumps(data,separators=(',',':'))+'\n');print('dictionary',len(data))
