"""Optimize one extra equivariant displacement direction under an explicit magnitude limit."""
import argparse,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from reweight import setup
sys.path.insert(0,str(Path(__file__).resolve().parent/'support'));from search import quantum
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('extra',type=Path);p.add_argument('direction',type=Path);p.add_argument('out',type=Path);p.add_argument('--max',type=float,default=.04);p.add_argument('--scale-max',type=float,default=.99);p.add_argument('--floor',type=float,default=641951292);p.add_argument('--grid',type=int,default=100000000);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 z,mats,signs,gs=setup(a.model,a.hits,a.extra);R=np.loadtxt('/workspace/k3_nov26/package/base.txt',dtype=int);I=np.loadtxt(a.model/'split_rows.txt',dtype=int);h=np.loadtxt(a.direction,dtype=int);n=len(R);S=np.vstack((np.zeros_like(R),-h));S[I]=h;mats=np.concatenate((mats,S[None,:,:]));F=np.asarray([signs@w for w in mats],dtype=float);C=a.floor
 def scores(t):
    yy=np.tensordot(t,F,axes=1);vs=abs(yy).sum(axis=1);i=vs.argmax();b=np.where(yy[i]>=0,1,-1);g=F[:,i]@b;return max(C,vs[i]),g
 cs={};best=0
 for st in [0,.02,-.01]:
    t=np.array([1.,1.,1.,1.,.935,.942,0,st]);A,B=z['A'],z['B']
    for it in range(18):
      Q,A,B=quantum(np.tensordot(t,mats,axes=1),A,B,600);grad=(mats*(A@B.T)).sum(axis=(1,2));val,cut=scores(t);rr=Q/val;old=t.copy()
      for j in range(120):
        cs[tuple(cut.tolist())]=cut;P=[[*list(g/1e6),-1] for g in cs.values()]+[[0]*8+[-1],[0,0,0,0,.97,0,1,0,0],[0,0,0,0,.97,0,-1,0,0]]
        rhs=[0]*len(cs)+[-C/1e6,.97,.97];bounds=[(.97,1)]*4+[(0,a.scale_max),(0,a.scale_max),(-.97,.97),(-a.max,a.max),(0,None)]
        sol=linprog(np.r_[-grad/1e6,rr],A_ub=P,b_ub=rhs,bounds=bounds,method='highs');assert sol.success
        t=sol.x[:-1];val,cut=scores(t);now=t@grad/val
        if val-sol.x[-1]*1e6<.001 and abs(now-rr)<1e-11:break
        rr=now
      t=np.rint(t*a.grid)/a.grid
      if abs(t-old).max()<1.5/a.grid:break
    Q,A,B=quantum(np.tensordot(t,mats,axes=1),A,B,900);val,g=scores(t);ratio=Q/val;print('t',t.tolist(),'classical',val,'matrix ratio',ratio,'observed attained',g@t,flush=True)
    if ratio>best:
      best=ratio;pp=np.rint(t*a.grid).astype(int)
      # Guarantee an attained value above the reference floor despite scale-grid rounding.
      for rep in range(10):
         t=pp/a.grid;val,g=scores(t)
         if g@t>=C:break
         j=4+np.argmax(g[4:6]);pp[j]+=1
      t=pp/a.grid;Q,A,B=quantum(np.tensordot(t,mats,axes=1),A,B,900)
      np.savez_compressed(a.out/'best.npz',M=np.tensordot(pp,mats,axes=1),A=A,B=B,quantum=Q*a.grid,parameters=pp,scale_denominator=a.grid)
if __name__=='__main__':main()
