"""Improve the rational rank-three witness and certify the fixed matrix in all dimensions."""
from pathlib import Path
from fractions import Fraction
import argparse
import json
import shutil
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fixed_matrix import refine, propose, bound
from cover import matrix


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('out', type=Path)
    opt = parser.parse_args()
    opt.out.mkdir(parents=True, exist_ok=True)
    M = matrix(opt.source/'matrix.txt')
    witness = json.loads((opt.source/'witness.json').read_text())
    C = witness['attained']
    assert Fraction(witness['classical_upper_numerator'], witness['classical_upper_denominator']) == C
    D = 10**36
    score, A, B = refine(M, witness['alice_numerators'], D)
    old = Fraction(witness['quantum_numerator'], C*witness['vector_denominator']**2)
    lower = Fraction(score, C*D**2)
    assert lower >= old
    cert = propose(M, A, B, D)
    upper = bound(M, cert, C)
    assert upper >= lower
    for path in opt.source.iterdir():
        if path.is_file() and path.name not in ('witness.json','model_dual.json','vector_room.json','matrix_upper.json'):
            shutil.copyfile(path,opt.out/path.name)
    decimals = 16
    floor = (lower.numerator*10**decimals - 1)//lower.denominator
    strict = f'{floor//10**decimals}.{floor%10**decimals:0{decimals}d}'
    witness.update(vector_denominator=D, quantum_numerator=score, alice_numerators=A,
                   bob_numerators=B, strict_lower_bound=strict)
    for name, value in [('witness.json',witness),('matrix_upper.json',cert)]:
        (opt.out/name).write_text(json.dumps(value,separators=(',',':'))+'\n')
    print('strict lower',strict,'gain from higher-precision vectors',float(lower-old),
          'fixed-matrix all-dimension headroom',float(upper-lower),flush=True)


if __name__ == '__main__':
    main()
