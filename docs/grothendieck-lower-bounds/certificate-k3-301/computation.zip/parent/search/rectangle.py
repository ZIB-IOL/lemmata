"""Optimize two displacement scales against the active Alice strategies of the upper corner."""
import argparse,json,sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
prior=Path(__file__).resolve().parent;sys.path.insert(0,str(prior/'support'))
from search import quantum
C=320975646
def fields(R,I,E,hit):
 n=len(R);k=len(I);split=k//2;bits=np.unpackbits(np.ascontiguousarray(hit[:,1:]).view(np.uint8),axis=1,bitorder='little')
 a=(1.-2*bits[:,:n+k]);a0=a[:,:n].copy();w=(a0[:,I]-a[:,n:])/2;a0[:,I]=(a0[:,I]+a[:,n:])/2
 return a,a0@R,w[:,:split]@E[:split],w[:,split:]@E[split:]
def fit(q0,grad,ratio,fields_,initial):
 _,x,e1,e2=fields_;current=np.array(initial,dtype=float);rows=[[0,0,-1]];rhs=[-C/1e6]
 def evaluate(s):
    if not len(x):return C,None
    y=x+s[0]*e1+s[1]*e2;values=abs(y).sum(axis=1);i=np.argmax(values)
    if values[i]<=C:return C,None
    b=np.where(y[i]>=0,1.,-1.);return values[i],(float(e1[i]@b),float(e2[i]@b),float(x[i]@b))
 for j in range(75):
    value,cut=evaluate(current)
    if cut is not None:
        g1,g2,off=cut;rows.append([g1/1e6,g2/1e6,-1]);rhs.append(-off/1e6)
    res=linprog(np.r_[-grad/1e6,ratio],A_ub=rows,b_ub=rhs,bounds=[(0,1),(0,1),(0,None)],method='highs');assert res.success
    current=res.x[:2];value,cc=evaluate(current);gap=value-res.x[-1]*1e6
    rr=(q0+grad@current)/value
    if gap<.00003 and abs(rr-ratio)<1e-12:break
    ratio=rr
 return current,evaluate(current)[0],gap
def main():
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('hits',type=Path);p.add_argument('out',type=Path);p.add_argument('--grid',type=int,default=1000000);q=p.parse_args();q.out.mkdir(exist_ok=True,parents=True)
 z=np.load(q.model/'candidate.npz');K=z['M'];R=np.loadtxt(prior.parent/'base.txt',dtype=int);I=np.loadtxt(q.model/'split_rows.txt',dtype=int);n=len(R);E=K[I]-R[I];h=len(I)//2
 rec=np.unique(np.fromfile(q.hits,dtype='<u4').reshape(-1,6),axis=0);rec=rec[rec[:,0]>C];F=fields(R,I,E,rec)
 if len(rec):assert np.array_equal(abs(F[1]+F[2]+F[3]).sum(axis=1),rec[:,0])
 def model(s):
    d=np.vstack((s[0]*E[:h],s[1]*E[h:]));M=np.vstack((2.*R,R[I]-d));M[I]=R[I]+d;return M
 best=0
 for start in ([.86,.86],[.95,.85],[.83,.98],[1.,1.]):
    s=np.array(start);A,B=z['A'],z['B']
    for it in range(25):
        Q,A,B=quantum(model(s),A,B,600);W=(A[I]-A[n:])/2;proj=(E@B)*W;g=np.array([proj[:h].sum(),proj[h:].sum()]);off=Q/2-g@s
        nxt,den,gap=fit(off,g,Q/(2*C),F,s);nxt=np.clip(np.rint(nxt*q.grid)/q.grid,0,1)
        if np.array_equal(nxt,s):break
        s=nxt
    M=model(s);Q,A,B=quantum(M,A,B,1500);vals=abs(F[1]+s[0]*F[2]+s[1]*F[3]).sum(axis=1);val=max(C,vals.max(initial=0));ratio=Q/(2*val)
    print('start',start,'scales',s.tolist(),'ratio',ratio,'classical',val,'inner LP residual',gap,'iterations',it,'active signs at corner',len(rec),flush=True)
    if ratio>best:
        best=ratio;ps=np.rint(s*q.grid).astype(int);d=np.vstack((ps[0]*E[:h],ps[1]*E[h:]));matrix=np.vstack((2*q.grid*R,q.grid*R[I]-d));matrix[I]=q.grid*R[I]+d
        np.savez_compressed(q.out/'best.npz',M=matrix,A=A,B=B,quantum=Q*q.grid,scale_numerators=ps,scale_denominator=q.grid)
if __name__=='__main__':main()
