"""Compute integer caps for averaged reference embeddings, including row compatibility between orientations."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import tempfile

def key(atom):
    return json.dumps(atom,sort_keys=True,separators=(',',':'))

def caps(center, perms, records, atoms, cutoff, limit=768, compiler='g++'):
    here=Path(__file__).resolve().parent
    if not atoms:
        return {}
    n,m=len(center),len(center[0])
    rec=list(struct.iter_unpack('<6I',Path(records).read_bytes()))
    with tempfile.TemporaryDirectory(prefix='k3-embeddings-') as name:
        path=Path(name)
        exe=path/'orbit_caps'
        subprocess.run([compiler,'-std=c++17','-O3',str(here/'orbit_caps_bob.cpp'),'-o',str(exe)],check=True)
        filename=path/'data.txt'
        with filename.open('w') as stream:
            def row(vals):print(*vals,file=stream)
            row([n,m,len(perms),len(rec),len(atoms),cutoff])
            for x in center:row(x)
            for h in perms:
                for x in h:row(x)
            for score,a,b,c,d,e in rec:row([2*score,a+(b<<32),c+(d<<32),e])
            for atom in atoms:
                assert atom['kind']=='reference'
                for k in ('rows','row_signs','columns','column_signs'):row(atom[k])
        out=subprocess.check_output([str(exe),str(filename),str(limit)],text=True)
    results=[list(map(int,line.split())) for line in out.splitlines()]
    assert [r[0] for r in results]==list(range(len(atoms)))
    return {key(a):r[1:] for a,r in zip(atoms,results)}

if __name__=='__main__':
    import sys
    root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
    from band_certificate import second_endpoint
    from cover import matrix
    base=matrix(root/'base.txt'); first=matrix(root/'lifted_matrix.txt')
    rows=list(map(int,(root/'split_rows.txt').read_text().split()))
    K,_,perms=second_endpoint(root,base,first,rows,matrix(root/'symmetry.txt'))
    atoms=[a for a in json.loads((root/'search/extra_dictionary.json').read_text()) if a['kind']=='reference']
    result=caps(K,perms,root/'second/band.bin',atoms,641519292,int(sys.argv[3]) if len(sys.argv)>3 else 768)
    Path(sys.argv[2]).write_text(json.dumps(result,separators=(',',':'))+'\n')
