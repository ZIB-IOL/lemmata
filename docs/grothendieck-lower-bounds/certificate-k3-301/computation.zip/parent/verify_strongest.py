"""Verify the strongest matrix and regenerate the exhaustive reference band."""

import argparse, hashlib, json, os, struct, subprocess, tempfile
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
from construction.rebuild import rebuild
from cover import caps, matrix
from band_certificate import signed, check_scores

ROOT = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError("Run Python without -O so the certificate checks are enabled.")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--cached-band", "--vectors-only", dest="vectors_only", action="store_true")
    p.add_argument("--portable", action="store_true")
    p.add_argument("--compiler", default="g++")
    p.add_argument("--scratch", type=Path)
    opt = p.parse_args()
    os.environ["CXX"] = opt.compiler
    assert 1 <= opt.threads <= 256
    for f, h in json.loads((ROOT / "SHA256SUMS.json").read_text()).items():
        assert hashlib.sha256((ROOT / f).read_bytes()).hexdigest() == h, f
    base = matrix(ROOT / "base.txt")
    first = rebuild()
    I = list(map(int, (ROOT / "split_rows.txt").read_text().split()))
    sym = matrix(ROOT / "symmetry.txt")
    d = ROOT / "second"
    w = json.loads((d / "witness.json").read_text())
    saved = d / "band.bin"
    witness, M, center, ratio = signed(w, ROOT, base, first, I, sym, saved)
    print(
        "Checked rank-three vectors, exact numerator, residual norm, stored sign scores and the attaining signing.",
        flush=True,
    )
    from band_certificate import second_endpoint
    from verify_extension import verify
    _, _, perms = second_endpoint(ROOT, base, first, I, sym)
    def decimal(x):
        with localcontext() as ctx:
            ctx.prec = 40
            return Decimal(x.numerator) / Decimal(x.denominator)
    print("Compact rank-three ratio", decimal(ratio), flush=True)
    ceiling_file = ROOT / "family.json"
    if ceiling_file.is_file():
        from family_ceiling import bound
        cert = json.loads(ceiling_file.read_text())
        supplied = {json.dumps(a, sort_keys=True) for a in cert["dictionary_arrays"]}
        assert all(json.dumps(t["atom"], sort_keys=True) in supplied
                   for t in json.loads((d / "extra_games.json").read_text()))
        upper, _ = bound(w, center, perms, cert)
        assert ratio <= upper < F("1.439628654")
        print("Fixed-vector certificate-family upper", decimal(upper), flush=True)
    best = ratio
    if (ROOT / "extension.json").is_file():
        ext = json.loads((ROOT / "extension.json").read_text())
        rate, info = verify(ROOT, w, M, center, perms, ext)
        best = max(best, rate)
        print("First extension on", info["columns"], "columns", decimal(rate), flush=True)
    side = ROOT / "larger"
    if (side / "extension.json").is_file():
        for item in ("extra_direction.txt", "second/recipe.json", "second/band.bin", "second/endpoint.txt"):
            assert (ROOT/item).read_bytes() == (side/item).read_bytes()
        incumbent = json.loads((side/"second/witness.json").read_text())
        _, M2, center2, _ = signed(incumbent, side, base, first, I, sym, saved)
        assert center2 == center
        for file in ("two-orbits.json", "extension.json"):
            ext = json.loads((side/file).read_text())
            rate, info = verify(side, incumbent, M2, center2, perms, ext)
            best = max(best, rate)
            print("Jointly fitted extension on", info["columns"], "columns", decimal(rate), flush=True)
    down = best.numerator * 10**16 // best.denominator
    strict = f"{down//10**16}.{down%10**16:016d}"
    assert best > F(strict)
    if opt.vectors_only:
        print("Verified K_G(3) >", strict, "against the archived reference list.", flush=True)
        return
    with tempfile.TemporaryDirectory(dir=opt.scratch, prefix="order-three-") as name:
        tmp = Path(name)
        flags = ["-O3", "-std=c++17", "-fopenmp"]
        if not opt.portable:
            flags += ["-march=native"]
        for exe in (
            "enumerate",
            "conditional_block",
            "check_margin",
            "shallow_fast",
            "score_band",
        ):
            subprocess.run(
                [opt.compiler, *flags, str(ROOT / (exe + ".cpp")), "-o", str(tmp / exe)],
                check=True,
            )
        from test_band import run

        run(tmp, tmp / "check_margin", tmp / "shallow_fast", tmp / "conditional_block")
        C = 320975646
        B = w["reference_margin"]
        cv = json.loads((ROOT / "cover.json").read_text())
        mul = cv["multiplier"]
        upper = caps(base, center, I, sym, cv, tmp / "conditional_block", tmp, opt.threads)
        L = {
            r: max(0, (v - C + mul - 2) // (mul - 1)) + (B + mul - 2) // (mul - 1)
            for r, v in upper.items()
        }
        largest = max(L.values())
        threshold = C - B - largest
        assert largest == 6488158 and threshold == 314271488
        cf = tmp / "caps.txt"
        cf.write_text("".join(f"{r} {v}\n" for r, v in L.items()))
        print(
            "Checked all",
            len(L),
            "conditional bounds. Enumerating the original signings.",
            flush=True,
        )
        near = tmp / "near.bin"
        th = str(opt.threads)
        subprocess.run(
            [
                str(tmp / "enumerate"),
                str(ROOT / "base.txt"),
                str(ROOT / "base.txt"),
                str(ROOT / "tails.txt"),
                str(threshold),
                th,
                "12",
                "--symmetry",
                str(ROOT / "symmetry.txt"),
                "--enumerate-above",
                "--packed-near",
                str(near),
            ],
            check=True,
        )
        with near.open("rb") as f:
            assert f.read(8) == b"K3SIG001" and struct.unpack("<IIIQ", f.read(20)) == (
                len(base),
                len(base[0]),
                threshold,
                7832114,
            )
        active = tmp / "second.bin"
        subprocess.run(
            [
                str(tmp / "check_margin"),
                str(ROOT / "base.txt"),
                str(d / "endpoint.txt"),
                str(ROOT / "split_rows.txt"),
                str(ROOT / "symmetry.txt"),
                str(near),
                str(threshold),
                str(C),
                th,
                str(largest),
                str(cf),
                str(active),
                str(B),
            ],
            check=True,
        )
        data = set(struct.iter_unpack("<6I", active.read_bytes()))
        stored = set(struct.iter_unpack("<6I", saved.read_bytes()))
        assert len(stored) == w["records"] and data == stored
        check_scores(ROOT, w, saved, tmp / "score_band")
        print("Verified K_G(3) >", strict, "with exhaustive regeneration.", flush=True)


if __name__ == "__main__":
    main()
