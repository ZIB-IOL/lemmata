// Exact simultaneous upper bounds for symmetry averages of contracted reference matrices.
// All signs with reference score above the cutoff are supplied up to the group and global sign.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <unordered_map>
#include <vector>

using I = std::int64_t;
using U = std::uint64_t;
using Bits = std::array<U,3>;
struct Hash {
    std::size_t operator()(const Bits& x) const {
        return (x[0]*11995408973635179863ull ^ x[1])*11400714819323198485ull ^ x[2];
    }
};
bool bit(const Bits& x, int i) { return (x[i/64] >> (i%64)) & 1; }
void set(Bits& x,int i) { x[i/64] |= U(1)<<(i%64); }
Bits project(Bits x,const Bits& mask) {
    bool decided=false, flip=false;
    for (int k=0;k<3;++k) {
        if (mask[k] && !decided) {
            flip=(x[k] & (mask[k] & -mask[k]))!=0;
            decided=true;
        }
        x[k]=(flip ? ~x[k] : x[k]) & mask[k];
    }
    return x;
}
struct Map { std::vector<int> p,s,b,t; };
struct Image { Bits a; int rec,g; };
using BobBits = std::array<U,6>;
struct Candidate {
    I score; Bits assignment;
    BobBits forced{}, negative{};
};
bool first_sign(const Bits& row,const Bits& mask) {
    for (int k=0;k<3;++k) if(mask[k]) return row[k] & (mask[k]&-mask[k]);
    return false;
}
struct Option { I score; U fixed, negative; bool alice_flip; };
std::vector<int> ints(std::istream& in,int n) {
    std::vector<int> r(n);
    for (int& x:r) { in>>x; assert(in); }
    return r;
}
int main(int argc,char** argv) {
    assert(argc==3);
    std::ifstream in(argv[1]);
    int limit=std::stoi(argv[2]); assert(limit>0);
    int n,m,G,R,N; I cutoff;
    in>>n>>m>>G>>R>>N>>cutoff;
    assert(n>0 && n<=192 && m>0 && m<=384 && G>0 && R>0 && N>0);
    std::vector<std::vector<int>> K;
    for(int i=0;i<n;++i) K.push_back(ints(in,m));
    I total=0;
    for(const auto& r:K) for(int v:r) total+=std::abs(I(v));
    assert(total<(I(1)<<40) && G<1024);
    std::vector<Map> maps;
    for(int g=0;g<G;++g) maps.push_back({ints(in,n),ints(in,n),ints(in,m),ints(in,m)});
    std::vector<std::vector<I>> fields(R,std::vector<I>(m));
    std::vector<I> scores(R); std::vector<Image> images;
    for(int r=0;r<R;++r) {
        U a0,a1,a2; in>>scores[r]>>a0>>a1>>a2;
        Bits a{a0,a1,a2}; auto& f=fields[r];
        for(int i=0;i<n;++i) for(int j=0;j<m;++j) f[j]+=(bit(a,i)?-1:1)*I(K[i][j]);
        I sum=0;for(I x:f) sum+=std::abs(x);
        assert(sum==scores[r] && sum>cutoff);
        for(int g=0;g<G;++g) {
            const auto& h=maps[g]; Bits b{};
            for(int i=0;i<n;++i) if(bit(a,i) != (h.s[i]<0)) set(b,h.p[i]);
            images.push_back({b,r,g});
        }
    }
    std::sort(images.begin(),images.end(),[&](const Image& x,const Image& y){
        return scores[x.rec]>scores[y.rec];
    });
    for(int atom=0;atom<N;++atom) {
        auto ia=ints(in,n), sa=ints(in,n), ib=ints(in,m), sb=ints(in,m);
        std::vector<int> first(n,-1), used;
        std::vector<std::array<int,3>> eq;
        Bits support{};
        for(int i=0;i<n;++i) {
            assert(ia[i]>=0 && ia[i]<n && std::abs(sa[i])==1);
            int k=first[ia[i]];
            if(k==-1) {first[ia[i]]=i;used.push_back(ia[i]);set(support,ia[i]);}
            else eq.push_back({k,i,sa[i]!=sa[k]});
        }
        for(int j=0;j<m;++j) assert(ib[j]>=0 && ib[j]<m && std::abs(sb[j])==1);
        std::vector<std::vector<int>> bins(G);
        // Only repeated output columns can lower the source l1 norm. A signed source index is encoded as +/-(j+1).
        for(int g=0;g<G;++g) {
            std::vector<std::vector<int>> groups(m);
            for(int j=0;j<m;++j) {
                int k=maps[g].b[j];
                groups[ib[k]].push_back((j+1)*maps[g].t[j]*sb[k]);
            }
            for(const auto& group:groups) if(group.size()>1) {
                bins[g].insert(bins[g].end(),group.begin(),group.end()); bins[g].push_back(0);
            }
        }
        std::vector<Candidate> top;
        I threshold=cutoff;
        auto prune=[&]() {
            if(int(top.size())<=limit) return;
            std::nth_element(top.begin(),top.begin()+limit,top.end(),[](const Candidate& a,const Candidate& b){return a.score>b.score;});
            threshold=std::max(threshold,top[limit].score);
            top.erase(std::remove_if(top.begin(),top.end(),[&](const Candidate& c){return c.score<=threshold;}),top.end());
        };
        for(const auto& im:images) {
            I value=scores[im.rec];
            if(value<=threshold) break;
            bool ok=true;
            for(const auto& e:eq) if((bit(im.a,e[0])!=bit(im.a,e[1]))!=bool(e[2])) {ok=false;break;}
            if(!ok) continue;
            const auto& f=fields[im.rec];
            I abs_sum=0,sum=0;
            for(int k:bins[im.g]) {
                if(k) {I v=k>0? f[k-1] : -f[-k-1];sum+=v;abs_sum+=std::abs(v);}
                else {value-=abs_sum-std::abs(sum);sum=0;abs_sum=0;if(value<=threshold) break;}
            }
            if(value<=threshold) continue;
            Bits x{};
            for(int j:used) {int i=first[j];if(bit(im.a,i)!=(sa[i]<0)) set(x,j);}
            Candidate cand{value,project(x,support)};
            bool flip=first_sign(x,support);
            std::vector<I> out(m);
            for(int j=0;j<m;++j) {
                int k=maps[im.g].b[j];
                out[ib[k]]+=f[j]*maps[im.g].t[j]*sb[k];
            }
            for(int j=0;j<m;++j) {
                if(2*std::abs(out[j])<value-cutoff) continue;
                cand.forced[j/64]|=U(1)<<(j%64);
                if((out[j]<0)!=flip) cand.negative[j/64]|=U(1)<<(j%64);
            }
            top.push_back(cand);
            if(int(top.size())>=2*limit+1) prune();
        }
        prune();
        std::sort(top.begin(),top.end(),[](const Candidate& a,const Candidate& b){return a.assignment<b.assignment;});
        top.erase(std::unique(top.begin(),top.end(),[](const Candidate& a,const Candidate& b){
            if(a.assignment!=b.assignment) return false;
            assert(a.score==b.score && a.forced==b.forced && a.negative==b.negative);
            return true;
        }),top.end());
        std::sort(top.begin(),top.end(),[](const Candidate& a,const Candidate& b){return a.score>b.score;});
        int ntest=std::min(m,64);
        std::vector<int> test(ntest);
        for(int i=0;i<ntest;++i) test[i]=i*m/ntest;
        std::vector<U> fixed0(top.size()),negative0(top.size());
        for(size_t l=0;l<top.size();++l) for(int t=0;t<ntest;++t) {
            int j=test[t];
            fixed0[l]|=((top[l].forced[j/64]>>(j%64))&1)<<t;
            negative0[l]|=((top[l].negative[j/64]>>(j%64))&1)<<t;
        }
        std::vector<I> accumulated(top.size()); I raw=threshold, sum_bound=G*threshold;
        for(const auto& c:top) raw=std::max(raw,c.score);
        for(const auto& h:maps) {
            Bits rotated_support{}, common{};
            for(int j:used) set(rotated_support,h.p[j]);
            for(int k=0;k<3;++k) common[k]=support[k]&rotated_support[k];
            std::unordered_map<Bits,std::vector<Option>,Hash> best;
            std::vector<int> inv(m);
            for(int j=0;j<m;++j) inv[h.b[j]]=j;
            for(const auto& c:top) {
                Bits x{};
                for(int j:used) if(bit(c.assignment,j)!=(h.s[j]<0)) set(x,h.p[j]);
                U fixed=0,negative=0;
                for(int t=0;t<ntest;++t) {
                    int j=inv[test[t]];
                    fixed|=((c.forced[j/64]>>(j%64))&1)<<t;
                    negative|=(((c.negative[j/64]>>(j%64))&1)^U(h.t[j]<0))<<t;
                }
                best[project(x,common)].push_back({c.score,fixed,negative,first_sign(x,common)});
            }
            for(size_t l=0;l<top.size();++l) {
                auto it=best.find(project(top[l].assignment,common));
                I v=threshold;
                if(it!=best.end()) {
                    bool af=first_sign(top[l].assignment,common);
                    for(const auto& q:it->second) {
                        U fixed=fixed0[l]&q.fixed;
                        U agree=negative0[l]^q.negative;
                        bool flip=af!=q.alice_flip;
                        if(((flip?~agree:agree)&fixed)==0 ||
                           ((common[0]|common[1]|common[2])==0 && ((~agree)&fixed)==0)) {
                            v=q.score;break;
                        }
                    }
                }
                accumulated[l]+=std::min(top[l].score,v);
            }
        }
        for(I v:accumulated) sum_bound=std::max(sum_bound,v);
        std::cout<<atom<<" "<<raw<<" "<<(sum_bound+G-1)/G<<" "<<threshold<<" "<<top.size()<<"\n";
    }
}
