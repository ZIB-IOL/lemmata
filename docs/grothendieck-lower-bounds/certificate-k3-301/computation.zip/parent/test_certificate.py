"""Brute-force both sides of the amplified and near argument on small integer games."""

import itertools, random, struct, subprocess
from pathlib import Path
from cover import caps


def put(path, rows):
    path.write_text("".join(" ".join(map(str, row)) + "\n" for row in rows))


def tests(tmp, near_solver, block_solver, active_solver=None):
    rng = random.Random(261127)
    covered_far = False
    positive = False
    for seed in range(16):
        n, m = 6, 7
        pre = 2
        ii = list(range(pre, n))
        k = len(ii)
        r = [[rng.randint(-10, 10) for _ in range(m)] for i in range(n)]
        d = [[rng.randint(-7, 7) for _ in range(m)] for i in ii]
        K = [[2 * x for x in row] for row in r] + [
            [v - w for v, w in zip(r[i], d[h])] for h, i in enumerate(ii)
        ]
        for h, i in enumerate(ii):
            K[i] = [v + w for v, w in zip(r[i], d[h])]
        sy = [[pre, 2, 1], [0, 1], list(range(n)), [1] * n, list(range(m)), [1] * m]
        for f, dt in [("r", r), ("k", K), ("i", [ii]), ("s", sy)]:
            put(tmp / f, dt)
        ss = list(itertools.product((1, -1), repeat=m))

        def norm(M):
            return max(sum(abs(sum(a * b for a, b in zip(row, v))) for row in M) for v in ss)

        c = norm(r)
        truth = norm(K)
        positive |= truth > 2 * c
        # Uniform total mass is one at each row. The amplified-game checker
        # may relax its coefficients through rounding exactly as in the large proof.
        cv = {
            "multiplier": 4,
            "denominator": 1,
            "indices": list(range(n)),
            "weight_numerators": [1] * n,
        }
        U = caps(r, K, ii, sy, cv, block_solver, tmp, 1)
        limit = {p: max(0, (u - c + 2) // 3) for p, u in U.items()}
        # The gain cannot exceed the sum of row norms. The two caps are independent.
        raw = max(
            sum(abs(sum(d[h][j] * s[h] for h in range(k))) for j in range(m))
            for s in itertools.product((1, -1), repeat=k)
        )
        for p in limit:
            limit[p] = min(limit[p], raw)
        covered_far |= min(limit.values()) < raw
        L = max(limit.values())
        T = c - L
        if L == 0:
            T = c - 1
        assert T >= 0
        put(tmp / "caps", limit.items())
        rec = []
        for aa in itertools.product((1, -1), repeat=n - 1):
            a = (1,) + aa
            value = sum(abs(sum(a[i] * r[i][j] for i in range(n))) for j in range(m))
            if value > T:
                rec.append((value, sum(1 << i for i, x in enumerate(a) if x < 0), 0, 0))
        data = (
            b"K3SIG001"
            + struct.pack("<IIIQ", n, m, T, len(rec))
            + b"".join(struct.pack("<IIII", *row) for row in rec)
        )
        (tmp / "records").write_bytes(data)
        args = [
            str(near_solver),
            *[str(tmp / f) for f in ["r", "k", "i", "s", "records"]],
            str(T),
            str(c),
            "1",
            str(L),
            str(tmp / "caps"),
        ]
        out = subprocess.check_output(args, text=True)
        if active_solver is not None:
            arr = tmp / "active_test.bin"
            subprocess.run(
                [str(active_solver), *args[1:], str(arr)], stdout=subprocess.DEVNULL, check=True
            )
            active = []
            for rec in set(struct.iter_unpack("<6I", arr.read_bytes())):
                signs = [1 - 2 * ((rec[1 + j // 32] >> (j % 32)) & 1) for j in range(n + k)]
                score = sum(abs(sum(v * x for v, x in zip(signs, col))) for col in zip(*K))
                assert score == 2 * rec[0] and rec[0] > c
                active.append(signs)
            for p0, p1 in [(0, 0), (2, 5), (5, 1), (4, 3), (5, 5)]:
                M = [[10 * x for x in row] for row in r]
                for h, i in enumerate(ii):
                    mul = p0 if h < 2 else p1
                    M[i] = [5 * x + mul * y for x, y in zip(r[i], d[h])]
                    M.append([5 * x - mul * y for x, y in zip(r[i], d[h])])
                scores = [
                    sum(abs(sum(v * x for v, x in zip(signs, col))) for col in zip(*M))
                    for signs in active
                ]
                assert max([10 * c] + scores) == norm(M)
        val = int(
            next(l.split()[1] for l in out.splitlines() if l.startswith("NEAR_ATTAINED "))
        )
        assert val == truth
    assert positive and covered_far
    print(
        "16 brute-force games verified, including strict amplification and nonzero classical penalties.",
        flush=True,
    )


def symmetry_test(tmp, enumerator, active_solver, block_solver):
    rng = random.Random(1553)
    n, m = 7, 8
    pa = [0, 2, 1, 4, 3, 6, 5]
    sa = [1, -1, -1, 1, 1, -1, -1]
    pb = [1, 0, 3, 2, 5, 4, 7, 6]
    sb = [1, 1, -1, -1, 1, 1, -1, -1]
    r = [[0] * m for _ in range(n)]
    d = [[0] * m for _ in range(n)]
    for j in (0, 2, 4, 6):
        r[0][j] = rng.randint(-35, 35)
        r[0][pb[j]] = sb[j] * r[0][j]
    for i in (1, 3, 5):
        r[i] = [rng.randint(-35, 35) for _ in range(m)]
        if i >= 3:
            d[i] = [rng.randint(-19, 19) for _ in range(m)]
        for j in range(m):
            r[pa[i]][pb[j]] = sa[i] * sb[j] * r[i][j]
            d[pa[i]][pb[j]] = (1 if i == 3 else -1) * sa[i] * sb[j] * d[i][j]
    I = list(range(3, 7))
    K = [[2 * v for v in row] for row in r]
    for i in I:
        K[i] = [x + y for x, y in zip(r[i], d[i])]
        K.append([x - y for x, y in zip(r[i], d[i])])
    # The signed swap maps prefix mask 0 to 3. The other two are fixed.
    reps = [0, 1, 2]
    sym = [[3, 3, 2], reps, list(range(n)), [1] * n, list(range(m)), [1] * m, pa, sa, pb, sb]
    cv = {
        "multiplier": 4,
        "indices": [0, 1, 3, 5],
        "weight_numerators": [1, 2, 2, 2],
        "denominator": 1,
    }
    for f, rows in [("r", r), ("k", K), ("i", [I]), ("s", sym)]:
        put(tmp / f, rows)
    signs = list(itertools.product((1, -1), repeat=m))

    def maximum(M):
        return max(sum(abs(sum(x * y for x, y in zip(row, b))) for row in M) for b in signs)

    C = maximum(r)
    ud = caps(r, K, I, sym, cv, block_solver, tmp, 1)
    raw = maximum([d[i] for i in I])
    L = {i: min(raw, max(0, (u - C + 2) // 3)) for i, u in ud.items()}
    cap = max(L.values())
    T = C - max(1, cap)
    assert T >= 0
    put(tmp / "caps", L.items())
    put(tmp / "tails", [[sum(sum(map(abs, row)) for row in r[h:])] for h in range(n + 1)])
    subprocess.run(
        [
            str(enumerator),
            str(tmp / "r"),
            str(tmp / "r"),
            str(tmp / "tails"),
            str(T),
            "1",
            "3",
            "--symmetry",
            str(tmp / "s"),
            "--enumerate-above",
            "--packed-near",
            str(tmp / "near"),
        ],
        stdout=subprocess.DEVNULL,
        check=True,
    )
    subprocess.run(
        [
            str(active_solver),
            str(tmp / "r"),
            str(tmp / "k"),
            str(tmp / "i"),
            str(tmp / "s"),
            str(tmp / "near"),
            str(T),
            str(C),
            "1",
            str(cap),
            str(tmp / "caps"),
            str(tmp / "active"),
        ],
        stdout=subprocess.DEVNULL,
        check=True,
    )
    ac = [
        [1 - 2 * ((row[1 + i // 32] >> (i % 32)) & 1) for i in range(len(K))]
        for row in struct.iter_unpack("<6I", (tmp / "active").read_bytes())
    ]
    for b0, b1, p0, p1, mu in [
        (100, 100, 100, 100, 0),
        (97, 98, 50, 75, 30),
        (99, 100, 10, 95, -58),
        (98, 97, 100, 0, 0),
    ]:
        M = [[2 * (b0 if i < 3 else b1) * x for x in row] for i, row in enumerate(r)]
        for i in I:
            v = [
                (p0 if i < 5 else p1) * y + (mu if i < 5 else 0) * x for x, y in zip(r[i], d[i])
            ]
            M[i] = [b1 * x + y for x, y in zip(r[i], v)]
            M.append([b1 * x - y for x, y in zip(r[i], v)])
        top = max(
            [200 * C]
            + [sum(abs(sum(s * x for s, x in zip(a, col))) for col in zip(*M)) for a in ac]
        )
        assert top == max(200 * C, maximum(M))
    print(
        "Signed-symmetry, conditional-cover, row-exchange, tilt and reweight tests passed.",
        flush=True,
    )
