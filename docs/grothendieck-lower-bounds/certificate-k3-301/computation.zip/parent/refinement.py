"""Verify the seven-parameter refined matrix and its fixed-vector certificates."""

from fractions import Fraction
from pathlib import Path
import json
from cover import matrix


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def domain():
    e = [[int(i == j) for i in range(7)] for j in range(7)]
    sg = lambda k, row: [k * x for x in row]
    d = []
    for j in range(4):
        d.extend([[-97, *sg(100, e[j])], [1, *sg(-1, e[j])]])
    for j in (4, 5):
        d.extend([[0, *e[j]], [1, *sg(-1, e[j])]])
    for s in (-1, 1):
        d.append([97, 0, 0, 0, 0, -97, 0, s * 100])
    return d


def components(base, endpoint, I, sym, groups):
    n, m = len(base), len(base[0])
    k = len(I)
    h = k // 2
    assert (
        k % 2 == 0
        and len(groups) == 4
        and sorted(i for g in groups for i in g) == list(range(n))
    )
    assert set(groups[2]) == set(I[:h]) and set(groups[3]) == set(I[h:])
    g_at = {i: v for v, group in enumerate(groups) for i in group}
    d = [[v - w for v, w in zip(endpoint[i], base[i])] for i in I]
    loc = {i: h for h, i in enumerate(I)}
    for at in range(2, len(sym), 4):
        pa, sa, pb, sb = sym[at : at + 4]
        assert all(g_at[i] == g_at[j] for i, j in enumerate(pa))
        for a, i in enumerate(I[:h]):
            other = d[loc[pa[i]]]
            assert all(other[pb[j]] == sa[i] * sb[j] * v for j, v in enumerate(d[a]))
    mats = [[[0] * m for _ in range(n + k)] for _ in range(7)]
    for i, row in enumerate(base):
        if i not in loc:
            mats[g_at[i]][i] = [2 * x for x in row]
            continue
        a = loc[i]
        mats[g_at[i]][i] = row
        mats[g_at[i]][n + a] = row
        slot = 4 + int(a >= h)
        mats[slot][i] = d[a]
        mats[slot][n + a] = [-x for x in d[a]]
        if a < h:
            mats[6][i] = row
            mats[6][n + a] = [-x for x in row]
    return mats


def verify(root, base, end, I, sym, records, base_C):
    w = json.loads((root / "witness.json").read_text())
    den = w["denominator"]
    p = w["weights"]
    assert type(den) is int and den > 0 and len(p) == 7 and all(type(v) is int for v in p)
    assert all(d[0] * den + dot(d[1:], p) >= 0 for d in domain())
    mats = components(base, end, I, sym, w["base_orbits"])
    K = [[dot(p, col) for col in zip(*rows)] for rows in zip(*mats)]
    assert K == matrix(root / "final_matrix.txt")
    X, Y = w["alice_numerators"], w["bob_numerators"]
    D = w["vector_denominator"]
    n = len(K)
    m = len(K[0])
    assert (
        len(X) == n
        and len(Y) == m
        and all(
            len(v) == 3 and all(type(x) is int for x in v) and dot(v, v) <= D * D for v in X + Y
        )
    )
    gram = [[dot(x, y) for y in Y] for x in X]
    form = [0] + [sum(dot(r, g) for r, g in zip(M, gram)) for M in mats]
    N = dot(p, form[1:])
    assert N == w["quantum_numerator"]

    def score(signs):
        return sum(abs(dot(signs, col)) for col in zip(*K))

    win = w["alice_signs"]
    assert len(win) == n and all(x in (-1, 1) for x in win)
    extra = set()
    if "shallow_cutoff" in w:
        import struct
        from supplement import parameters

        parameters(w, K, base_C)
        extra = set(struct.iter_unpack("<6I", (root / "supplement.bin").read_bytes()))
    top = max(
        ([0] if extra or "shallow_cutoff" in w else [2 * base_C * den])
        + [
            score([1 - 2 * ((rec[1 + i // 32] >> (i % 32)) & 1) for i in range(n)])
            for rec in (records | extra)
        ]
    )
    assert top == score(win) == w["classical"]
    ratio = Fraction(N, D * D * top)
    assert ratio > Fraction(w["strict_lower_bound"])
    for filename, allow_floor in [
        ("certificate_dual.json", True),
        ("physical_dual.json", False),
    ]:
        path = root / filename
        if not path.exists():
            assert allow_floor == ("shallow_cutoff" in w)
            continue
        cs = json.loads(path.read_text())
        combo = [Fraction() for x in form]
        total = Fraction()
        for item in cs["terms"]:
            weight = Fraction(item["weight_numerator"], item["weight_denominator"])
            assert weight >= 0
            if item["kind"] == "sign":
                a, b = item["alice"], item["bob"]
                assert len(a) == n and len(b) == m and all(x in (-1, 1) for x in a + b)
                v = [0] + [sum(s * dot(row, b) for s, row in zip(a, M)) for M in mats]
                total += weight
            elif item["kind"] == "floor":
                assert allow_floor
                v = [2 * base_C] + [0] * 7
                total += weight
            else:
                assert item["kind"] == "domain" and item["affine_slack"] in domain()
                v = [-x for x in item["affine_slack"]]
            for j, t in enumerate(v):
                combo[j] += weight * t
        assert combo == form
        upper = total / D**2
        assert upper == Fraction(cs["numerator"], cs["denominator"]) and upper >= ratio
        if allow_floor or "shallow_cutoff" in w:
            assert upper == ratio
        if not allow_floor and "individual_upper_numerator" in w:
            from all_parameters import bound

            full = bound(root, w, base, end, I, sym, upper, base_C)
            assert full == Fraction(
                w["individual_upper_numerator"], w["individual_upper_denominator"]
            )
    return w, ratio
