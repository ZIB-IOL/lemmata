"""Verify a column extension of a certified comparison, using integer scores throughout."""
from fractions import Fraction as F
import json
from math import isqrt
from pathlib import Path
import struct
from cover import matrix
from packed_scores import Scores

def orbits(seed,perms,den):
    i,j,sign,r=seed
    m=len(perms[0][2])
    assert all(type(x) is int for x in seed) and 0<=i<m and -1<=j<m and sign in (-1,1) and r>0
    if j==-1:
        assert r==den
        return sorted({(p[i],-1,1) for _,_,p,_ in perms})
    assert i!=j
    return sorted({(p[i],p[j],sign*s[i]*s[j]) for _,_,p,s in perms})

def columns(z,perms,m,scale):
    d=z['ratio_denominator'];Z=z['incumbent_weight'];Y=z['reference_weight']
    assert type(d) is int and d>0 and type(Z) is int and Z>0 and type(Y) is int
    used=[0]*m;new_mass=[0]*m;extra=[]
    for item in z['mergers']:
        seed=item['seed'];v=item['weight']
        assert type(v) is int and v>0
        r=seed[3]
        for a,b,s in orbits(seed,perms,d):
            used[a]+=v*d
            if b>=0:
                used[b]+=v*r;new_mass[a]+=v*d;new_mass[b]+=v*r
                extra.append((a,b,v*d*scale,v*r*s*scale))
    old=Z*d
    diagonal=[scale*(d*Y-v) for v in used]
    return old,diagonal,[v*scale for v in new_mass],extra

def signed_scores(packed,mask,n):
    digits=mask.to_bytes((n+7)//8,'little')
    value=packed.offset-sum(table[digit] for table,digit in zip(packed.tables,digits))
    return [v-(1<<63) for v in packed.unpack(value.to_bytes(packed.width,'little'))]

def verify(root,model,M,K,perms,z):
    w=model;m=len(K[0]);n=len(K);scale=w['scale_denominator']; cutoff=2*(320975646-w['reference_margin'])
    mult,dk,added_mass,extra=columns(z,perms,m,scale)
    W=matrix(root/'second/transport.txt')
    mass=max(sum(abs(mult*v+(dk[i] if j==i else 0)) for j,v in enumerate(row))+added_mass[i] for i,row in enumerate(W))
    outside=mass*cutoff+mult*(F(w['outside_numerator'],w['outside_denominator'])-w['transport_mass']*cutoff)
    assert outside>=0
    p0,p1=Scores(M),Scores(K);near=-1;best=None
    for record in struct.iter_unpack('<6I',(root/'second/band.bin').read_bytes()):
        mask=sum(v<<(32*i) for i,v in enumerate(record[1:]))
        f=signed_scores(p0,mask,n);h=signed_scores(p1,mask,n)
        score=sum(abs(mult*x+d*y) for x,d,y in zip(f,dk,h))
        score+=sum(abs(u*h[a]+v*h[b]) for a,b,u,v in extra)
        if score>near:near,best=score,mask
    X=z['alice_numerators'];D=z['vector_denominator']
    assert type(D) is int and D>0 and len(X)==n and all(len(x)==3 and all(type(t) is int for t in x) and sum(t*t for t in x)<=D*D for x in X)
    def fields(C):
        return [tuple(sum(a*b for a,b in zip(row,c)) for c in zip(*X)) for row in zip(*C)]
    p=fields(M);q=fields(K)
    def length(vec):return isqrt(sum(v*v for v in vec))
    quantum=sum(length([mult*u+d*v for u,v in zip(a,b)]) for a,b,d in zip(p,q,dk))
    quantum+=sum(length([u*x+v*y for x,y in zip(q[a],q[b])]) for a,b,u,v in extra)
    classical=max(F(near),outside);ratio=F(quantum,D)/classical
    result=dict(columns=m+len(extra),attained=near,attaining_mask=best,
                outside_numerator=outside.numerator,outside_denominator=outside.denominator,
                classical_numerator=classical.numerator,classical_denominator=classical.denominator,
                quantum_lower_numerator=quantum)
    if 'result' in z:
        assert z['result']==result and ratio>F(z['strict_lower_bound'])
    return ratio,result
