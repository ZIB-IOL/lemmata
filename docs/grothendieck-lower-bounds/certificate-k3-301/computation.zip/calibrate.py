"""Balance the reference and remainder and confirm the exact signed score of the resulting matrix."""
import argparse,json,subprocess,tempfile
from decimal import Decimal,localcontext
from fractions import Fraction as F
from pathlib import Path
from certificate import PARENT,HERE,T,read,dump,put,reconstruct

def process(case,exe,threads=4,build=False):
    spec,w,K,H,M,mass,outside=reconstruct(PARENT,case)
    cert=read(case/'result.json');vec=read(case/'vectors.json');X,Y,D=vec['alice'],vec['bob'],vec['vector_denominator']
    gram=[[sum(a*b for a,b in zip(x,y)) for y in Y] for x in X]
    hq=sum(v*g for row,rr in zip(H,gram) for v,g in zip(row,rr));fq=cert['quantum_numerator']-hq
    m=len(Y);t0=T*mass;uf=outside-t0
    precision=10**12
    def gradients(mask,lam):
        b=[1-2*((mask[j//64]>>(j%64))&1) for j in range(m)]
        h=[sum(t*v for t,v in zip(row,b)) for row in H]
        f=[sum(t*v for t,v in zip(row,b))-x for row,x in zip(M,h)]
        a=[1 if lam.denominator*x+lam.numerator*y>=0 else -1 for x,y in zip(h,f)]
        return sum(x*y for x,y in zip(a,h)),sum(x*y for x,y in zip(a,f))
    with tempfile.TemporaryDirectory() as name:
        tmp=Path(name);put(tmp/'M',M);put(tmp/'H',H);memo={}
        def eval_at(p):
            if p in memo:return memo[p]
            lam=F(p,precision);words=subprocess.check_output([str(exe),str(tmp/'M'),str(tmp/'H'),str(case/'split-band.txt'),str(precision),str(p),str(threads)],text=True).split()
            near=int(words[0]);mask=list(map(int,words[1:]));h,f=gradients(mask,lam);assert near==precision*h+p*f
            far=precision*t0+p*uf;num=precision*hq+p*fq;rate=F(num,D**2)/max(F(near),far)
            memo[p]=(rate,near,far,mask,h,f,num);return memo[p]
        if build:
            lines={(F(t0),uf),gradients(cert['attaining_bob_mask'],F(1))};lo,hi=F(99,100),F(101,100)
            for it in range(14):
                positions={lo,hi,F(1)}
                for a,b in lines:
                    for c,d in lines:
                        if b!=d:
                            xx=F(c-a,b-d)
                            if lo<=xx<=hi:positions.add(xx)
                def optimistic(lam):return F(hq+lam*fq,D**2)/max(a+lam*b for a,b in lines)
                trial=max(positions,key=optimistic);p=round(trial*precision)
                _,_,_,_,a,b,_=eval_at(p)
                if (a,b) in lines:
                    for delta in (-3,3):
                        eval_at(p+delta)
                    break
                lines.add((a,b))
            eval_at(precision)
            # Prefer an attained denominator when comparing numerically indistinguishable results.
            peak=max(v[0] for v in memo.values())
            attained=[p for p,v in memo.items() if v[1]>=v[2] and peak-v[0]<F(1,10**14)]
            best=max(attained or memo,key=lambda p:memo[p][0])
        else:best=read(case/'calibration.json')['remainder_weight']
        rate,near,far,mask,h,f,num=eval_at(best);v=rate.numerator*10**16//rate.denominator
        data=dict(reference_weight=precision,remainder_weight=best,near=near,far_numerator=far.numerator,far_denominator=far.denominator,mask=mask,quantum_numerator=num,strict_lower=f'{v//10**16}.{v%10**16:016d}')
        assert rate>F(data['strict_lower'])
        if build:dump(case/'calibration.json',data)
        else:assert data==read(case/'calibration.json')
        with localcontext() as c:
            c.prec=50
            print('calibrated ratio',Decimal(rate.numerator)/Decimal(rate.denominator),'exact classical maximum attained',near>=far,'remainder weight',best,flush=True)
    return rate
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--build',action='store_true');p.add_argument('--threads',type=int,default=4);o=p.parse_args()
    with tempfile.TemporaryDirectory() as n:
        exe=Path(n)/'score_weight';subprocess.run(['g++','-O3','-std=c++17','-fopenmp',str(HERE/'score_weight.cpp'),'-o',str(exe)],check=True);process(o.case,exe,o.threads,o.build)
