# An explicit witness for $K_G(3)>1.4397098471655953$

For a real matrix $A$, let $C(A)=\max_{b\in\{\pm1\}^m}\|Ab\|_1$. Let $Q_d(A)$ be the largest value of $\sum_{ij}A_{ij}\langle x_i,y_j\rangle$ over real unit vectors of dimension $d$. The real Grothendieck constant of order three is the supremum of $Q_3(A)/C(A)$ over all finite nonzero $A$.

**Theorem.** There is an explicit 301 by 321 integer matrix $W$ such that
$$
 1.4397098471655953 < \frac{Q_3(W)}{C(W)} \le K_G(3).
$$
The matrix uses 160 additional Alice settings beyond the 141-row reference. Two symmetry-related neighbors were introduced at each of 15 twofold directions and at each member of another 30-direction orbit. The centers of three spherical gaps contributed further orbits of 10, 30 and 30 directions. All 301 Alice directions and all 321 Bob directions were subsequently optimized. The exact classical maximum is
$$
 C(W)=641951269303647081416258863417.
$$

## Transposing the reference search

Let $K$ be the 141 by 321 integer reference matrix and set $T=641519292$. The previous exhaustive enumeration covers every Alice signing $a$ with $\|K^{\mathsf T}a\|_1>T$, up to its signed symmetries and global sign reversal. This covering list contains 4,309 records. The archive includes the original integer branch-and-bound computation and a proof of its cutoffs. [Parent proof](parent/REFERENCE_PROOF.md)

The 81 by 321 matrix underlying this construction was obtained from the example of Márton, Bene, Diviánszky and Vértesi. [Márton et al.](https://arxiv.org/abs/2611.22893) · [Lemmata entry](https://lemmata.iol.berlin/html/2611.00009)

For any $b$ with $\|Kb\|_1>T$, choose $a_i$ to agree with $(Kb)_i$ wherever the latter is nonzero. Then
$$
 T<a^{\mathsf T}Kb\le\|K^{\mathsf T}a\|_1,
$$
so a simultaneous signed symmetry takes this pair to one with a listed $a$. For that $a$, put $h=K^{\mathsf T}a$. Start with $b_j=\operatorname{sign}(h_j)$, choosing $+1$ at zero. Flipping a set of signs $J$ gives score $\sum_j|h_j|-2\sum_{j\in J}|h_j|$. Every subset giving a score strictly above $T$ is enumerated, including free flips at zeros.

There are 811,958 eligible pairs among the listed Alice records. The primary enumeration keeps the 730,373 pairs satisfying $a_i(Kb)_i\ge0$ for all $i$ and canonicalizes $b$ under the 60 signed symmetries and global sign. This yields exactly 625,968 Bob representatives. A separate implementation keeps every eligible pair and obtains exactly the same set. Each inclusion follows directly from the displayed inequality and the flip formula.

## Moving the reference directions

The supplied integer transport $V$ has 301 rows and 141 columns. Define $H=VK$ and $s=\max_j\sum_i|V_{ij}|=984625626$. For any Bob signing,
$$
 \|Hb\|_1\le s\|Kb\|_1.
$$
Thus every $b$ with $\|Hb\|_1>sT$ belongs to the transposed reference list up to symmetry. Exact evaluation leaves 101,967 representatives. The verifier checks the signed symmetries of $V$ and of the witness entrywise. This makes a calculation on one representative valid for its entire orbit.

The uncalibrated matrix in the reconstruction is $M=H+F$. Write $U$ for the certified global bound on $C(F)$. It is recovered from integer arithmetic as the complementary bound in `witness/result.json` minus $sT$. The decomposition of $F$ uses nonnegative multiples of previously certified comparison matrices, signed relabelings of reference games, and an integer perturbation. A relabeling pulls every classical signing back to an allowed signing of the source game. Symmetry averaging preserves its classical upper bound by convexity. Entrywise integer rounding costs at most the sum of the absolute rounding errors. The verifier reconstructs every nonzero term and adds its proved bound with the same coefficient.

Some relabelings merge several source rows at the same destination. A source row signing can arise from a destination signing only when its signs obey these identifications. For each embedded copy of $K$, enumerate the symmetry images of all 4,309 source records that obey the identifications. For each, merge the signed column fields as prescribed by the column relabeling and compute their exact one-norm. An unlisted source signing contributes at most $T$. The computation retains up to 256 high assignments on the destination support, raising the complementary bound to the largest discarded value if necessary.

To bound the 60-term symmetry average of such a copy, orient a largest term at the identity. If its score exceeds the complementary bound, its partial assignment is retained. In each other orientation, a retained assignment is eligible only when its signs agree on the common support, up to global reversal. Bound that term by the smaller of the identity score and the largest compatible score, allowing the complementary bound in every orientation. Adding these 60 upper bounds and maximizing over the retained identity assignments gives the asserted bound on the average. The verifier repeats this contraction and comparison from the source sign list.

For the integer perturbation $E$, choose the stored positive weights $v_j$, put $G=E\operatorname{diag}(v)E^{\mathsf T}$ and let $L$ be its supplied integer factor for the comparison $\operatorname{diag}(d)-G$. Set $R=\operatorname{diag}(d)-G-LL^{\mathsf T}$. Diagonal dominance gives
$$
 G\preceq\operatorname{diag}\left(d_i+\sum_k|R_{ik}|\right).
$$
For any unit-ball row vectors with Gram matrix $X$, optimize over column vectors and apply weighted Cauchy–Schwarz. The square of the score is at most
$$
 \left(\sum_j1/v_j\right)\operatorname{tr}(GX)
 \le\left(\sum_j1/v_j\right)\left(\sum_i d_i+\sum_{ik}|R_{ik}|\right).
$$
The integer checker computes the full residual and rounds outwards. This estimate applies to classical signs and also to vectors of every dimension.

## Exact denominator and numerator

The final distributed matrix is $W=qH+pF$ with $q=10^{12}$ and $p=999999444607$. Outside the 101,967-record list one has
$$
 \|Wb\|_1\le qsT+pU
 =\frac{25678050772145879924996720520334256197}{40000000}
 \le C(W).
$$
On the list, maximizing $\|Wb\|_1$ gives 641951269303647081416258863417. The archived Bob signing attains this value. The two inequalities establish the exact classical maximum over all $2^{321}$ Bob strategies, with Alice already maximized out.

Write $D=10^{40}$. The distributed integer triples $u_i,w_j$ satisfy $\|u_i\|_2^2,\|w_j\|_2^2\le D^2$. Their integer objective is
$$
 N=\sum_{ij}W_{ij}\langle u_i,w_j\rangle
 =92422356381691369081494724621543334927103898587805286507057963067018402350722593401925517175131539945819591534.
$$
Unit-ball triples suffice for the lower bound. Fix one party and choose for each vector a unit maximizer of its linear objective, then repeat for the other party. These two replacements can only increase the score. Consequently
$$
 K_G(3)\ge \frac{Q_3(W)}{C(W)}
 \ge \frac{N}{D^2 C(W)}
 > 1.4397098471655953.
$$
The final comparison is an integer cross-multiplication. Applying the preceding Gram estimate to the entire matrix also certifies a gap below $7.2\times 10^{-35}$ between this rational ratio and $Q_\infty(W)/C(W)$. This last estimate concerns the single displayed matrix. A stronger lower bound on the universal constant can use a different matrix.

## How far this search can go with the displayed directions

Keep all displayed rational triples fixed. Consider signed-icosahedrally invariant matrices built from an arbitrary real row transport $VK$, a perturbation $E$, and nonnegative multiples of the 24 previous comparison groups and the 128 listed symmetrized embeddings. Write $\nu(E)$ for the supremum of the vector objective for $E$ in arbitrary dimension. Allow the denominator $B$ to be any bound satisfying both
$$
 B\ge C(M),\qquad B\ge T\|V\|_{1\to1}+\nu(E)+\sum_l\lambda_l c_l ,
$$
where $c_l$ are the comparison costs used by the certificate. Entrywise rounding may be charged by its absolute sum. Then the fixed-vector score divided by $B$ is **less than 1.4397119** throughout this family. This quantifies a limitation of the current directions and the stated rules for certifying the denominator.

To see this, let $G_{ij}=\langle u_i,w_j\rangle/D^2$. The certificate supplies nonnegative rational weights $\omega_t$ on sign matrices $a_tb_t^{\mathsf T}$. Their contribution to the score is at most $B\sum_t\omega_t$. Average $G-\sum_t\omega_t a_tb_t^{\mathsf T}$ over the signed group action and call the resulting rational matrix $Z$. Its pairing with an invariant $M$ equals the pairing before averaging.

The verifier bounds the contribution from $VK$ by
$$
 \|V\|_{1\to1}\sum_j\max_i |\langle K_{j,:}, Z_{i,:}\rangle|.
$$
It also computes $\langle A_l,Z\rangle/c_l$ for each comparison matrix $A_l$. For relabeled copies of $K$ it may replace the cost by the smaller $T$ plus the rounding allowance. Finally it checks an explicit rational factorization with entrywise residual $Z_{ij}=\langle r_i,s_j\rangle+e_{ij}$, $|e_{ij}|\le\epsilon$. Pairing $Z$ with $E$ is bounded by
$$
 \left(\max_i\|r_i\|_2\max_j\|s_j\|_2+\sqrt n\,\epsilon\right)\nu(E).
$$
For the residual term, use coordinate row vectors and the columns of $(e_{ij})$ as column vectors. Taking the largest of the cost-normalized bounds and adding $\sum_t\omega_t$ yields the stated rational ceiling. The archive contains the sign weights, factors and verifier. [Family certificate](witness/family.json) · [Checker](family.py)
