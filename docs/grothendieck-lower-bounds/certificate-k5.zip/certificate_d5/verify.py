"""Exact vector certificate for K_G(5), importing the cited classical upper bound.

Uses only the Python standard library. It does not independently prove the
classical upper bound 919782264 from Marton et al., arXiv:2611.22893, Table 4.
"""
from pathlib import Path
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib, json

ROOT = Path(__file__).resolve().parent


def read_integer_matrix(path):
    rows=[]
    for line in path.read_text().splitlines():
        if not line.strip():continue
        row=[Decimal(s) for s in line.split()]
        assert all(x==x.to_integral_value() for x in row)
        rows.append([int(x) for x in row])
    return rows


def verify():
    w=json.loads((ROOT/'witness.json').read_text())
    assert hashlib.sha256((ROOT/'matrix.txt').read_bytes()).hexdigest()==w['matrix_sha256']
    assert hashlib.sha256((ROOT/'source_matrix.txt').read_bytes()).hexdigest()==w['source_matrix_sha256']
    M=read_integer_matrix(ROOT/'matrix.txt')
    assert M==read_integer_matrix(ROOT/'source_matrix.txt')
    A,B,D=w['alice_numerators'],w['bob_numerators'],w['denominator']
    assert w['dimension']==5 and D==10**15
    assert len(M)==len(A)==80 and len(B)==269
    assert all(len(row)==269 for row in M)
    assert all(len(v)==5 and all(type(x) is int for x in v)
               and sum(x*x for x in v)<=D*D for v in A+B)
    N=sum(M[i][j]*sum(A[i][k]*B[j][k] for k in range(5))
          for i in range(80) for j in range(269))
    assert N==w['quantum_objective_numerator']==1379089182810903048332452323838491520594
    assert w['quantum_objective_denominator']==D*D
    signs=w['classical_alice_signs'];C=w['classical_cited_upper']
    assert C==919782264 and len(signs)==80 and all(x in (-1,1) for x in signs)
    attained=sum(abs(sum(signs[i]*M[i][j] for i in range(80))) for j in range(269))
    assert attained==C
    ratio=Fraction(N,D*D*C)
    assert ratio>Fraction('1.49936483533988')
    with localcontext() as context:
        context.prec=65
        print('Exact rational quotient:',Decimal(ratio.numerator)/Decimal(ratio.denominator))
    print('PASS: all 349 five-dimensional rational vectors satisfy the unit-ball constraints.')
    print('PASS: exact numerator, matrix identity, attaining classical signs, and strict quotient comparison.')
    print('K_G(5) > 1.49936483533988 using the cited classical upper bound C(M) <= 919782264.')
    print('The classical upper bound is an external result; it was not verified by this program.')


if __name__=='__main__':verify()
