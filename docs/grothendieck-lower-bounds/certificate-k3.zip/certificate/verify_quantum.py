"""Check the explicit rank-three witness using Python integers only.

This checks the numerator and an attaining classical assignment. The global
classical upper bound is established separately by verify_classical.cpp.
"""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import hashlib
import json

ROOT = Path(__file__).resolve().parent
NUMERATOR = 461845159210737970564046146266219485493
DENOMINATOR = 10**30
CLASSICAL = 320975296
LOWER = Fraction("1.43888070193021")


def verify():
    raw = (ROOT / "matrix.txt").read_bytes()
    matrix = [[int(x) for x in line.split()]
              for line in raw.decode().splitlines() if line.strip()]
    witness = json.loads((ROOT / "primal.json").read_text())
    assert hashlib.sha256(raw).hexdigest() == witness["matrix_sha256"]
    alice = witness["alice_numerators"]
    bob = witness["bob_numerators"]
    denominator = witness["primal_denominator"]
    assert denominator == 10**15
    assert len(matrix) == len(alice) == 81
    assert len(bob) == 321 and all(len(row) == 321 for row in matrix)
    assert all(len(v) == 3 and all(type(x) is int for x in v)
               and sum(x*x for x in v) <= denominator**2 for v in alice + bob)
    numerator = sum(matrix[i][j] * sum(alice[i][k] * bob[j][k]
                    for k in range(3)) for i in range(81) for j in range(321))
    assert numerator == NUMERATOR and denominator**2 == DENOMINATOR
    signs = witness["classical_alice_signs"]
    assert len(signs) == 81 and all(x in (-1, 1) for x in signs)
    attained = sum(abs(sum(signs[i] * matrix[i][j] for i in range(81)))
                   for j in range(321))
    assert attained == CLASSICAL
    ratio = Fraction(numerator, denominator**2 * CLASSICAL)
    assert ratio > LOWER
    with localcontext() as context:
        context.prec = 60
        decimal = str(Decimal(ratio.numerator) / Decimal(ratio.denominator))
    result = {
        "matrix_shape": [81, 321],
        "matrix_sha256": witness["matrix_sha256"],
        "unit_ball_constraints": "all 402 checked exactly in dimension 3",
        "quantum_numerator": numerator,
        "quantum_denominator": denominator**2,
        "classical_value_attained": attained,
        "ratio_decimal": decimal,
        "strict_decimal_lower_bound": "1.43888070193021",
        "global_classical_upper_bound": "requires separate C++ search",
    }
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    verify()
